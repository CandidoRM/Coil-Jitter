import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, _ as createFileRoute, b as require_jsx_runtime, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { _ as FlaskConical, a as Signal, c as Ruler, d as Radio, f as RadioTower, g as Gauge, h as HeartPulse, i as Stethoscope, l as Rss, m as Microscope, n as TowerControl, o as ScanSearch, p as Radar, r as TestTubes, s as SatelliteDish, t as Wifi, u as RotateCcw, v as DraftingCompass, y as Antenna } from "../_libs/lucide-react.mjs";
import { readFileSync } from "node:fs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BWx8LyWy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var TRIED = "coil-fault-tried";
var DEAD = "coil-fault-dead";
var EPOCH = "coil-fault-epoch";
var epoch = "3";
var NOISE = /medida falhou|pacote falhou|AbortError|Failed to fetch|Load failed|NetworkError|The user aborted|ResizeObserver|^off$/i;
function memory$2() {
	try {
		return typeof sessionStorage === "undefined" ? null : sessionStorage;
	} catch {
		return null;
	}
}
function forgetOldFault() {
	const box = memory$2();
	if (!box || box.getItem(EPOCH) === epoch) return;
	box.removeItem(DEAD);
	box.removeItem(TRIED);
	box.setItem(EPOCH, epoch);
}
forgetOldFault();
function faultDead() {
	return memory$2()?.getItem(DEAD) === "1";
}
function lock() {
	try {
		memory$2()?.setItem(DEAD, "1");
	} catch {}
	if (typeof window !== "undefined") window.dispatchEvent(new Event("coil-dead"));
}
var busy = false;
function noteFault(reason) {
	const text = reason instanceof Error ? `${reason.name} ${reason.message}` : String(reason ?? "");
	if (!text || NOISE.test(text)) return "ignore";
	const box = memory$2();
	if (!box) {
		lock();
		return "dead";
	}
	if (box.getItem(DEAD) === "1") return "dead";
	if (busy) return box.getItem(TRIED) === "1" ? "dead" : "restart";
	busy = true;
	if (box.getItem(TRIED) === "1") {
		lock();
		return "dead";
	}
	try {
		box.setItem(TRIED, "1");
		const timer = window.setTimeout(() => lock(), 4e3);
		window.addEventListener("pagehide", () => window.clearTimeout(timer), { once: true });
		location.reload();
	} catch {
		lock();
		return "dead";
	}
	return "restart";
}
function forgiveRestart() {
	if (faultDead()) return;
	try {
		memory$2()?.removeItem(TRIED);
	} catch {}
}
var armed = false;
function armFaultWatch() {
	if (armed || typeof window === "undefined") return;
	armed = true;
	window.addEventListener("error", (event) => {
		const target = event.target;
		if (target && target !== window) {
			if (target instanceof HTMLScriptElement) noteFault(/* @__PURE__ */ new Error("arquivo do Coil falhou"));
			if (target instanceof HTMLLinkElement && target.rel === "stylesheet") noteFault(/* @__PURE__ */ new Error("arquivo do Coil falhou"));
			return;
		}
		noteFault(event.error ?? event.message);
	}, true);
	window.addEventListener("unhandledrejection", (event) => {
		noteFault(event.reason);
	});
}
armFaultWatch();
function AppErrorComponent({ error }) {
	const [dead, setDead] = (0, import_react.useState)(faultDead);
	(0, import_react.useEffect)(() => {
		if (noteFault(error) === "dead" || faultDead()) setDead(true);
	}, [error]);
	if (!dead) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-full flex-col items-center justify-center gap-6 px-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "clock-doing",
			children: "Coil Jitter Off-line"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "key-stack",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "speed-redo is-off",
				disabled: true,
				"aria-label": "Medir"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "speed-redo wake-redo is-off",
				disabled: true,
				"aria-label": "Sintonizar"
			})]
		})]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var CLOUD = "https://speed.cloudflare.com";
var WINDOW_MS = 4e3;
var DOWN_CAP = 12e6;
var PARALLEL = 6;
var UP_BYTES = 5e5;
var UP_PARALLEL = 2;
var halt = new AbortController();
function haltCoil() {
	halt.abort();
	halt = new AbortController();
}
function liveCtrl() {
	const ctrl = new AbortController();
	if (halt.signal.aborted) {
		ctrl.abort();
		return ctrl;
	}
	const stop = () => ctrl.abort();
	halt.signal.addEventListener("abort", stop, { once: true });
	ctrl.signal.addEventListener("abort", () => halt.signal.removeEventListener("abort", stop), { once: true });
	return ctrl;
}
function mbps(bytes, ms) {
	if (ms < 1 || bytes < 1) return 0;
	return bytes * 8 / ms / 1e3;
}
function median(values) {
	const sorted = [...values].sort((a, b) => a - b);
	const mid = Math.floor(sorted.length / 2);
	return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}
var bodyCache = /* @__PURE__ */ new Map();
function randomBody(bytes) {
	const cached = bodyCache.get(bytes);
	if (cached) return cached;
	const buffer = new ArrayBuffer(bytes);
	const payload = new Uint8Array(buffer);
	for (let offset = 0; offset < bytes; offset += 65536) crypto.getRandomValues(payload.subarray(offset, Math.min(bytes, offset + 65536)));
	bodyCache.set(bytes, buffer);
	return buffer;
}
function warmUploadBodies() {
	randomBody(64e3);
	randomBody(UP_BYTES);
}
if (typeof window !== "undefined") {
	const idle = window.requestIdleCallback;
	if (idle) idle(() => warmUploadBodies());
	else window.setTimeout(warmUploadBodies, 1200);
}
function cloudPaths(stamp) {
	return {
		ping: (i) => `${CLOUD}/__down?bytes=0&r=${stamp}-p${i}`,
		warm: (i) => `${CLOUD}/__down?bytes=400000&r=${stamp}-w${i}`,
		down: (i) => `${CLOUD}/__down?bytes=25000000&r=${stamp}-d${i}`,
		up: `${CLOUD}/__up?r=${stamp}-u`
	};
}
function ownPaths(stamp) {
	return {
		ping: (i) => `/api/speed?bytes=0&r=${stamp}-p${i}`,
		warm: (i) => `/api/speed?bytes=400000&r=${stamp}-w${i}`,
		down: (i) => `/api/speed?bytes=12000000&r=${stamp}-d${i}`,
		up: `/api/speed?r=${stamp}-u`
	};
}
async function cloudReachable() {
	const ctrl = liveCtrl();
	const timer = setTimeout(() => ctrl.abort(), 2500);
	try {
		return (await fetch(`${CLOUD}/__down?bytes=0&r=${Date.now()}`, {
			cache: "no-store",
			signal: ctrl.signal
		})).ok;
	} catch {
		return false;
	} finally {
		clearTimeout(timer);
	}
}
async function pull$1(url, signal, add) {
	const response = await fetch(url, {
		cache: "no-store",
		signal
	});
	if (!response.ok || !response.body) throw new Error("medida falhou");
	const reader = response.body.getReader();
	try {
		while (!signal.aborted) {
			const { done, value } = await reader.read();
			if (done || !value) break;
			add(value.byteLength);
			noteRx(value.byteLength);
		}
	} catch (error) {
		if (signal.aborted) return;
		throw error;
	} finally {
		reader.cancel().catch(() => {});
	}
}
async function measurePing(url) {
	const samples = [];
	let lost = 0;
	for (let i = 0; i < 5; i++) {
		const start = performance.now();
		try {
			const response = await fetch(url(i), { cache: "no-store" });
			if (!response.ok) throw new Error("medida falhou");
			noteRx((await response.arrayBuffer()).byteLength || 1);
			if (i > 0) samples.push(performance.now() - start);
		} catch (error) {
			if (i === 0) throw error;
			lost += 1;
		}
	}
	if (!samples.length) throw new Error("medida falhou");
	let drift = 0;
	for (let i = 1; i < samples.length; i++) drift += Math.abs(samples[i] - samples[i - 1]);
	return {
		ping: median(samples),
		jitter: samples.length > 1 ? drift / (samples.length - 1) : 0,
		lost
	};
}
function loadedMbps(ticks) {
	if (ticks.length < 2) return 0;
	const first = ticks[0];
	const last = ticks[ticks.length - 1];
	const span = last.t - first.t;
	if (span < 1) return 0;
	const cut = first.t + span * .25;
	const mark = ticks.find((tick) => tick.t >= cut);
	const from = mark && last.t - mark.t >= 600 && last.bytes - mark.bytes >= 6e4 ? mark : first;
	return mbps(last.bytes - from.bytes, last.t - from.t);
}
async function warmDownload(url) {
	const ctrl = liveCtrl();
	const timer = setTimeout(() => ctrl.abort(), 4e3);
	try {
		await Promise.all(Array.from({ length: PARALLEL }, (_, i) => pull$1(url(i), ctrl.signal, () => {})));
	} catch {} finally {
		clearTimeout(timer);
		ctrl.abort();
	}
}
async function oneLoadedPing(url) {
	const ctrl = liveCtrl();
	const timer = setTimeout(() => ctrl.abort(), 4e3);
	const start = performance.now();
	try {
		const response = await fetch(url, {
			cache: "no-store",
			signal: ctrl.signal
		});
		if (!response.ok) return null;
		noteRx((await response.arrayBuffer()).byteLength || 1);
		return Math.round(performance.now() - start);
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
	}
}
var NEAR_DOWN = [
	"https://sao.download.datapacket.com/100mb.bin",
	"https://eze.download.datapacket.com/100mb.bin",
	"https://scl.download.datapacket.com/100mb.bin",
	"https://bog.download.datapacket.com/100mb.bin",
	"https://lim.download.datapacket.com/100mb.bin"
];
async function firstByte(url) {
	const ctrl = liveCtrl();
	const timer = setTimeout(() => ctrl.abort(), 1800);
	const start = performance.now();
	try {
		const response = await fetch(`${url}?r=${Date.now()}`, {
			cache: "no-store",
			signal: ctrl.signal
		});
		if (!response.ok || !response.body) return null;
		const reader = response.body.getReader();
		const { value } = await reader.read();
		reader.cancel().catch(() => {});
		if (!value) return null;
		return performance.now() - start;
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
		ctrl.abort();
	}
}
async function closestDownloads(count = 2) {
	return (await Promise.all(NEAR_DOWN.map(async (url) => ({
		url,
		ms: await firstByte(url)
	})))).filter((row) => row.ms != null).sort((a, b) => a.ms - b.ms).slice(0, count).map((row) => row.url);
}
function fairDown(values) {
	const ready = values.filter((n) => Number.isFinite(n) && n > 0);
	if (ready.length <= 1) return ready[0] ?? 0;
	const kept = ready.filter((value, index) => {
		const others = ready.filter((_, i) => i !== index);
		return value >= others.reduce((sum, n) => sum + n, 0) / others.length * .6;
	});
	const use = kept.length ? kept : ready;
	return use.reduce((sum, n) => sum + n, 0) / use.length;
}
async function onceDownload(fileUrl) {
	const stamp = Date.now();
	try {
		const reading = await measureDownload((i) => `${fileUrl}?r=${stamp}-${i}`);
		touchTraffic();
		return reading.mbps;
	} catch {
		return null;
	}
}
async function measureDownload(url, probe) {
	const ctrl = liveCtrl();
	const ticks = [];
	let bytes = 0;
	let seq = 0;
	let windowTimer;
	let loadedTask = null;
	const failsafe = setTimeout(() => ctrl.abort(), 12e3);
	const add = (n) => {
		windowTimer ??= setTimeout(() => ctrl.abort(), WINDOW_MS);
		bytes += n;
		const now = performance.now();
		const last = ticks[ticks.length - 1];
		if (!last || now - last.t >= 100) ticks.push({
			t: now,
			bytes
		});
		else {
			last.t = now;
			last.bytes = bytes;
		}
		if (probe && !loadedTask) loadedTask = new Promise((resolve) => {
			setTimeout(() => resolve(oneLoadedPing(probe(90))), 800);
		});
		if (bytes >= DOWN_CAP) ctrl.abort();
	};
	async function worker() {
		while (!ctrl.signal.aborted && bytes < DOWN_CAP) try {
			await pull$1(url(seq++), ctrl.signal, add);
		} catch (error) {
			if (ctrl.signal.aborted) return;
			throw error;
		}
	}
	try {
		await Promise.all(Array.from({ length: PARALLEL }, () => worker()));
	} finally {
		clearTimeout(failsafe);
		if (windowTimer) clearTimeout(windowTimer);
		ctrl.abort();
	}
	if (bytes < 5e4 || ticks.length < 2) throw new Error("medida falhou");
	return {
		mbps: loadedMbps(ticks),
		loaded: loadedTask ? await loadedTask : null
	};
}
function sendUpload(url, body) {
	return new Promise((resolve, reject) => {
		const xhr = new XMLHttpRequest();
		const timer = setTimeout(() => {
			xhr.abort();
			reject(/* @__PURE__ */ new Error("medida falhou"));
		}, 12e3);
		xhr.open("POST", url);
		xhr.setRequestHeader("content-type", "application/octet-stream");
		const stop = () => {
			clearTimeout(timer);
			halt.signal.removeEventListener("abort", stop);
			xhr.abort();
			reject(/* @__PURE__ */ new Error("medida falhou"));
		};
		if (halt.signal.aborted) {
			stop();
			return;
		}
		halt.signal.addEventListener("abort", stop, { once: true });
		const finish = () => {
			clearTimeout(timer);
			halt.signal.removeEventListener("abort", stop);
		};
		xhr.upload.onload = () => {
			finish();
			resolve();
		};
		xhr.upload.onerror = () => {
			finish();
			reject(/* @__PURE__ */ new Error("medida falhou"));
		};
		xhr.onerror = () => {
			finish();
			reject(/* @__PURE__ */ new Error("medida falhou"));
		};
		xhr.send(body);
		noteTx(body.byteLength);
	});
}
async function measureUpload(url, warm) {
	if (warm) try {
		await sendUpload(url, randomBody(64e3));
	} catch {}
	const bodies = Array.from({ length: UP_PARALLEL }, () => randomBody(UP_BYTES));
	const started = performance.now();
	await Promise.all(bodies.map((body) => sendUpload(url, body)));
	return mbps(UP_BYTES * bodies.length, performance.now() - started);
}
async function timedFetch(url) {
	const ctrl = liveCtrl();
	const timer = setTimeout(() => ctrl.abort(), 8e3);
	const start = performance.now();
	try {
		const response = await fetch(url, {
			cache: "no-store",
			signal: ctrl.signal
		});
		if (!response.ok) throw new Error("pacote falhou");
		noteRx((await response.arrayBuffer()).byteLength || 1);
		return performance.now() - start;
	} finally {
		clearTimeout(timer);
	}
}
var IDLE_MS = 1e4;
var lastTraffic = 0;
var pageRx = 0;
var pageTx = 0;
function noteRx(bytes) {
	if (bytes > 0) pageRx += bytes;
}
function noteTx(bytes) {
	if (bytes > 0) pageTx += bytes;
}
function readTraffic() {
	const native = coilNative();
	if (typeof native?.rx === "number" || typeof native?.tx === "number") return {
		rx: native?.rx ?? 0,
		tx: native?.tx ?? 0
	};
	return {
		rx: pageRx,
		tx: pageTx
	};
}
function touchTraffic() {
	lastTraffic = performance.now();
}
function generationParts(mbps) {
	const speed = mbps == null || !Number.isFinite(mbps) ? null : mbps < .3 ? 2 : mbps < 5 ? 3 : mbps < 50 ? 4 : 5;
	if (typeof navigator === "undefined") return {
		phone: null,
		speed
	};
	const reported = navigator.connection?.effectiveType;
	return {
		phone: reported === "slow-2g" || reported === "2g" ? 2 : reported === "3g" ? 3 : reported === "4g" ? 4 : null,
		speed
	};
}
function generationMark(mbps) {
	const { phone, speed } = generationParts(mbps);
	const name = (n) => `${n}G`;
	if (speed == null) return phone == null ? "" : name(phone);
	if (phone == null) return name(speed);
	if (Math.abs(phone - speed) >= 2) {
		const mid = (phone + speed) / 2;
		if (Number.isInteger(mid)) return name(mid);
		return `${name(Math.floor(mid))}–${name(Math.ceil(mid))}`;
	}
	if (phone === 4 && speed >= 5) return "5G";
	return name(speed >= phone ? speed : phone);
}
function generationLine(mbps) {
	const { phone, speed } = generationParts(mbps);
	const settled = speed ?? 4;
	const name = (n) => `${n}G`;
	if (phone == null) return `O celular não informa a geração · a descida parece ${name(settled)}`;
	if (Math.abs(phone - settled) >= 2) {
		const mid = (phone + settled) / 2;
		if (Number.isInteger(mid)) return `Destoa do celular · média ${name(mid)}`;
		return `Destoa do celular · entre ${name(Math.floor(mid))} e ${name(Math.ceil(mid))}`;
	}
	if (phone === 4 && settled >= 4) return "Perto do celular · 4G ou mais";
	return `Confere com o celular · ${name(phone)}`;
}
function linkFacts() {
	if (typeof navigator === "undefined" || navigator.onLine === false) return [];
	const lines = [];
	const connection = navigator.connection;
	if (!connection) {
		lines.push("O aparelho não informa o tipo.");
		return lines;
	}
	if (connection.type === "wifi") lines.push("Caminho: Wi-fi.");
	else if (connection.type === "cellular") lines.push("Caminho: plano.");
	else if (connection.type === "ethernet") lines.push("Caminho: cabo.");
	else if (connection.type === "bluetooth") lines.push("Caminho: Bluetooth.");
	else if (connection.type === "none") lines.push("Sem interface de rede.");
	else if (connection.type) lines.push("Caminho não identificado.");
	if (connection.saveData) lines.push("Economia de dados ligada.");
	if (typeof connection.rtt === "number" && connection.rtt >= 1e3) lines.push(`O aparelho estima a resposta muito alta · ${Math.round(connection.rtt)} ms`);
	else if (typeof connection.rtt === "number" && connection.rtt >= 300) lines.push(`O aparelho estima a resposta alta · ${Math.round(connection.rtt)} ms`);
	if (typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < .5) lines.push("O aparelho estima a descida muito baixa.");
	else if (typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < 1.5) lines.push("O aparelho estima a descida baixa.");
	return lines;
}
function looksSlow() {
	const connection = navigator.connection;
	if (!connection) return false;
	if (connection.effectiveType === "slow-2g" || connection.effectiveType === "2g" || connection.effectiveType === "3g") return true;
	if (typeof connection.rtt === "number" && connection.rtt >= 300) return true;
	return typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < 1.5;
}
function linkSlow() {
	return looksSlow();
}
var activeUntil = 0;
function noteAction() {
	activeUntil = performance.now() + IDLE_MS;
}
var gate = "up";
function setGate(next) {
	gate = next;
}
function readLane() {
	if (typeof navigator === "undefined") return null;
	const nav = navigator;
	const kind = nav.connection?.type;
	if (kind === "ethernet") return "cable";
	if (kind === "bluetooth") return "bt";
	if (kind === "cellular") return "cell";
	if (kind === "wifi") return "wifi";
	if (kind === "none") return null;
	return !nav.userAgentData?.mobile && !/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) ? "wifi" : null;
}
function readVpn() {
	return coilNative()?.vpn === true;
}
function readInterruption() {
	return coilNative()?.interruption?.trim() || "";
}
function towerPhrase(meters) {
	if (!Number.isFinite(meters) || meters < 0) return "";
	if (meters <= 400) return "Torres próximas";
	if (meters <= 1500) return "Torres afastadas";
	if (meters <= 5e3) return "Torres longínquas";
	return "Torres remotas";
}
function readTowers() {
	const native = coilNative();
	const cell = native?.cell;
	const fix = native?.fix;
	if (!cell || !Number.isFinite(cell.mcc) || !Number.isFinite(cell.mnc) || !Number.isFinite(cell.tac) || !Number.isFinite(cell.id)) return "";
	if (!fix || !Number.isFinite(fix.lat) || !Number.isFinite(fix.lon)) return "";
	if (typeof native?.towerMeters !== "number") return "";
	return towerPhrase(native.towerMeters);
}
function readDbm() {
	if (typeof navigator === "undefined" || readLane() !== "cell") return null;
	const dbm = coilNative()?.dbm;
	if (typeof dbm !== "number" || !Number.isFinite(dbm) || dbm >= 0 || dbm < -150) return null;
	return Math.round(dbm);
}
function readSignal() {
	const dbm = readDbm();
	if (dbm == null) return "";
	return `Sinal −${Math.abs(dbm)} dBm`;
}
function openInterruptions() {
	const open = coilNative()?.openInterruptions;
	if (!open) return false;
	open();
	return true;
}
function coilNative() {
	if (typeof window === "undefined") return void 0;
	return window.CoilNative;
}
async function probeReach() {
	if (typeof navigator !== "undefined" && navigator.onLine === false) return "down";
	const ctrl = liveCtrl();
	const timer = setTimeout(() => ctrl.abort(), 2500);
	try {
		const response = await fetch("/api/reach", {
			cache: "no-store",
			signal: ctrl.signal
		});
		if (response.redirected) {
			const here = new URL(response.url).host;
			if (here && here !== location.host) return "portal";
		}
		if (!response.ok) return "local";
		return "up";
	} catch {
		return navigator.onLine === false ? "down" : "local";
	} finally {
		clearTimeout(timer);
	}
}
function linkMark(busy) {
	if (typeof navigator !== "undefined" && navigator.onLine === false) return "off";
	if (gate !== "up") return "off";
	if (looksSlow()) return "slow";
	if (busy || performance.now() < activeUntil) return "active";
	return "idle";
}
async function sendMicro() {
	const stamp = Date.now();
	try {
		return await timedFetch(`${CLOUD}/__down?bytes=5000&r=${stamp}-prime`);
	} catch {
		return await timedFetch(`/api/speed?bytes=5000&r=${stamp}-prime`);
	}
}
async function primeLink(onStep) {
	const idle = lastTraffic === 0 || performance.now() - lastTraffic > IDLE_MS;
	const slow = looksSlow();
	if (!idle && !slow) return {
		primed: false,
		waitMs: 0
	};
	onStep(idle ? "ociosa" : "lenta");
	await new Promise((resolve) => setTimeout(resolve, 350));
	onStep("pacote");
	const took = await sendMicro();
	const waitMs = Math.round(Math.min(500, Math.max(100, took < 120 ? 180 : took < 300 ? 320 : 480)));
	onStep("espera", waitMs);
	await new Promise((resolve) => setTimeout(resolve, waitMs));
	touchTraffic();
	onStep("pronta");
	return {
		primed: true,
		waitMs
	};
}
async function kickUdp() {
	if (typeof RTCPeerConnection === "undefined") return false;
	const pc = new RTCPeerConnection({ iceServers: [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }] });
	try {
		pc.createDataChannel("coil");
		await pc.setLocalDescription(await pc.createOffer());
		return await new Promise((resolve) => {
			let done = false;
			const finish = (hit) => {
				if (done) return;
				done = true;
				clearTimeout(timer);
				resolve(hit);
			};
			const timer = setTimeout(() => finish(false), 2500);
			pc.onicecandidate = (event) => {
				const cand = event.candidate?.candidate ?? "";
				if (cand.includes("typ srflx") || cand.includes("typ relay")) finish(true);
				else if (!event.candidate) finish(false);
			};
		});
	} catch {
		return false;
	} finally {
		pc.close();
	}
}
async function kick(url) {
	const ctrl = liveCtrl();
	const timer = setTimeout(() => ctrl.abort(), 4e3);
	try {
		await fetch(url, {
			cache: "no-store",
			mode: "no-cors",
			signal: ctrl.signal
		});
		return true;
	} catch {
		return false;
	} finally {
		clearTimeout(timer);
	}
}
async function probeOutages(place, carrier) {
	const params = new URLSearchParams();
	if (place?.city) params.set("city", place.city);
	if (place?.state) params.set("state", place.state);
	if (place?.uf) params.set("uf", place.uf);
	if (carrier) params.set("carrier", carrier);
	try {
		const response = await fetch(`/api/outage?${params}`, { cache: "no-store" });
		if (!response.ok) return [];
		return ((await response.json()).lines ?? []).filter((line) => line === "Queda aberta na região" || line === "Queda aberta na operadora");
	} catch {
		return [];
	}
}
async function probePages() {
	try {
		const response = await fetch("/api/pages", { cache: "no-store" });
		if (!response.ok) return ["Páginas sem retorno"];
		const data = await response.json();
		return data.lines?.length ? data.lines : ["Páginas sem retorno"];
	} catch {
		return ["Páginas sem retorno"];
	}
}
async function probeDns() {
	const ctrl = liveCtrl();
	const timer = setTimeout(() => ctrl.abort(), 2500);
	const t0 = performance.now();
	try {
		const res = await fetch("https://cloudflare-dns.com/dns-query?name=one.one.one.one&type=A", {
			headers: { accept: "application/dns-json" },
			cache: "no-store",
			signal: ctrl.signal
		});
		if (!res.ok) return {
			kind: "none",
			ms: null
		};
		const data = await res.json();
		const ms = Math.round(performance.now() - t0);
		if (data.Status !== 0) return {
			kind: "none",
			ms
		};
		if (ms >= 1e3) return {
			kind: "late",
			ms
		};
		if (ms >= 300) return {
			kind: "slow",
			ms
		};
		return {
			kind: "ok",
			ms
		};
	} catch {
		return {
			kind: "none",
			ms: null
		};
	} finally {
		clearTimeout(timer);
	}
}
async function clockFetch(url) {
	const ctrl = liveCtrl();
	const timer = setTimeout(() => ctrl.abort(), 2500);
	const t0 = performance.now();
	try {
		await fetch(url, {
			cache: "no-store",
			mode: "no-cors",
			signal: ctrl.signal
		});
		return Math.round(performance.now() - t0);
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
	}
}
async function probePhoneDns() {
	const ip = await clockFetch("https://1.1.1.1/cdn-cgi/trace");
	const named = await clockFetch("https://one.one.one.one/cdn-cgi/trace");
	if (ip == null || named == null) return null;
	return Math.max(0, named - ip);
}
function dnsGap(cloudMs, phoneMs) {
	if (cloudMs == null || phoneMs == null) return "";
	if (phoneMs >= cloudMs * 2 && phoneMs - cloudMs >= 200) return "DNS do celular mais lento que o da Cloudflare";
	return "";
}
var COLO = {
	GRU: "São Paulo",
	GIG: "Rio de Janeiro",
	FOR: "Fortaleza",
	SSA: "Salvador",
	BSB: "Brasília",
	CWB: "Curitiba",
	POA: "Porto Alegre",
	MAO: "Manaus",
	BEL: "Belém",
	REC: "Recife",
	CNF: "Belo Horizonte",
	FLN: "Florianópolis",
	VIX: "Vitória",
	NAT: "Natal",
	AJU: "Aracaju",
	SLZ: "São Luís",
	JPA: "João Pessoa",
	THE: "Teresina",
	CGB: "Cuiabá",
	CGR: "Campo Grande",
	EZE: "Buenos Aires",
	SCL: "Santiago",
	BOG: "Bogotá",
	LIM: "Lima",
	MIA: "Miami",
	IAD: "Ashburn",
	ATL: "Atlanta",
	DFW: "Dallas",
	LAX: "Los Angeles",
	ORD: "Chicago",
	EWR: "Nova York",
	LIS: "Lisboa",
	MAD: "Madrid",
	LHR: "Londres",
	CDG: "Paris",
	FRA: "Frankfurt",
	AMS: "Amsterdã"
};
function exitPhrase(city, ping, signalGood) {
	if (!city) return "";
	if (signalGood && ping != null && ping >= 300) return `Saindo por ${city} · caminho longo`;
	return `Saindo por ${city}`;
}
function carrierPhrase(name) {
	if (!name) return "";
	return /^(google|cloudflare|amazon|microsoft|akamai|oracle|apple|fastly)\b/i.test(name) ? `Saindo pelo ${name}` : `Saindo pela ${name}`;
}
async function probeExit() {
	try {
		const res = await fetch("https://1.1.1.1/cdn-cgi/trace", { cache: "no-store" });
		if (!res.ok) return {
			city: "",
			carrier: ""
		};
		const text = await res.text();
		noteRx(text.length || 1);
		const field = (key) => text.match(new RegExp(`^${key}=(.+)$`, "m"))?.[1]?.trim() ?? "";
		const city = COLO[field("colo")] || field("colo");
		const warp = field("warp");
		if (warp === "on" || warp === "plus") return {
			city,
			carrier: "Cloudflare WARP"
		};
		const ip = field("ip");
		if (!ip) return {
			city,
			carrier: ""
		};
		const who = await fetch(`/api/who?ip=${encodeURIComponent(ip)}`, { cache: "no-store" });
		if (!who.ok) return {
			city,
			carrier: ""
		};
		return {
			city,
			carrier: (await who.json()).name?.trim() || ""
		};
	} catch {
		return {
			city: "",
			carrier: ""
		};
	}
}
async function probeOutside(place) {
	const where = place.trim() || "Brazil";
	try {
		const created = await fetch("https://api.globalping.io/v1/measurements", {
			method: "POST",
			headers: { "content-type": "application/json" },
			cache: "no-store",
			body: JSON.stringify({
				type: "ping",
				target: "speed.cloudflare.com",
				locations: [{
					magic: where,
					limit: 1
				}],
				measurementOptions: { packets: 3 }
			})
		});
		if (!created.ok) return "";
		const job = await created.json();
		if (!job.id) return "";
		for (let i = 0; i < 6; i++) {
			await new Promise((resolve) => setTimeout(resolve, 700));
			const res = await fetch(`https://api.globalping.io/v1/measurements/${job.id}`, { cache: "no-store" });
			if (!res.ok) return "";
			const data = await res.json();
			if (data.status !== "finished") continue;
			const row = data.results?.[0];
			const stats = row?.result?.stats;
			if (row?.result?.status !== "finished" || !stats || typeof stats.avg !== "number") return "";
			if ((stats.loss ?? 0) > 0 || stats.avg >= 300) return "De fora também está ruim";
			return `De ${row.probe?.city?.trim() || (place.trim() ? where : "Brasil")} o destino responde`;
		}
		return "";
	} catch {
		return "";
	}
}
async function pokeNetwork(onStep) {
	const stamp = Date.now();
	const say = (line) => onStep?.(line);
	say("Sintonizando redes...");
	const base = await cloudReachable() ? `${CLOUD}/__down` : "/api/speed";
	let before = 0;
	let dead = false;
	try {
		before = await timedFetch(`${base}?bytes=0&r=${stamp}-a`);
	} catch {
		dead = true;
	}
	say("Emitindo pulso...");
	try {
		await timedFetch(`${base}?bytes=5000&r=${stamp}-b1`);
	} catch {
		dead = true;
	}
	await new Promise((resolve) => setTimeout(resolve, 200));
	say("Emitindo pulso...");
	try {
		await timedFetch(`${base}?bytes=5000&r=${stamp}-b2`);
	} catch {
		dead = true;
	}
	say("Enviando UDP...");
	const udp = await kickUdp();
	const opened = (await Promise.all([
		kick(`${CLOUD}/__down?bytes=1000&r=${stamp}-k1`),
		kick(`https://cp.cloudflare.com/generate_204?r=${stamp}`),
		kick(`https://www.gstatic.com/generate_204?r=${stamp}`),
		kick(`/api/speed?bytes=1000&r=${stamp}-k2`)
	])).filter(Boolean).length;
	for (let beat = 1; beat <= 3; beat++) {
		try {
			await timedFetch(`${base}?bytes=1000&r=${stamp}-beat${beat}`);
		} catch {
			dead = true;
		}
		if (beat < 3) await new Promise((resolve) => setTimeout(resolve, 160));
	}
	await new Promise((resolve) => setTimeout(resolve, 300));
	let after = 0;
	let http = true;
	try {
		after = await timedFetch(`${base}?bytes=0&r=${stamp}-c`);
	} catch {
		http = false;
	}
	const woke = http && !dead && before - after > 100 && after < before * .65;
	touchTraffic();
	return {
		before: Math.round(before),
		after: Math.round(after),
		woke,
		revived: dead && http,
		opened,
		udp,
		http
	};
}
async function diagnosePacket() {
	if (typeof navigator !== "undefined" && navigator.onLine === false) return {
		kind: "off",
		ms: null
	};
	const stamp = Date.now();
	const url = await cloudReachable() ? `${CLOUD}/__down?bytes=0&r=${stamp}-diag` : `/api/speed?bytes=0&r=${stamp}-diag`;
	const ctrl = liveCtrl();
	const timer = setTimeout(() => ctrl.abort(), 3e3);
	const start = performance.now();
	try {
		const response = await fetch(url, {
			cache: "no-store",
			signal: ctrl.signal
		});
		if (!response.ok) throw new Error("pacote falhou");
		noteRx((await response.arrayBuffer()).byteLength || 1);
		return judgeResponse(performance.now() - start);
	} catch {
		return {
			kind: typeof navigator !== "undefined" && navigator.onLine === false ? "off" : "none",
			ms: null
		};
	} finally {
		clearTimeout(timer);
	}
}
function judgeResponse(ms) {
	const time = Math.round(ms);
	if (time >= 1e3) return {
		kind: "late",
		ms: time
	};
	if (time >= 300) return {
		kind: "slow",
		ms: time
	};
	return {
		kind: "ok",
		ms: time
	};
}
function loadLine(idle, loaded) {
	if (loaded == null) return "Ping não voltou na descida";
	return loaded >= idle + 150 && loaded >= Math.round(idle * 1.8) ? `Rede entope na descida · ${loaded} ms` : `Ping firme na descida · ${loaded} ms`;
}
function diagnosisLine(kind, ms) {
	if (kind === "off") return "Queda de conexão durante o envio";
	if (kind === "none") return "Dados enviados sem retorno";
	if (kind === "late") return `Demorou demais · ${ms} ms`;
	if (kind === "slow") return `Respondeu, mas devagar · ${ms} ms`;
	return `Respondeu a tempo · ${ms} ms`;
}
async function openSpeedLane() {
	const stamp = Date.now();
	const cloud = await cloudReachable();
	const paths = cloud ? cloudPaths(stamp) : ownPaths(stamp);
	return {
		cloud,
		async down(warm = false) {
			if (warm) await warmDownload(paths.warm);
			const reading = await measureDownload(paths.down, paths.ping);
			touchTraffic();
			return reading;
		},
		async up(warm = false) {
			let value;
			try {
				value = await measureUpload(paths.up, warm);
			} catch (error) {
				if (!cloud) throw error;
				value = await measureUpload(ownPaths(stamp).up, false);
			}
			touchTraffic();
			return value;
		},
		async ping() {
			const reading = await measurePing(paths.ping);
			touchTraffic();
			return {
				ping: Math.round(reading.ping),
				jitter: Math.round(reading.jitter),
				lost: reading.lost
			};
		}
	};
}
var snapshot = {
	carrier: "Vivo",
	tech: "5G",
	place: "Londrina",
	dbm: -78,
	bars: 3,
	down: 42.6,
	up: 11.4,
	ping: 28,
	usedGb: 6.4,
	capGb: 20,
	renewIn: 12,
	quality: "Boa"
};
var diary = [
	{
		t: "06:58",
		title: "Acordou no Wi-Fi Casa",
		detail: "Sinal cheio"
	},
	{
		t: "07:31",
		title: "Saiu de casa",
		detail: "Passou para Vivo 5G"
	},
	{
		t: "07:40",
		title: "Queda de 11 segundos",
		detail: "No 5G, sozinho"
	},
	{
		t: "07:41",
		title: "Voltou",
		detail: "−81 dBm"
	},
	{
		t: "07:44",
		title: "Agora",
		detail: "−78 dBm · 28 ms"
	}
];
var pulse = [
	22,
	24,
	26,
	25,
	31,
	48,
	36,
	29,
	28,
	27,
	30,
	28,
	26,
	28
];
function br(n, digits = 1) {
	return n.toLocaleString("pt-BR", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	});
}
var concepts = [
	{
		id: 72,
		slug: "polido",
		name: "Polido",
		kind: "chapa",
		line: "Alumínio novo. Sem marca de uso."
	},
	{
		id: 73,
		slug: "escova",
		name: "Escova",
		kind: "chapa",
		line: "Aço escovado na horizontal, ainda limpo."
	},
	{
		id: 74,
		slug: "jato",
		name: "Jato",
		kind: "chapa",
		line: "Fosco jateado. Quase nenhum brilho."
	},
	{
		id: 75,
		slug: "chumbo",
		name: "Chumbo",
		kind: "chapa",
		line: "Grafite escuro, liso, pouco manuseado."
	},
	{
		id: 76,
		slug: "frio",
		name: "Frio",
		kind: "chapa",
		line: "Inox com reflexo frio na diagonal."
	},
	{
		id: 77,
		slug: "niquel",
		name: "Níquel",
		kind: "chapa",
		line: "Metal morno, com um véu leve de dedo."
	},
	{
		id: 78,
		slug: "bronze",
		name: "Bronze",
		kind: "chapa",
		line: "Bronze escuro. Pátina só num canto."
	},
	{
		id: 79,
		slug: "oleo",
		name: "Óleo",
		kind: "chapa",
		line: "Aço com véu de óleo e uma marca de dedo."
	},
	{
		id: 80,
		slug: "dedos",
		name: "Dedos",
		kind: "chapa",
		line: "As bordas escureceram de tanto toque."
	},
	{
		id: 81,
		slug: "uso",
		name: "Uso",
		kind: "chapa",
		line: "Centro mais claro. Os cantos já gastaram."
	},
	{
		id: 82,
		slug: "oxido",
		name: "Óxido",
		kind: "chapa",
		line: "Zinco com pontos brancos de oxidação."
	},
	{
		id: 83,
		slug: "patina",
		name: "Pátina",
		kind: "chapa",
		line: "Bronze com verde só na borda."
	},
	{
		id: 84,
		slug: "pinta",
		name: "Pinta",
		kind: "chapa",
		line: "Aço com pintas pequenas de ferrugem."
	},
	{
		id: 85,
		slug: "tempera",
		name: "Têmpera",
		kind: "chapa",
		line: "Aço queimado. Azul e marrom de calor."
	},
	{
		id: 86,
		slug: "sucata",
		name: "Sucata",
		kind: "chapa",
		line: "O mais usado: escuro, manchado, ferrugem na quina."
	},
	{
		id: 1,
		slug: "campo",
		name: "Campo",
		line: "Rádio de campo. O número em dBm é o herói."
	},
	{
		id: 2,
		slug: "sentenca",
		name: "Sentença",
		line: "Uma frase. O resto só aparece se você pedir."
	},
	{
		id: 3,
		slug: "cockpit",
		name: "Cockpit",
		line: "Quatro instrumentos. Nenhum protagoniza."
	},
	{
		id: 4,
		slug: "franquia",
		name: "Franquia",
		line: "O plano vem primeiro. O sinal é nota de rodapé."
	},
	{
		id: 5,
		slug: "pulso",
		name: "Pulso",
		line: "A latência desenhada ao longo dos minutos."
	},
	{
		id: 6,
		slug: "barras",
		name: "Barras",
		line: "As barrinhas ocupam a tela inteira."
	},
	{
		id: 7,
		slug: "diario",
		name: "Diário",
		line: "O dia da rede, escrito em ordem."
	},
	{
		id: 8,
		slug: "relogio",
		name: "Relógio",
		line: "Um arco, como instrumento de pulso."
	},
	{
		id: 9,
		slug: "cartoes",
		name: "Cartões",
		line: "Três cartões. Um assunto em cada."
	},
	{
		id: 10,
		slug: "faixa",
		name: "Faixa",
		line: "Uma linha de status. O detalhe fica embaixo."
	},
	{
		id: 11,
		slug: "orbita",
		name: "Órbita",
		line: "O sinal é um satélite girando em volta do número."
	},
	{
		id: 12,
		slug: "fosforo",
		name: "Fósforo",
		line: "Terminal de fósforo verde, com varredura de tela."
	},
	{
		id: 13,
		slug: "neon",
		name: "Neon",
		line: "Letreiro aceso. A rede como fachada de noite."
	},
	{
		id: 14,
		slug: "visor",
		name: "Visor",
		line: "HUD de capacete: cantos, mira e leitura fria."
	},
	{
		id: 15,
		slug: "ondas",
		name: "Ondas",
		line: "Três ondas de rádio, uma para cada medida."
	},
	{
		id: 16,
		slug: "selos",
		name: "Selos",
		line: "Um selo carimbado. A rede como correspondência."
	},
	{
		id: 17,
		slug: "ceu",
		name: "Céu",
		line: "Constelação. O ponto mais claro é o agora."
	},
	{
		id: 18,
		slug: "fita",
		name: "Fita",
		line: "Medidores de estúdio. O sinal sobe em segmentos."
	},
	{
		id: 19,
		slug: "grade",
		name: "Grade",
		line: "Uma cidade de células acesas conforme a rede."
	},
	{
		id: 20,
		slug: "luneta",
		name: "Luneta",
		line: "Tudo visto por uma lente redonda."
	},
	{
		id: 21,
		slug: "escovado",
		name: "Escovado",
		kind: "fundo",
		line: "Alumínio escovado, claro, como tampa de aparelho."
	},
	{
		id: 22,
		slug: "aco",
		name: "Aço",
		kind: "fundo",
		line: "Chapa de aço fosco, do tipo painel de instrumento."
	},
	{
		id: 23,
		slug: "anodizado",
		name: "Anodizado",
		kind: "fundo",
		line: "Alumínio anodizado preto, sem brilho de neon."
	},
	{
		id: 24,
		slug: "inox",
		name: "Inox",
		kind: "fundo",
		line: "Aço inoxidável escovado na diagonal."
	},
	{
		id: 25,
		slug: "jateado",
		name: "Jateado",
		kind: "fundo",
		line: "Alumínio jateado, fosco, sem direção de escova."
	},
	{
		id: 26,
		slug: "esmalte",
		name: "Esmalte",
		kind: "fundo",
		line: "Tinta eletrostática grafite, de chassi de equipamento."
	},
	{
		id: 27,
		slug: "fresagem",
		name: "Fresagem",
		kind: "fundo",
		line: "Alumínio escovado na vertical, com risco e reflexo de estúdio."
	},
	{
		id: 28,
		slug: "acovivo",
		name: "Aço vivo",
		kind: "fundo",
		line: "Aço laminado, grão fino e brilho de óleo."
	},
	{
		id: 29,
		slug: "negro",
		name: "Negro",
		kind: "fundo",
		line: "Alumínio anodizado preto, luz raspando a superfície."
	},
	{
		id: 30,
		slug: "espelho",
		name: "Espelho",
		kind: "fundo",
		line: "Inox escovado na diagonal, com reflexo do ambiente."
	},
	{
		id: 31,
		slug: "grao",
		name: "Grão",
		kind: "fundo",
		line: "Alumínio jateado, fosco, grão fechado."
	},
	{
		id: 32,
		slug: "chassi",
		name: "Chassi",
		kind: "fundo",
		line: "Tinta de equipamento, casca de laranja, emenda e parafusos."
	},
	{
		id: 33,
		slug: "liga",
		name: "Liga",
		kind: "fundo",
		line: "Inox do Espelho com a emenda e os parafusos do Chassi."
	},
	{
		id: 34,
		slug: "ferrugem",
		name: "Ferrugem",
		kind: "fundo",
		line: "Aço quase íntegro, com pequenas manchas de corrosão."
	},
	{
		id: 35,
		slug: "gasto",
		name: "Gasto",
		kind: "fundo",
		line: "Alumínio com risco, mancha fosca e oxidação na borda."
	},
	{
		id: 36,
		slug: "zinco",
		name: "Zinco",
		kind: "fundo",
		line: "Chapa galvanizada, corrosão pequena no canto."
	},
	{
		id: 37,
		slug: "parafusos",
		name: "Parafusos",
		kind: "fundo",
		line: "Placa grafite com quatro parafusos allen."
	},
	{
		id: 38,
		slug: "pregos",
		name: "Pregos",
		kind: "fundo",
		line: "Chapa clara com rebites e duas cabeças de prego."
	},
	{
		id: 39,
		slug: "fixacao",
		name: "Fixação",
		kind: "fundo",
		line: "Parafusos e um prego, com ferrugem só em volta deles."
	},
	{
		id: 40,
		slug: "torre",
		name: "Torre",
		kind: "botao",
		line: "Mastro com ondas no topo."
	},
	{
		id: 41,
		slug: "antena",
		name: "Antena",
		kind: "botao",
		line: "Haste única, como antena de rádio."
	},
	{
		id: 42,
		slug: "sinal",
		name: "Sinal",
		kind: "botao",
		line: "Barras crescendo. O sinal em pé."
	},
	{
		id: 43,
		slug: "onda",
		name: "Onda",
		kind: "botao",
		line: "Três arcos saindo de um ponto."
	},
	{
		id: 44,
		slug: "prato",
		name: "Medidor",
		kind: "botao",
		line: "Ponteiro de instrumento. É o ícone atual."
	},
	{
		id: 45,
		slug: "radar",
		name: "Radar",
		kind: "botao",
		line: "Círculo com um braço varrendo."
	},
	{
		id: 46,
		slug: "poste",
		name: "Poste",
		kind: "botao",
		line: "Torre de controle, mais larga que o mastro."
	},
	{
		id: 47,
		slug: "wifi",
		name: "Wi-fi",
		kind: "botao",
		line: "O arco familiar do Wi-fi."
	},
	{
		id: 48,
		slug: "radio",
		name: "Rádio",
		kind: "acordar",
		line: "O rádio de antes."
	},
	{
		id: 49,
		slug: "batida",
		name: "Pulso",
		kind: "acordar",
		line: "Linha de pulso. Diagnóstico."
	},
	{
		id: 50,
		slug: "esteto",
		name: "Esteto",
		kind: "acordar",
		line: "Estetoscópio. Ausculta a rede."
	},
	{
		id: 51,
		slug: "varredura",
		name: "Varredura",
		kind: "acordar",
		line: "Uma busca varrendo o sinal."
	},
	{
		id: 52,
		slug: "lente",
		name: "Lente",
		kind: "acordar",
		line: "Microscópio. Exame de perto."
	},
	{
		id: 53,
		slug: "medidor",
		name: "Prato",
		kind: "acordar",
		line: "Antena parabólica. É o ícone atual."
	},
	{
		id: 54,
		slug: "regua",
		name: "Régua",
		kind: "acordar",
		line: "Medida direta, em escala."
	},
	{
		id: 55,
		slug: "compasso",
		name: "Compasso",
		kind: "acordar",
		line: "Abre o arco e mede."
	},
	{
		id: 56,
		slug: "tubos",
		name: "Tubos",
		kind: "acordar",
		line: "Análise de laboratório."
	},
	{
		id: 57,
		slug: "brilho",
		name: "Brilho",
		kind: "efeito",
		line: "O número ganha um halo de fósforo."
	},
	{
		id: 58,
		slug: "cintilacao",
		name: "Cintilação",
		kind: "efeito",
		line: "O visor pisca leve, como um tubo cansado."
	},
	{
		id: 59,
		slug: "fantasma",
		name: "Fantasma",
		kind: "efeito",
		line: "Uma cópia fraca do texto, um pouco ao lado."
	},
	{
		id: 60,
		slug: "grao",
		name: "Grão",
		kind: "efeito",
		line: "Granulação fina sobre o vidro."
	},
	{
		id: 61,
		slug: "vinheta",
		name: "Vinheta",
		kind: "efeito",
		line: "Os cantos do visor escurecem."
	},
	{
		id: 62,
		slug: "reflexo",
		name: "Reflexo",
		kind: "efeito",
		line: "Um brilho de vidro atravessa o visor."
	},
	{
		id: 63,
		slug: "moldura",
		name: "Moldura",
		kind: "efeito",
		line: "A borda interna acende e apaga."
	},
	{
		id: 64,
		slug: "linhas",
		name: "Linhas",
		kind: "efeito",
		line: "As linhas do tubo ficam mais fortes e descem."
	},
	{
		id: 65,
		slug: "nucleo",
		name: "Núcleo",
		kind: "efeito",
		line: "Um clarão parado atrás do número."
	},
	{
		id: 66,
		slug: "poeira",
		name: "Poeira",
		kind: "efeito",
		line: "Pontos pequenos parados no vidro."
	},
	{
		id: 67,
		slug: "vidro",
		name: "Vidro",
		kind: "efeito",
		line: "Reflexo fixo de vidro curvo no topo."
	},
	{
		id: 68,
		slug: "quente",
		name: "Quente",
		kind: "efeito",
		line: "O centro mais claro e a borda mais escura."
	},
	{
		id: 69,
		slug: "batida",
		name: "Batida",
		kind: "efeito",
		line: "O visor inteiro respira em brilho."
	},
	{
		id: 70,
		slug: "eco",
		name: "Eco",
		kind: "efeito",
		line: "O texto se repete, cada vez mais fraco."
	},
	{
		id: 71,
		slug: "neblina",
		name: "Neblina",
		kind: "efeito",
		line: "Uma névoa leve por cima do vidro."
	},
	{
		id: 87,
		slug: "lenta",
		name: "Rede lenta",
		kind: "marca",
		line: "Ponteiro no começo do arco. A rede responde, mas arrasta."
	},
	{
		id: 88,
		slug: "ociosa",
		name: "Rede ociosa",
		kind: "marca",
		line: "Um ponto parado no círculo. A rede está no ar e não se move."
	},
	{
		id: 89,
		slug: "ociosa-1",
		name: "Ociosa 01 · Anel",
		kind: "marca",
		line: "Círculo vazio. Nada dentro."
	},
	{
		id: 90,
		slug: "ociosa-2",
		name: "Ociosa 02 · Ponto",
		kind: "marca",
		line: "Um ponto parado no meio do círculo."
	},
	{
		id: 91,
		slug: "ociosa-3",
		name: "Ociosa 03 · Traço",
		kind: "marca",
		line: "Um traço curto no centro. Repouso."
	},
	{
		id: 92,
		slug: "ociosa-4",
		name: "Ociosa 04 · Diâmetro",
		kind: "marca",
		line: "Uma linha atravessa o círculo e para."
	},
	{
		id: 93,
		slug: "ociosa-5",
		name: "Ociosa 05 · Pausa",
		kind: "marca",
		line: "Duas barras. A rede está em pausa."
	},
	{
		id: 94,
		slug: "ociosa-6",
		name: "Ociosa 06 · Lua",
		kind: "marca",
		line: "Uma lua. O rádio dorme."
	},
	{
		id: 95,
		slug: "ociosa-7",
		name: "Ociosa 07 · Pálpebra",
		kind: "marca",
		line: "Um olho fechado. Sem movimento."
	},
	{
		id: 96,
		slug: "ociosa-8",
		name: "Ociosa 08 · Nível",
		kind: "marca",
		line: "A bolha no centro. Nada pende."
	},
	{
		id: 97,
		slug: "ociosa-9",
		name: "Ociosa 09 · Ampulheta",
		kind: "marca",
		line: "O tempo parado no meio."
	},
	{
		id: 98,
		slug: "ociosa-10",
		name: "Ociosa 10 · Quadro",
		kind: "marca",
		line: "Um quadro vazio."
	},
	{
		id: 99,
		slug: "ociosa-11",
		name: "Ociosa 11 · Selo",
		kind: "marca",
		line: "Um ponto dentro do quadro."
	},
	{
		id: 100,
		slug: "ociosa-12",
		name: "Ociosa 12 · Linha",
		kind: "marca",
		line: "A onda virou um traço."
	},
	{
		id: 101,
		slug: "ociosa-13",
		name: "Ociosa 13 · Reticências",
		kind: "marca",
		line: "Três pontos parados."
	},
	{
		id: 102,
		slug: "ociosa-14",
		name: "Ociosa 14 · Tigela",
		kind: "marca",
		line: "Um arco deitado. Sem subir."
	},
	{
		id: 103,
		slug: "ociosa-15",
		name: "Ociosa 15 · Menos",
		kind: "marca",
		line: "Um menos dentro do círculo."
	},
	{
		id: 104,
		slug: "lenta-1",
		name: "Lenta 01 · Ponteiro",
		kind: "marca",
		line: "O ponteiro fica no começo do arco."
	},
	{
		id: 105,
		slug: "lenta-2",
		name: "Lenta 02 · Rastro",
		kind: "marca",
		line: "O ponto anda e deixa um rastro."
	},
	{
		id: 106,
		slug: "lenta-3",
		name: "Lenta 03 · Arco",
		kind: "marca",
		line: "Só o arco de baixo do sinal."
	},
	{
		id: 107,
		slug: "lenta-4",
		name: "Lenta 04 · Barras",
		kind: "marca",
		line: "A última barra não se completa."
	},
	{
		id: 108,
		slug: "lenta-5",
		name: "Lenta 05 · Descida",
		kind: "marca",
		line: "A linha desce e demora."
	},
	{
		id: 109,
		slug: "lenta-6",
		name: "Lenta 06 · Onda",
		kind: "marca",
		line: "Uma onda longa e rasa."
	},
	{
		id: 110,
		slug: "lenta-7",
		name: "Lenta 07 · Relógio",
		kind: "marca",
		line: "O ponteiro já passou da hora."
	},
	{
		id: 111,
		slug: "lenta-8",
		name: "Lenta 08 · Espaço",
		kind: "marca",
		line: "Os pontos se afastam."
	},
	{
		id: 112,
		slug: "lenta-9",
		name: "Lenta 09 · Freio",
		kind: "marca",
		line: "Um corte no fundo do círculo."
	},
	{
		id: 113,
		slug: "lenta-10",
		name: "Lenta 10 · Passo",
		kind: "marca",
		line: "Dois passos, longe um do outro."
	},
	{
		id: 114,
		slug: "lenta-11",
		name: "Lenta 11 · Cauda",
		kind: "marca",
		line: "Traços atrás do ponto."
	},
	{
		id: 115,
		slug: "lenta-12",
		name: "Lenta 12 · Ladeira",
		kind: "marca",
		line: "A descida termina num ponto."
	},
	{
		id: 116,
		slug: "lenta-13",
		name: "Lenta 13 · Meia",
		kind: "marca",
		line: "O arco não fecha."
	},
	{
		id: 117,
		slug: "lenta-14",
		name: "Lenta 14 · Elipse",
		kind: "marca",
		line: "O círculo esticado no tempo."
	},
	{
		id: 118,
		slug: "lenta-15",
		name: "Lenta 15 · Eco",
		kind: "marca",
		line: "O segundo círculo chega atrasado."
	},
	{
		id: 119,
		slug: "sono-1",
		name: "Sono 01 · Pilha",
		kind: "marca",
		line: "Z, zZ e zz subindo. O sono clássico."
	},
	{
		id: 120,
		slug: "sono-2",
		name: "Sono 02 · ZzZzz",
		kind: "marca",
		line: "A palavra ZzZzz, inclinada."
	},
	{
		id: 121,
		slug: "sono-3",
		name: "Sono 03 · Pálpebra",
		kind: "marca",
		line: "O olho fechado, com ZzZzz em cima."
	},
	{
		id: 122,
		slug: "sono-0",
		name: "Sono 00 · Dois Z",
		kind: "marca",
		line: "Dois Z sobrepostos, um maior que o outro."
	},
	{
		id: 123,
		slug: "zz-1",
		name: "Z 01 · Alto",
		kind: "marca",
		line: "O Z menor fica no alto, sobre o maior."
	},
	{
		id: 124,
		slug: "zz-2",
		name: "Z 02 · Centro",
		kind: "marca",
		line: "O Z menor cobre o meio do maior."
	},
	{
		id: 125,
		slug: "zz-3",
		name: "Z 03 · Baixo",
		kind: "marca",
		line: "O Z menor fica à esquerda, mais baixo."
	},
	{
		id: 126,
		slug: "zz-4",
		name: "Z 04 · Torto",
		kind: "marca",
		line: "O Z menor entra inclinado sobre o maior."
	},
	{
		id: 127,
		slug: "zz-5",
		name: "Z 05 · Frente",
		kind: "marca",
		line: "O Z da frente é o maior. O de trás fica atrás."
	},
	{
		id: 128,
		slug: "lua-1",
		name: "Lua 01 · Chapa",
		kind: "marca",
		line: "A lua minguante que está na chapa."
	},
	{
		id: 129,
		slug: "lua-2",
		name: "Lua 02 · Fina",
		kind: "marca",
		line: "Uma lasca fina, barriga à direita."
	},
	{
		id: 130,
		slug: "lua-3",
		name: "Lua 03 · Larga",
		kind: "marca",
		line: "Mais gorda, ainda minguante."
	},
	{
		id: 131,
		slug: "lua-4",
		name: "Lua 04 · Alta",
		kind: "marca",
		line: "A mesma lua, com as pontas mais altas."
	},
	{
		id: 132,
		slug: "lua-5",
		name: "Lua 05 · Contorno",
		kind: "marca",
		line: "Só o corte da lua, sem o miolo."
	}
];
var KEY$3 = "coil-place";
function memory$1() {
	try {
		return typeof localStorage === "undefined" ? null : localStorage;
	} catch {
		return null;
	}
}
function readBox$1() {
	const raw = memory$1()?.getItem(KEY$3);
	if (!raw) return null;
	try {
		const data = JSON.parse(raw);
		if (data?.status === "denied") return data;
		if (data?.status === "saved" && data.city && data.state) return data;
	} catch {}
	return null;
}
function startDates() {
	const day = /* @__PURE__ */ new Date();
	day.setDate(day.getDate() - 3);
	const y = day.getFullYear();
	const m = String(day.getMonth() + 1).padStart(2, "0");
	const d = String(day.getDate()).padStart(2, "0");
	return {
		start: `${y}-${m}-${d}`,
		startBr: `${d}/${m}/${y}`
	};
}
function readPlace() {
	const box = readBox$1();
	if (!box || box.status !== "saved") return null;
	const dates = startDates();
	const place = {
		city: box.city,
		state: box.state,
		uf: box.uf,
		start: dates.start,
		startBr: dates.startBr
	};
	if (typeof window !== "undefined") window.CoilPlace = place;
	return place;
}
async function ensurePlace() {
	if (typeof window === "undefined" || !navigator.geolocation) return;
	if (readPlace()) return;
	if (readBox$1()?.status === "denied") return;
	const outcome = await new Promise((resolve) => {
		navigator.geolocation.getCurrentPosition((pos) => resolve(pos), (error) => resolve(error.code === 1 ? "denied" : "later"), {
			enableHighAccuracy: false,
			timeout: 8e3,
			maximumAge: 3e5
		});
	});
	if (outcome === "denied") {
		memory$1()?.setItem(KEY$3, JSON.stringify({ status: "denied" }));
		return;
	}
	if (outcome === "later") return;
	try {
		const response = await fetch(`/api/place?lat=${outcome.coords.latitude}&lon=${outcome.coords.longitude}`, { cache: "no-store" });
		if (!response.ok) return;
		const data = await response.json();
		if (!data.city || !data.state) return;
		memory$1()?.setItem(KEY$3, JSON.stringify({
			status: "saved",
			city: data.city,
			state: data.state,
			uf: data.uf || ""
		}));
		readPlace();
	} catch {}
}
var KEY$2 = "coil-carrier";
function memory() {
	try {
		return typeof localStorage === "undefined" ? null : localStorage;
	} catch {
		return null;
	}
}
function readBox() {
	const raw = memory()?.getItem(KEY$2);
	if (!raw) return null;
	try {
		const data = JSON.parse(raw);
		if (data?.status === "denied") return data;
		if (data?.status === "saved" && data.name) return data;
	} catch {}
	return null;
}
function matchCarrier(raw) {
	const text = raw.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();
	if (text.includes("TIM") || text.includes("CORREIOS")) return "TIM";
	if (text.includes("CLARO")) return "CLARO";
	if (text.includes("VIVO") || text.includes("TELEFONICA")) return "VIVO";
	if (/(^|[^A-Z])OI([^A-Z]|$)/.test(text)) return "OI";
	if (text.includes("ALGAR")) return "ALGAR";
	if (text.includes("SERCOMTEL")) return "SERCOMTEL";
	if (text.includes("BRISANET")) return "BRISANET";
	return "";
}
function readCarrier() {
	const box = readBox();
	const name = box?.status === "saved" ? box.name : "";
	if (typeof window !== "undefined" && name) window.CoilCarrier = { name };
	return name;
}
function saveCarrier(raw) {
	const name = matchCarrier(raw);
	if (!name) return "";
	memory()?.setItem(KEY$2, JSON.stringify({
		status: "saved",
		name
	}));
	readCarrier();
	return name;
}
function denyCarrier() {
	memory()?.setItem(KEY$2, JSON.stringify({ status: "denied" }));
}
function ensureCarrier() {
	if (typeof window === "undefined") return;
	const host = window;
	host.CoilSaveCarrier = saveCarrier;
	host.CoilDenyCarrier = denyCarrier;
	if (readCarrier() || readBox()?.status === "denied") return;
	if (host.CoilNative?.carrier) {
		saveCarrier(host.CoilNative.carrier);
		return;
	}
	host.CoilNative?.requestCarrier?.();
}
var KEY$1 = "sinal-interface";
var FUNDO_KEY = "coil-fundo";
var BOTAO_KEY = "coil-botao";
var ACORDAR_KEY = "coil-acordar";
var EFEITO_KEY = "coil-efeito";
var CHAPA_KEY = "coil-chapa";
var DEFAULT_ID = 4;
var DEFAULT_FUNDO = 32;
var DEFAULT_BOTAO = 44;
var DEFAULT_ACORDAR = 53;
var DEFAULT_EFEITO = 60;
var DEFAULT_CHAPA = 81;
var CHAPA_PICK = "coil-chapa-pick";
var chosen = DEFAULT_ID;
var fundo$1 = DEFAULT_FUNDO;
var botao$1 = DEFAULT_BOTAO;
var acordar$1 = DEFAULT_ACORDAR;
var efeito = DEFAULT_EFEITO;
var chapa$1 = DEFAULT_CHAPA;
var listeners$1 = /* @__PURE__ */ new Set();
function emit$1() {
	listeners$1.forEach((listener) => listener());
}
function subscribeChoice(listener) {
	listeners$1.add(listener);
	return () => listeners$1.delete(listener);
}
function getChosen() {
	return chosen;
}
function getServerChosen() {
	return DEFAULT_ID;
}
function hasKind(id, kind) {
	return concepts.some((item) => item.id === id && "kind" in item && item.kind === kind);
}
function isFundo(id) {
	return hasKind(id, "fundo");
}
function isBotao(id) {
	return hasKind(id, "botao");
}
function isAcordar(id) {
	return hasKind(id, "acordar");
}
function isEfeito(id) {
	return hasKind(id, "efeito");
}
function isChapa(id) {
	return hasKind(id, "chapa");
}
function isMarca(id) {
	return hasKind(id, "marca");
}
function isTela(id) {
	return concepts.some((item) => item.id === id && !isFundo(id) && !isBotao(id) && !isAcordar(id) && !isEfeito(id) && !isChapa(id) && !isMarca(id));
}
function hydrateChoice() {
	const n = Number(localStorage.getItem(KEY$1));
	chosen = isTela(n) ? n : DEFAULT_ID;
	if (!isTela(n)) localStorage.setItem(KEY$1, String(DEFAULT_ID));
	const f = Number(localStorage.getItem(FUNDO_KEY));
	fundo$1 = isFundo(f) ? f : DEFAULT_FUNDO;
	const b = Number(localStorage.getItem(BOTAO_KEY));
	botao$1 = isBotao(b) ? b : DEFAULT_BOTAO;
	const a = Number(localStorage.getItem(ACORDAR_KEY));
	acordar$1 = isAcordar(a) ? a : DEFAULT_ACORDAR;
	const e = Number(localStorage.getItem(EFEITO_KEY));
	efeito = isEfeito(e) ? e : DEFAULT_EFEITO;
	const c = Number(localStorage.getItem(CHAPA_KEY));
	if (localStorage.getItem(CHAPA_PICK) !== "uso") {
		chapa$1 = DEFAULT_CHAPA;
		localStorage.setItem(CHAPA_KEY, String(DEFAULT_CHAPA));
		localStorage.setItem(CHAPA_PICK, "uso");
	} else {
		chapa$1 = isChapa(c) ? c : DEFAULT_CHAPA;
		if (!isChapa(c)) localStorage.setItem(CHAPA_KEY, String(DEFAULT_CHAPA));
	}
	emit$1();
}
function chooseConcept(id) {
	if (isFundo(id)) {
		fundo$1 = id;
		localStorage.setItem(FUNDO_KEY, String(id));
		emit$1();
		return;
	}
	if (isBotao(id)) {
		botao$1 = id;
		localStorage.setItem(BOTAO_KEY, String(id));
		emit$1();
		return;
	}
	if (isAcordar(id)) {
		acordar$1 = id;
		localStorage.setItem(ACORDAR_KEY, String(id));
		emit$1();
		return;
	}
	if (isEfeito(id)) {
		efeito = id;
		localStorage.setItem(EFEITO_KEY, String(id));
		emit$1();
		return;
	}
	if (isChapa(id)) {
		chapa$1 = id;
		localStorage.setItem(CHAPA_KEY, String(id));
		emit$1();
		return;
	}
	if (isMarca(id)) return;
	chosen = id;
	localStorage.setItem(KEY$1, String(id));
	emit$1();
}
function useChosen() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, getChosen, getServerChosen);
}
function useBackground() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, () => fundo$1, () => DEFAULT_FUNDO);
}
function useButton() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, () => botao$1, () => DEFAULT_BOTAO);
}
function useWakeIcon() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, () => acordar$1, () => DEFAULT_ACORDAR);
}
function useVisorEffect() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, () => efeito, () => DEFAULT_EFEITO);
}
function useChapa() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, () => chapa$1, () => DEFAULT_CHAPA);
}
function useRandomFlicker(active = true) {
	const [ms, setMs] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!active) return;
		let alive = true;
		let timer = 0;
		const play = () => {
			if (!alive) return;
			const dur = 1700 + Math.random() * 700;
			setMs(dur);
			timer = window.setTimeout(() => {
				if (!alive) return;
				setMs(null);
				timer = window.setTimeout(play, 250 + Math.random() * 3250);
			}, dur);
		};
		timer = window.setTimeout(play, 250 + Math.random() * 3250);
		return () => {
			alive = false;
			window.clearTimeout(timer);
		};
	}, [active]);
	return ms;
}
function WifiGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		width: "16",
		height: "16",
		fill: "none",
		stroke: "currentColor",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M3.8 8.2c2.1-2.5 5-3.9 8.2-3.9s6.1 1.4 8.2 3.9"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M6.7 11.5c1.4-1.6 3.3-2.5 5.3-2.5s3.9.9 5.3 2.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M9.4 14.6c.7-.7 1.6-1.1 2.6-1.1s1.9.4 2.6 1.1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "18.4",
				r: "1.25",
				fill: "currentColor",
				stroke: "none"
			})
		]
	});
}
function CellGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		width: "16",
		height: "16",
		fill: "none",
		stroke: "currentColor",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M8.1 19.4V7.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M8.1 4.7 5.2 8.1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M8.1 4.7 11 8.1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M15.9 4.6v11.9"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M15.9 19.3 13 15.9"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M15.9 19.3 18.8 15.9"
			})
		]
	});
}
function CableGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		width: "16",
		height: "16",
		fill: "none",
		stroke: "currentColor",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "17.4",
				y: "3.8",
				width: "3.1",
				height: "2.9",
				rx: "0.4",
				fill: "currentColor",
				stroke: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M17.4 5.25h-2.8C9.4 5.25 9.2 9.2 13.2 10.6 16.9 11.9 16.7 16.1 12.1 16.7H6.6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3.5",
				y: "15.25",
				width: "3.1",
				height: "2.9",
				rx: "0.4",
				fill: "currentColor",
				stroke: "none"
			})
		]
	});
}
function BtGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		width: "16",
		height: "16",
		fill: "none",
		stroke: "currentColor",
		strokeLinecap: "square",
		strokeLinejoin: "miter",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			strokeWidth: "2",
			d: "M6.6 6.8 17 16.4 12 20.8V3.2l5 4.4L6.6 17.2"
		})
	});
}
function UpArrowGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		width: "16",
		height: "16",
		fill: "none",
		stroke: "currentColor",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			strokeWidth: "2",
			d: "M12 19.2V7.2"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			strokeWidth: "2",
			d: "M7.2 11.4 12 5.6l4.8 5.8"
		})]
	});
}
function DownArrowGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		width: "16",
		height: "16",
		fill: "none",
		stroke: "currentColor",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			strokeWidth: "2",
			d: "M12 4.8v12"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			strokeWidth: "2",
			d: "M7.2 12.6 12 18.4l4.8-5.8"
		})]
	});
}
function BoltGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		width: "16",
		height: "16",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: "M13.4 2.2 5.2 13.6h5.4l-1.5 8.2 8.7-12.2h-5.6l1.2-7.4z"
		})
	});
}
function WaneGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		width: "16",
		height: "16",
		fill: "none",
		stroke: "currentColor",
		strokeLinejoin: "round",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			strokeWidth: "2",
			d: "M7.2 4.2C8.8 6.5 9.7 9.1 9.7 12s-.9 5.5-2.5 7.8C11.6 20.6 16.8 16.8 16.8 12S11.6 3.4 7.2 4.2z"
		})
	});
}
function MoonMark({ size = 22, n }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		width: size,
		height: size,
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: n === 2 ? "M11.2 5.4C12.6 7.2 13.4 9.5 13.4 12s-.8 4.8-2.2 6.6C14.4 19.4 17.6 16.2 17.6 12S14.4 4.6 11.2 5.4z" : n === 3 ? "M5.2 4.4C7.6 6.8 9.2 9.2 9.2 12s-1.6 5.2-4 7.6C10.2 21.2 18.4 17.2 18.4 12S10.2 2.8 5.2 4.4z" : "M7.2 4.2C8.8 6.5 9.7 9.1 9.7 12s-.9 5.5-2.5 7.8C11.6 20.6 16.8 16.8 16.8 12S11.6 3.4 7.2 4.2z",
			transform: n === 4 ? "rotate(-18 12 12)" : void 0,
			fill: n === 5 ? "none" : "currentColor",
			stroke: n === 5 ? "currentColor" : "none",
			strokeWidth: n === 5 ? 1.6 : void 0,
			strokeLinejoin: "round"
		})
	});
}
function SlowGlyph({ size = 16 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		width: size,
		height: size,
		fill: "none",
		stroke: "currentColor",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M4.6 16.2a8 8 0 0 1 14.8 0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M12 16.2 7.6 13.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "16.2",
				r: "1.2",
				fill: "currentColor",
				stroke: "none"
			})
		]
	});
}
function IdleMark({ size = 22, n }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		width: size,
		height: size,
		fill: "none",
		stroke: "currentColor",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": true,
		children: [
			n === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "7.2",
				strokeWidth: "2"
			}) : null,
			n === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "7.2",
				strokeWidth: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "1.35",
				fill: "currentColor",
				stroke: "none"
			})] }) : null,
			n === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "7.2",
				strokeWidth: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M9 12h6"
			})] }) : null,
			n === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "7.2",
				strokeWidth: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M4.8 12h14.4"
			})] }) : null,
			n === 5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M8 5.5v13"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M16 5.5v13"
			})] }) : null,
			n === 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M15.2 5a6.8 6.8 0 1 0 0 14"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M15.2 5a4.4 4.4 0 0 1 0 14"
			})] }) : null,
			n === 7 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M4.8 13.2c2.3-3.4 4.6-5 7.2-5s4.9 1.6 7.2 5"
			}) : null,
			n === 8 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3.2",
				y: "9",
				width: "17.6",
				height: "6",
				rx: "3",
				strokeWidth: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "1.25",
				fill: "currentColor",
				stroke: "none"
			})] }) : null,
			n === 9 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M7.2 4.4h9.6M7.2 19.6h9.6"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M8 4.4c0 3.8 4 5 4 7.6s-4 3.8-4 7.6M16 4.4c0 3.8-4 5-4 7.6s4 3.8 4 7.6"
			})] }) : null,
			n === 10 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "5",
				y: "5",
				width: "14",
				height: "14",
				rx: "2.2",
				strokeWidth: "2"
			}) : null,
			n === 11 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "5",
				y: "5",
				width: "14",
				height: "14",
				rx: "2.2",
				strokeWidth: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "1.3",
				fill: "currentColor",
				stroke: "none"
			})] }) : null,
			n === 12 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M3.5 14.5h11"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "17.2",
				cy: "14.5",
				r: "1.3",
				fill: "currentColor",
				stroke: "none"
			})] }) : null,
			n === 13 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "6",
					cy: "12",
					r: "1.25",
					fill: "currentColor",
					stroke: "none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "12",
					cy: "12",
					r: "1.25",
					fill: "currentColor",
					stroke: "none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "18",
					cy: "12",
					r: "1.25",
					fill: "currentColor",
					stroke: "none"
				})
			] }) : null,
			n === 14 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M4.6 10.2a7.4 7.4 0 0 0 14.8 0"
			}) : null,
			n === 15 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "7.2",
				strokeWidth: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M8.2 12h7.6"
			})] }) : null
		]
	});
}
function SlowMark({ size = 22, n }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		width: size,
		height: size,
		fill: "none",
		stroke: "currentColor",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": true,
		children: [
			n === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					strokeWidth: "2",
					d: "M4.6 16.2a8 8 0 0 1 14.8 0"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					strokeWidth: "2",
					d: "M12 16.2 7.6 13.4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "12",
					cy: "16.2",
					r: "1.15",
					fill: "currentColor",
					stroke: "none"
				})
			] }) : null,
			n === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M3.5 12h9"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16.2",
				cy: "12",
				r: "1.7",
				fill: "currentColor",
				stroke: "none"
			})] }) : null,
			n === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M7.2 14.8c1.4-1.6 3-2.4 4.8-2.4s3.4.8 4.8 2.4"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "18.2",
				r: "1.2",
				fill: "currentColor",
				stroke: "none"
			})] }) : null,
			n === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					strokeWidth: "2",
					d: "M6 17v-3"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					strokeWidth: "2",
					d: "M12 17V9"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					strokeWidth: "2",
					d: "M18 17v-1.2",
					strokeDasharray: "1.6 1.8"
				})
			] }) : null,
			n === 5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M5 7.5 19 16.5"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "19",
				cy: "16.5",
				r: "1.2",
				fill: "currentColor",
				stroke: "none"
			})] }) : null,
			n === 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M3 14c2.2-1.2 3.2-1.2 4.6 0s2.6 1.2 4.8 0 2.4-1.2 4.6 0 2.4 1.2 4 0"
			}) : null,
			n === 7 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "7.2",
				strokeWidth: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M12 12 15.4 15.6"
			})] }) : null,
			n === 8 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "5",
					cy: "12",
					r: "1.15",
					fill: "currentColor",
					stroke: "none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "11",
					cy: "12",
					r: "1.15",
					fill: "currentColor",
					stroke: "none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "19",
					cy: "12",
					r: "1.15",
					fill: "currentColor",
					stroke: "none"
				})
			] }) : null,
			n === 9 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "7.2",
				strokeWidth: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M6.2 16.4h11.6"
			})] }) : null,
			n === 10 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M6 6.5v11"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M18 6.5v11"
			})] }) : null,
			n === 11 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M4 12h2.2M8.2 12h2.2M12.4 12h2.2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18.4",
				cy: "12",
				r: "1.25",
				fill: "currentColor",
				stroke: "none"
			})] }) : null,
			n === 12 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M4.5 7.5 16.5 16.5"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "17.6",
				cy: "17.2",
				r: "1.2",
				fill: "currentColor",
				stroke: "none"
			})] }) : null,
			n === 13 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				strokeWidth: "2",
				d: "M4.2 9.2c2.2 2.6 4.8 4 7.8 4"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "15.6",
				cy: "13.2",
				r: "1.2",
				fill: "currentColor",
				stroke: "none"
			})] }) : null,
			n === 14 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "12",
				cy: "12",
				rx: "8.2",
				ry: "4.2",
				strokeWidth: "2"
			}) : null,
			n === 15 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "8.2",
					cy: "12",
					r: "3.2",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					strokeWidth: "2",
					d: "M11.4 12h4.2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "17.6",
					cy: "12",
					r: "1.7",
					strokeWidth: "2"
				})
			] }) : null
		]
	});
}
function SleepMark({ size = 22, n }) {
	const letter = {
		fill: "currentColor",
		stroke: "none",
		fontFamily: "Georgia, 'Times New Roman', serif",
		fontWeight: 700
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		width: size,
		height: size,
		"aria-hidden": true,
		children: [
			n === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "1.2",
					y: "21",
					fontSize: "9",
					...letter,
					children: "Z"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "8.2",
					y: "14.5",
					fontSize: "7",
					...letter,
					children: "zZ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "14.6",
					y: "8",
					fontSize: "5",
					...letter,
					children: "zz"
				})
			] }) : null,
			n === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "12",
				y: "14.5",
				fontSize: "6.4",
				textAnchor: "middle",
				transform: "rotate(-12 12 12)",
				...letter,
				children: "ZzZzz"
			}) : null,
			n === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M3.2 16.6c2.6-3.2 5-4.6 8.8-4.6s6.2 1.4 8.8 4.6",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.7",
				strokeLinecap: "round"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "13.5",
				y: "9.2",
				fontSize: "4.6",
				textAnchor: "middle",
				...letter,
				children: "ZzZzz"
			})] }) : null,
			n === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "2",
				y: "20",
				fontSize: "16",
				...letter,
				children: "Z"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "10",
				y: "13",
				fontSize: "9",
				...letter,
				children: "Z"
			})] }) : null,
			n === 5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "1",
				y: "21",
				fontSize: "18",
				...letter,
				children: "Z"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "11",
				y: "12",
				fontSize: "8",
				...letter,
				children: "Z"
			})] }) : null,
			n === 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "3",
				y: "19",
				fontSize: "15",
				...letter,
				children: "Z"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "8",
				y: "15",
				fontSize: "10",
				...letter,
				children: "Z"
			})] }) : null,
			n === 7 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "4",
				y: "18",
				fontSize: "14",
				...letter,
				children: "Z"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "2",
				y: "14",
				fontSize: "8",
				...letter,
				children: "Z"
			})] }) : null,
			n === 8 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "2",
				y: "19",
				fontSize: "15",
				...letter,
				children: "Z"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "12",
				y: "14",
				fontSize: "9",
				transform: "rotate(-16 15 12)",
				...letter,
				children: "Z"
			})] }) : null,
			n === 9 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "5",
				y: "18",
				fontSize: "12",
				opacity: "0.55",
				...letter,
				children: "Z"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "8",
				y: "16",
				fontSize: "14",
				...letter,
				children: "Z"
			})] }) : null
		]
	});
}
function SegNum({ value }) {
	const comma = value.indexOf(",");
	if (comma < 0) return value;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		value.slice(0, comma).replaceAll(".", ""),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
			className: "seg-dec",
			children: ","
		}),
		value.slice(comma + 1)
	] });
}
function segLong(value) {
	return value.replace(/\D/g, "").length >= 5;
}
function Shell({ slug, chrome, children, bare, live, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: `concept concept-${slug} ${chrome ? "concept-chrome" : ""} ${live ? "concept-live" : ""} ${tone ? `bg-${tone}` : ""} ${bare ? "" : "px-5 pb-28 pt-5"}`,
		children
	});
}
function Kicker({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "c-muted text-xs tracking-widest uppercase",
		children
	});
}
function Campo({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "campo",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: [
				"Campo · ",
				snapshot.carrier,
				" ",
				snapshot.tech
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto mt-10 grid h-56 w-56 place-items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 200 200",
					className: "absolute inset-0 h-full w-full",
					"aria-hidden": true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "92",
							className: "ring ring-dim"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "68",
							className: "ring ring-dim"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "44",
							className: "ring ring-hot"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-accent text-5xl leading-none tabular-nums",
						children: snapshot.dbm
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted mt-1 text-xs tracking-widest",
						children: "dBm"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-10 grid grid-cols-3 gap-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted text-xs",
						children: "Desce"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-lg tabular-nums",
						children: br(snapshot.down)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted text-xs",
						children: "Sobe"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-lg tabular-nums",
						children: br(snapshot.up)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted text-xs",
						children: "Ping"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-lg tabular-nums",
						children: snapshot.ping
					})] })
				]
			})
		]
	});
}
function Sentenca({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "sentenca",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: snapshot.place }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 text-6xl leading-none tracking-tight",
				children: "Sinal bom."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-6 max-w-xs text-2xl leading-snug",
				children: [
					snapshot.carrier,
					" ",
					snapshot.tech,
					", ",
					snapshot.dbm,
					" dBm."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "c-rule mt-16 grid grid-cols-3 gap-4 border-t pt-5 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted",
						children: "Ping"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 tabular-nums",
						children: [snapshot.ping, " ms"]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted",
						children: "Desce"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 tabular-nums",
						children: br(snapshot.down)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted",
						children: "Plano"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 tabular-nums",
						children: [br(snapshot.usedGb), " GB"]
					})] })
				]
			})
		]
	});
}
function Cockpit({ chrome }) {
	const tiles = [
		{
			k: "Sinal",
			v: `${snapshot.bars}/4`,
			u: `${snapshot.dbm} dBm`
		},
		{
			k: "Ping",
			v: String(snapshot.ping),
			u: "ms"
		},
		{
			k: "Desce",
			v: br(snapshot.down),
			u: "Mb/s"
		},
		{
			k: "Sobe",
			v: br(snapshot.up),
			u: "Mb/s"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "cockpit",
		chrome,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Cockpit · ", snapshot.tech] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 grid grid-cols-2 gap-3",
			children: tiles.map((tile) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "c-surface rounded-xl px-3 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted text-xs tracking-widest uppercase",
						children: tile.k
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-accent mt-3 text-4xl leading-none tabular-nums",
						children: tile.v
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted mt-2 text-xs",
						children: tile.u
					})
				]
			}, tile.k))
		})]
	});
}
function useSweepPass() {
	const [pass, setPass] = (0, import_react.useState)(0);
	const running = (0, import_react.useRef)(false);
	const again = (0, import_react.useRef)(false);
	const active = (0, import_react.useRef)(0);
	const finish = (ticket) => {
		if (ticket !== active.current) return;
		active.current = 0;
		if (again.current) {
			again.current = false;
			const next = ticket + 1;
			active.current = next;
			running.current = true;
			setPass(next);
			window.setTimeout(() => finish(next), 1200);
			return;
		}
		running.current = false;
		setPass(0);
	};
	return {
		pass,
		poke: (0, import_react.useCallback)(() => {
			if (running.current) {
				again.current = true;
				return;
			}
			running.current = true;
			again.current = false;
			const ticket = active.current + 1 || 1;
			active.current = ticket;
			setPass(ticket);
			window.setTimeout(() => finish(ticket), 1200);
		}, []),
		done: (0, import_react.useCallback)((ticket) => {
			finish(ticket);
		}, []),
		clear: (0, import_react.useCallback)(() => {
			active.current = 0;
			running.current = false;
			again.current = false;
			setPass(0);
		}, [])
	};
}
var PlateLamps = (0, import_react.memo)(function PlateLamps() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "lamp-cut",
		"aria-hidden": "true",
		width: "0",
		height: "0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
				id: "visor-lamp",
				filterUnits: "objectBoundingBox",
				primitiveUnits: "userSpaceOnUse",
				x: "-1.6",
				y: "-1.6",
				width: "4.2",
				height: "4.2",
				colorInterpolationFilters: "sRGB",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "SourceAlpha",
						stdDeviation: "1.4",
						result: "b1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 190, 90)",
						result: "c1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "c1",
						in2: "b1",
						operator: "in",
						result: "g1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "SourceAlpha",
						stdDeviation: "3",
						result: "b2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 110, 20)",
						floodOpacity: "0.4",
						result: "c2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "c2",
						in2: "b2",
						operator: "in",
						result: "g2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("feMerge", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "g2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "g1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "SourceGraphic" })
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
				id: "visor-carved",
				filterUnits: "objectBoundingBox",
				primitiveUnits: "userSpaceOnUse",
				x: "-1.6",
				y: "-1.6",
				width: "4.2",
				height: "4.2",
				colorInterpolationFilters: "sRGB",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "SourceAlpha",
						stdDeviation: "1.6",
						result: "b1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 190, 90)",
						result: "c1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "c1",
						in2: "b1",
						operator: "in",
						result: "g1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "SourceAlpha",
						stdDeviation: "3.4",
						result: "b2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 110, 20)",
						floodOpacity: "0.4",
						result: "c2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "c2",
						in2: "b2",
						operator: "in",
						result: "g2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feOffset", {
						in: "SourceAlpha",
						dx: "1.55",
						dy: "1.65",
						result: "shift"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shift",
						in2: "SourceAlpha",
						operator: "out",
						result: "lipA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 248, 236)",
						floodOpacity: "0.78",
						result: "lipC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "lipC",
						in2: "lipA",
						operator: "in",
						result: "lip"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feOffset", {
						in: "SourceAlpha",
						dx: "-1.4",
						dy: "-1.4",
						result: "shift2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shift2",
						in2: "SourceAlpha",
						operator: "out",
						result: "shadeA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "#000",
						floodOpacity: "0.8",
						result: "shadeC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shadeC",
						in2: "shadeA",
						operator: "in",
						result: "shade"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("feMerge", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "g2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "g1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "shade" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "lip" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "SourceGraphic" })
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
				id: "net-well",
				filterUnits: "objectBoundingBox",
				primitiveUnits: "userSpaceOnUse",
				x: "-1.6",
				y: "-1.6",
				width: "4.2",
				height: "4.2",
				colorInterpolationFilters: "sRGB",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feOffset", {
						in: "SourceAlpha",
						dx: "-1.25",
						dy: "-1.15",
						result: "shadeShift"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "shadeShift",
						stdDeviation: "0.4",
						result: "shadeBlur"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shadeBlur",
						in2: "SourceAlpha",
						operator: "out",
						result: "shadeA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "#070504",
						floodOpacity: "0.92",
						result: "shadeC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shadeC",
						in2: "shadeA",
						operator: "in",
						result: "shade"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feOffset", {
						in: "SourceAlpha",
						dx: "1.2",
						dy: "1.25",
						result: "lipShift"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "lipShift",
						stdDeviation: "0.28",
						result: "lipBlur"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "lipBlur",
						in2: "SourceAlpha",
						operator: "out",
						result: "lipA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 248, 236)",
						floodOpacity: "0.88",
						result: "lipC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "lipC",
						in2: "lipA",
						operator: "in",
						result: "lip"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "#140e0a",
						floodOpacity: "0.62",
						result: "floorC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "floorC",
						in2: "SourceAlpha",
						operator: "in",
						result: "floor"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("feMerge", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "shade" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "floor" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "lip" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "SourceGraphic" })
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
				id: "net-well-led",
				filterUnits: "objectBoundingBox",
				primitiveUnits: "userSpaceOnUse",
				x: "-2.2",
				y: "-2.2",
				width: "5.4",
				height: "5.4",
				colorInterpolationFilters: "sRGB",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "SourceAlpha",
						stdDeviation: "1.4",
						result: "b1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 190, 90)",
						result: "c1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "c1",
						in2: "b1",
						operator: "in",
						result: "g1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "SourceAlpha",
						stdDeviation: "3",
						result: "b2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 110, 20)",
						floodOpacity: "0.4",
						result: "c2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "c2",
						in2: "b2",
						operator: "in",
						result: "g2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feOffset", {
						in: "SourceAlpha",
						dx: "-1.05",
						dy: "-0.95",
						result: "shadeShift"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "shadeShift",
						stdDeviation: "0.35",
						result: "shadeBlur"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shadeBlur",
						in2: "SourceAlpha",
						operator: "out",
						result: "shadeA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "#2a1008",
						floodOpacity: "0.72",
						result: "shadeC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shadeC",
						in2: "shadeA",
						operator: "in",
						result: "shade"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feOffset", {
						in: "SourceAlpha",
						dx: "1.05",
						dy: "1.1",
						result: "lipShift"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "lipShift",
						stdDeviation: "0.22",
						result: "lipBlur"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "lipBlur",
						in2: "SourceAlpha",
						operator: "out",
						result: "lipA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 236, 206)",
						floodOpacity: "0.55",
						result: "lipC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "lipC",
						in2: "lipA",
						operator: "in",
						result: "lip"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("feMerge", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "g2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "g1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "shade" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "lip" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "SourceGraphic" })
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
				id: "net-groove",
				filterUnits: "objectBoundingBox",
				primitiveUnits: "userSpaceOnUse",
				x: "-1.2",
				y: "-1.2",
				width: "3.4",
				height: "3.4",
				colorInterpolationFilters: "sRGB",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feOffset", {
						in: "SourceAlpha",
						dx: "0.7",
						dy: "0.75",
						result: "lipShift"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "lipShift",
						in2: "SourceAlpha",
						operator: "out",
						result: "lipA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 250, 242)",
						floodOpacity: "0.72",
						result: "lipC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "lipC",
						in2: "lipA",
						operator: "in",
						result: "lip"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feOffset", {
						in: "SourceAlpha",
						dx: "-0.65",
						dy: "-0.6",
						result: "shadeShift"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shadeShift",
						in2: "SourceAlpha",
						operator: "out",
						result: "shadeA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "#120c08",
						floodOpacity: "0.8",
						result: "shadeC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shadeC",
						in2: "shadeA",
						operator: "in",
						result: "shade"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("feMerge", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "shade" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "lip" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "SourceGraphic" })
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
				id: "net-led",
				filterUnits: "objectBoundingBox",
				primitiveUnits: "userSpaceOnUse",
				x: "-2.2",
				y: "-2.2",
				width: "5.4",
				height: "5.4",
				colorInterpolationFilters: "sRGB",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "SourceAlpha",
						stdDeviation: "1.4",
						result: "b1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 190, 90)",
						result: "c1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "c1",
						in2: "b1",
						operator: "in",
						result: "g1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						in: "SourceAlpha",
						stdDeviation: "3",
						result: "b2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 110, 20)",
						floodOpacity: "0.4",
						result: "c2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "c2",
						in2: "b2",
						operator: "in",
						result: "g2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feOffset", {
						in: "SourceAlpha",
						dx: "0.55",
						dy: "0.6",
						result: "lipShift"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "lipShift",
						in2: "SourceAlpha",
						operator: "out",
						result: "lipA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "rgb(255, 244, 220)",
						floodOpacity: "0.5",
						result: "lipC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "lipC",
						in2: "lipA",
						operator: "in",
						result: "lip"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feOffset", {
						in: "SourceAlpha",
						dx: "-0.45",
						dy: "-0.45",
						result: "shadeShift"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shadeShift",
						in2: "SourceAlpha",
						operator: "out",
						result: "shadeA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFlood", {
						floodColor: "#3a1408",
						floodOpacity: "0.45",
						result: "shadeC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feComposite", {
						in: "shadeC",
						in2: "shadeA",
						operator: "in",
						result: "shade"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("feMerge", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "g2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "g1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "shade" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "lip" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "SourceGraphic" })
					] })
				]
			})
		]
	});
});
function Franquia({ chrome, actions }) {
	const fundo = useBackground();
	const botao = useButton();
	const acordar = useWakeIcon();
	const efeito = useVisorEffect();
	const chapa = useChapa();
	const RedoIcon = redoIcons[botao] ?? RadioTower;
	const WakeIcon = wakeIcons[acordar] ?? Radio;
	const tone = concepts.find((item) => item.id === fundo)?.slug;
	const efeitoClass = efeito ? `efeito-${concepts.find((item) => item.id === efeito)?.slug ?? ""}` : "";
	const chapaClass = chapa ? `chapa-${concepts.find((item) => item.id === chapa)?.slug ?? ""}` : "";
	const [link, setLink] = (0, import_react.useState)(null);
	const [dnsMs, setDnsMs] = (0, import_react.useState)(null);
	const [dnsWait, setDnsWait] = (0, import_react.useState)(false);
	const [dbm, setDbm] = (0, import_react.useState)(null);
	const [flow, setFlow] = (0, import_react.useState)({
		up: false,
		down: false
	});
	const [reading, setReading] = (0, import_react.useState)("idle");
	const [poking, setPoking] = (0, import_react.useState)(false);
	const runRef = (0, import_react.useRef)(false);
	const medirHeld = (0, import_react.useRef)(false);
	const wakeHeld = (0, import_react.useRef)(false);
	const pokingRef = (0, import_react.useRef)(false);
	const resettingRef = (0, import_react.useRef)(false);
	const queueRef = (0, import_react.useRef)([]);
	const shownRef = (0, import_react.useRef)({
		state: "Pronto",
		doing: "Carregando bobina..."
	});
	const shownAtRef = (0, import_react.useRef)(performance.now());
	const closingRef = (0, import_react.useRef)(false);
	const timerRef = (0, import_react.useRef)(null);
	const holdRef = (0, import_react.useRef)(false);
	const litRef = (0, import_react.useRef)(false);
	const tuneRef = (0, import_react.useRef)(false);
	const [shown, setShown] = (0, import_react.useState)(shownRef.current);
	const visorFx = efeitoClass === "efeito-grao" && shown.doing === "Carregando bobina..." ? "" : efeitoClass;
	const [fadeKey, setFadeKey] = (0, import_react.useState)(0);
	const [lit, setLit] = (0, import_react.useState)(false);
	const downSweep = useSweepPass();
	const sideSweep = useSweepPass();
	const execSweep = useSweepPass();
	const diagSweep = useSweepPass();
	const [tune, setTune] = (0, import_react.useState)(false);
	const [diagLines, setDiagLines] = (0, import_react.useState)([{
		id: 1,
		text: "Coil Jitter Off-line",
		at: 0,
		keep: true
	}]);
	const [diagKey, setDiagKey] = (0, import_react.useState)(0);
	const [online, setOnline] = (0, import_react.useState)(true);
	const [lane, setLane] = (0, import_react.useState)(null);
	const laneRef = (0, import_react.useRef)(null);
	const gateRef = (0, import_react.useRef)(null);
	const vpnRef = (0, import_react.useRef)(false);
	const noticeRef = (0, import_react.useRef)("");
	const towerRef = (0, import_react.useRef)("");
	const signalRef = (0, import_react.useRef)("");
	const [mark, setMark] = (0, import_react.useState)("off");
	const markRef = (0, import_react.useRef)(null);
	const diagQueue = (0, import_react.useRef)([]);
	const diagTimer = (0, import_react.useRef)(null);
	const diagLinesRef = (0, import_react.useRef)([{
		id: 1,
		text: "Coil Jitter Off-line",
		at: 0,
		keep: true
	}]);
	const diagSeq = (0, import_react.useRef)(1);
	const diagScroll = (0, import_react.useRef)(null);
	const flick = useRandomFlicker();
	const deadRef = (0, import_react.useRef)(faultDead());
	const [dead, setDead] = (0, import_react.useState)(deadRef.current);
	const [quiet, setQuiet] = (0, import_react.useState)(false);
	const [resetting, setResetting] = (0, import_react.useState)(false);
	function playDiag() {
		if (diagTimer.current !== null) return;
		const next = diagQueue.current.shift();
		if (!next) return;
		const lines = [{
			id: ++diagSeq.current,
			text: next,
			at: performance.now()
		}, ...diagLinesRef.current];
		diagLinesRef.current = lines;
		setDiagLines(lines);
		setDiagKey((n) => n + 1);
		diagTimer.current = window.setTimeout(() => {
			diagTimer.current = null;
			playDiag();
		}, 1800);
	}
	function showCoil(text) {
		const current = diagLinesRef.current;
		const index = current.findIndex((line) => line.text === "Coil Jitter Off-line" || line.text === "Coil Jitter On-line");
		if (index >= 0 && current[index].text === text) return;
		const line = {
			id: index >= 0 ? current[index].id : ++diagSeq.current,
			text,
			at: 0,
			keep: true
		};
		const lines = index >= 0 ? current.map((item, i) => i === index ? line : item) : [line, ...current];
		diagLinesRef.current = lines;
		setDiagLines(lines);
	}
	function clearDiag() {
		diagQueue.current = [];
		if (diagTimer.current !== null) {
			window.clearTimeout(diagTimer.current);
			diagTimer.current = null;
		}
		diagLinesRef.current = [];
		setDiagLines([]);
	}
	function tell(line) {
		if (resettingRef.current) return;
		if ((diagQueue.current.at(-1) ?? diagLinesRef.current[0]?.text) === line) return;
		diagQueue.current.push(line);
		playDiag();
	}
	function tellNow(line) {
		diagQueue.current = [];
		if (diagTimer.current !== null) {
			window.clearTimeout(diagTimer.current);
			diagTimer.current = null;
		}
		tell(line);
	}
	function applyMark(busy) {
		if (resettingRef.current) return;
		const next = linkMark(busy);
		if (markRef.current === next) return;
		markRef.current = next;
		setMark(next);
	}
	(0, import_react.useEffect)(() => {
		let rx = 0;
		let tx = 0;
		let ready = false;
		let upUntil = 0;
		let downUntil = 0;
		const tick = () => {
			if (document.visibilityState === "hidden") {
				upUntil = 0;
				downUntil = 0;
				setFlow((prev) => prev.up || prev.down ? {
					up: false,
					down: false
				} : prev);
				return;
			}
			const next = readTraffic();
			const now = performance.now();
			if (!ready) {
				ready = true;
				rx = next.rx;
				tx = next.tx;
				return;
			}
			if (next.tx < tx) tx = next.tx;
			if (next.rx < rx) rx = next.rx;
			if (next.tx > tx) upUntil = now + 500;
			if (next.rx > rx) downUntil = now + 500;
			tx = next.tx;
			rx = next.rx;
			const up = now < upUntil;
			const down = now < downUntil;
			setFlow((prev) => prev.up === up && prev.down === down ? prev : {
				up,
				down
			});
		};
		const watch = window.setInterval(tick, 400);
		window.addEventListener("coil-traffic", tick);
		document.addEventListener("visibilitychange", tick);
		return () => {
			window.clearInterval(watch);
			window.removeEventListener("coil-traffic", tick);
			document.removeEventListener("visibilitychange", tick);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!actions) return;
		ensurePlace();
		ensureCarrier();
		const onCarrier = () => {
			const name = window.CoilNative?.carrier;
			if (name) saveCarrier(name);
		};
		window.addEventListener("coil-carrier", onCarrier);
		return () => window.removeEventListener("coil-carrier", onCarrier);
	}, [actions]);
	(0, import_react.useEffect)(() => {
		const read = () => applyMark(runRef.current || pokingRef.current);
		read();
		const watch = window.setInterval(read, 500);
		return () => window.clearInterval(watch);
	}, []);
	(0, import_react.useEffect)(() => {
		const lock = () => {
			deadRef.current = true;
			setDead(true);
			const line = [{
				id: ++diagSeq.current,
				text: "Coil Jitter Off-line",
				at: 0,
				keep: true
			}];
			diagLinesRef.current = line;
			setDiagLines(line);
		};
		if (faultDead()) lock();
		window.addEventListener("coil-dead", lock);
		const pardon = window.setTimeout(() => forgiveRestart(), 8e3);
		return () => {
			window.removeEventListener("coil-dead", lock);
			window.clearTimeout(pardon);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (diagScroll.current) diagScroll.current.scrollTop = 0;
	}, [diagLines[0]?.id]);
	(0, import_react.useEffect)(() => {
		const sweep = window.setInterval(() => {
			if (resettingRef.current) return;
			const now = performance.now();
			const kept = diagLinesRef.current.filter((line) => line.keep || now - line.at < 12e4);
			if (kept.length !== diagLinesRef.current.length) {
				diagLinesRef.current = kept;
				setDiagLines(kept);
			}
			if (!(runRef.current || pokingRef.current || diagQueue.current.length > 0 || diagTimer.current !== null) && diagLinesRef.current.length === 0) showCoil(deadRef.current || shownRef.current.doing === "Carregando bobina..." ? "Coil Jitter Off-line" : "Coil Jitter On-line");
			if (shownRef.current.doing && now - shownAtRef.current >= 12e4) {
				const blank = {
					state: "",
					doing: ""
				};
				shownRef.current = blank;
				setShown(blank);
			}
		}, 1e3);
		return () => window.clearInterval(sweep);
	}, []);
	function releaseLight() {
		if (holdRef.current || timerRef.current !== null || queueRef.current.length > 0) return;
		if (!litRef.current) return;
		litRef.current = false;
		setLit(false);
		if (tuneRef.current) {
			tuneRef.current = false;
			setTune(false);
		}
	}
	function holdMs(doing, last) {
		if (doing === "Sintonizando redes...") return 1500;
		return last ? 1e3 : 500;
	}
	function playNext() {
		if (timerRef.current !== null) return;
		const next = queueRef.current.shift();
		if (!next) {
			if (closingRef.current && shownRef.current.doing) {
				const remain = holdMs(shownRef.current.doing, true) - (performance.now() - shownAtRef.current);
				if (remain > 0) {
					timerRef.current = window.setTimeout(() => {
						timerRef.current = null;
						playNext();
					}, remain);
					return;
				}
				const wasLoading = shownRef.current.doing === "Carregando bobina...";
				closingRef.current = false;
				const blank = {
					state: "",
					doing: ""
				};
				shownRef.current = blank;
				setShown(blank);
				if (wasLoading && !deadRef.current) showCoil("Coil Jitter On-line");
			}
			releaseLight();
			return;
		}
		shownRef.current = next;
		shownAtRef.current = performance.now();
		setShown(next);
		setFadeKey((n) => n + 1);
		const lastOne = closingRef.current && queueRef.current.length === 0;
		timerRef.current = window.setTimeout(() => {
			timerRef.current = null;
			playNext();
		}, holdMs(next.doing, lastOne));
	}
	function say(state, doing) {
		if (resettingRef.current) return;
		const last = queueRef.current.at(-1) ?? shownRef.current;
		if (last.state === state && last.doing === doing) return;
		closingRef.current = false;
		queueRef.current.push({
			state,
			doing
		});
		if (timerRef.current !== null) {
			const remain = Math.max(0, holdMs(shownRef.current.doing, false) - (performance.now() - shownAtRef.current));
			window.clearTimeout(timerRef.current);
			timerRef.current = null;
			if (remain === 0) {
				playNext();
				return;
			}
			timerRef.current = window.setTimeout(() => {
				timerRef.current = null;
				playNext();
			}, remain);
			return;
		}
		playNext();
	}
	function clearExec() {
		closingRef.current = true;
		if (timerRef.current !== null) return;
		playNext();
	}
	function beginLight() {
		holdRef.current = true;
		if (litRef.current) return;
		litRef.current = true;
		setLit(true);
	}
	function beginTune() {
		tuneRef.current = true;
		setTune(true);
		beginLight();
	}
	function endLight() {
		holdRef.current = false;
		releaseLight();
	}
	(0, import_react.useEffect)(() => {
		timerRef.current = window.setTimeout(() => {
			timerRef.current = null;
			playNext();
		}, 500);
		const syncLane = () => {
			const next = readLane();
			laneRef.current = next;
			setLane(next);
		};
		const noteGate = (next) => {
			setGate(next);
			setOnline(next === "up");
			applyMark(runRef.current || pokingRef.current);
			const prev = gateRef.current;
			if (prev === next) return;
			gateRef.current = next;
			if (next === "down") tell("Rede fora do ar");
			else if (next === "portal") tell("Portal de login");
			else if (next === "local") {
				const laneNow = laneRef.current;
				tell(laneNow === "wifi" ? "Wi-fi sem internet" : laneNow === "cell" ? "Dados sem internet" : laneNow === "cable" ? "Cabo sem internet" : laneNow === "bt" ? "Bluetooth sem internet" : "Sem internet");
			} else if (prev) tell("Rede restabelecida");
		};
		const noteVpn = () => {
			const next = readVpn();
			if (next === vpnRef.current) return;
			vpnRef.current = next;
			if (next) tell("VPN no caminho");
		};
		const noteNotice = () => {
			const next = readInterruption();
			if (!next || next === noticeRef.current) return;
			noticeRef.current = next;
			tell(next);
		};
		const noteTowers = () => {
			const next = readTowers();
			if (!next || next === towerRef.current) return;
			towerRef.current = next;
			tell(next);
		};
		const noteSignal = () => {
			const value = readDbm();
			setDbm((prev) => prev === value ? prev : value);
			const next = readSignal();
			if (!next || next === signalRef.current) return;
			signalRef.current = next;
			tell(next);
		};
		let lookSeq = 0;
		const look = async () => {
			if (resettingRef.current) return;
			syncLane();
			noteVpn();
			noteNotice();
			noteTowers();
			noteSignal();
			const seq = ++lookSeq;
			if (navigator.onLine === false) {
				noteGate("down");
				return;
			}
			if (runRef.current || pokingRef.current) return;
			const reach = await probeReach();
			if (seq !== lookSeq) return;
			noteGate(reach);
		};
		const report = () => {
			look();
			if (!runRef.current && !pokingRef.current && shownRef.current.doing === "Carregando bobina...") clearExec();
		};
		setOnline(navigator.onLine);
		syncLane();
		if (document.readyState === "complete") report();
		else window.addEventListener("load", report, { once: true });
		window.addEventListener("online", report);
		window.addEventListener("offline", report);
		const conn = navigator.connection;
		conn?.addEventListener?.("change", report);
		window.addEventListener("coil-vpn", noteVpn);
		window.addEventListener("coil-esaq", noteNotice);
		window.addEventListener("coil-tower", noteTowers);
		window.addEventListener("coil-signal", noteSignal);
		const watch = window.setInterval(() => void look(), 8e3);
		const releaseHold = () => {
			medirHeld.current = false;
			wakeHeld.current = false;
		};
		window.addEventListener("pointerup", releaseHold);
		window.addEventListener("pointercancel", releaseHold);
		return () => {
			window.removeEventListener("load", report);
			window.removeEventListener("online", report);
			window.removeEventListener("offline", report);
			conn?.removeEventListener?.("change", report);
			window.removeEventListener("coil-vpn", noteVpn);
			window.removeEventListener("coil-esaq", noteNotice);
			window.removeEventListener("coil-tower", noteTowers);
			window.removeEventListener("coil-signal", noteSignal);
			window.removeEventListener("pointerup", releaseHold);
			window.removeEventListener("pointercancel", releaseHold);
			window.clearInterval(watch);
			if (timerRef.current !== null) window.clearTimeout(timerRef.current);
			if (diagTimer.current !== null) window.clearTimeout(diagTimer.current);
		};
	}, []);
	const down = link?.down ?? null;
	const up = link?.up ?? null;
	const ping = link?.ping ?? null;
	const jitter = link?.jitter ?? null;
	const downText = quiet ? "" : reading === "busy" && down == null ? "…" : down != null ? br(down) : "_";
	const [genText, setGenText] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (quiet || down == null) {
			setGenText("");
			return;
		}
		setGenText(generationMark(down));
	}, [quiet, down]);
	const upText = quiet ? "" : reading === "busy" && up == null ? "…" : up != null ? br(up, 0) : "_";
	const pingText = quiet ? "" : reading === "busy" && ping == null ? "…" : ping != null ? String(ping) : "_";
	const jitterText = quiet ? "" : reading === "busy" && jitter == null ? "…" : jitter != null ? String(jitter) : "_";
	const dnsText = quiet ? "" : dnsWait ? "…" : dnsMs != null ? String(dnsMs) : "_";
	const dbmText = quiet ? "" : dbm != null ? `−${Math.abs(dbm)}` : "_";
	const blinking = (text) => text === "—" || text === "…" || text === "_";
	const sweeping = lit && !tune;
	const blankDown = quiet || downText === "" || downText === "_";
	const blankSide = quiet || [
		upText,
		pingText,
		jitterText,
		dnsText,
		dbmText
	].every((text) => text === "" || text === "—" || text === "_");
	(0, import_react.useEffect)(() => {
		if (blankDown) {
			downSweep.clear();
			return;
		}
		downSweep.poke();
	}, [
		blankDown,
		downText,
		downSweep.poke,
		downSweep.clear
	]);
	(0, import_react.useEffect)(() => {
		if (blankSide) {
			sideSweep.clear();
			return;
		}
		sideSweep.poke();
	}, [
		blankSide,
		upText,
		pingText,
		jitterText,
		dnsText,
		dbmText,
		sideSweep.poke,
		sideSweep.clear
	]);
	const loadingSwept = (0, import_react.useRef)(false);
	const skipExecSweep = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!shown.doing) return;
		if (shown.doing === "Carregando bobina...") {
			if (loadingSwept.current) return;
			let live = true;
			const frame = window.requestAnimationFrame(() => {
				if (!live || loadingSwept.current) return;
				loadingSwept.current = true;
				skipExecSweep.current = true;
				execSweep.poke();
			});
			return () => {
				live = false;
				window.cancelAnimationFrame(frame);
			};
		}
		if (skipExecSweep.current) {
			skipExecSweep.current = false;
			return;
		}
		execSweep.poke();
	}, [shown.doing, execSweep.poke]);
	const diagSeen = (0, import_react.useRef)(diagKey);
	(0, import_react.useEffect)(() => {
		if (quiet) {
			diagSweep.clear();
			return;
		}
		if (diagSeen.current === diagKey) return;
		diagSeen.current = diagKey;
		if (diagLines.length === 0) return;
		diagSweep.poke();
	}, [
		diagKey,
		quiet,
		diagLines.length,
		diagSweep.poke,
		diagSweep.clear
	]);
	function pause() {
		return new Promise((resolve) => setTimeout(resolve, 1e3));
	}
	async function measure() {
		if (runRef.current || pokingRef.current) return;
		const onCell = lane === "cell";
		runRef.current = true;
		applyMark(true);
		clearDiag();
		beginLight();
		setReading("busy");
		setDnsMs(null);
		setDnsWait(false);
		setLink(null);
		let down = null;
		let up = null;
		let loadedPing = null;
		let sawLoad = false;
		let pingMs = null;
		let lostPackets = 0;
		let cause = "Dados enviados sem retorno";
		let started = false;
		let cloudMiss = false;
		async function cycle() {
			if (navigator.onLine === false) {
				cause = "Sem conexão para o envio";
				throw new Error("off");
			}
			started = true;
			let lane = null;
			const path = async () => {
				if (lane) return lane;
				say("Medindo", "Selecionando servidor...");
				lane = await openSpeedLane();
				if (!lane.cloud) cloudMiss = true;
				return lane;
			};
			if (down == null) {
				cause = "Recebimento de dados falhou";
				const prime = await primeLink((step) => {
					if (step === "pacote") say("Medindo", "Preparando medição...");
					else if (step === "espera") say("Medindo", "Aguardando retorno...");
				});
				if (prime.primed) tell(`Esperou ${prime.waitMs} ms`);
				const near = [];
				say("Medindo", "Selecionando servidor...");
				const files = await closestDownloads(2);
				for (let i = 0; i < files.length; i++) {
					if (i > 0) say("Medindo", "Selecionando servidor...");
					say("Medindo", "Recebendo dados...");
					const first = await onceDownload(files[i]);
					await pause();
					const samples = [first, await onceDownload(files[i])].filter((n) => n != null);
					if (!samples.length) continue;
					near.push(samples.reduce((sum, n) => sum + n, 0) / samples.length);
				}
				const road = await path();
				say("Medindo", "Recebendo dados...");
				const down1 = await road.down(true);
				await pause();
				const down2 = await road.down(false);
				const cloudDown = (down1.mbps + down2.mbps) / 2;
				down = fairDown([...near, cloudDown]);
				const samples = [down1.loaded, down2.loaded].filter((n) => n != null);
				loadedPing = samples.length ? Math.max(...samples) : null;
				sawLoad = true;
				if (cloudMiss) tell("A nuvem não respondeu");
				setLink({
					down,
					up: null,
					ping: null,
					jitter: null
				});
			}
			if (up == null) {
				cause = "Transferência de dados falhou";
				const road = await path();
				say("Medindo", "Transferindo dados...");
				const up1 = await road.up(true);
				await pause();
				up = (up1 + await road.up(false)) / 2;
				setLink({
					down,
					up,
					ping: null,
					jitter: null
				});
				await pause();
			}
			cause = "Latência falhou";
			const road = await path();
			say("Medindo", "Calculando latência...");
			const ping1 = await road.ping();
			await pause();
			const ping2 = await road.ping();
			const ping = Math.round((ping1.ping + ping2.ping) / 2);
			const jitter = Math.round((ping1.jitter + ping2.jitter) / 2);
			pingMs = ping;
			lostPackets = ping1.lost + ping2.lost;
			setLink({
				down,
				up,
				ping,
				jitter
			});
			const reply = judgeResponse(ping);
			tellNow(diagnosisLine(reply.kind, reply.ms));
			if (ping1.lost + ping2.lost > 0) tell("Pacotes se perderam");
			if (sawLoad) tell(loadLine(ping, loadedPing));
			for (const line of linkFacts()) tell(line);
			if (onCell && down != null) {
				say("Medindo", "Apurando geração...");
				tell(generationLine(down));
			}
			clearExec();
			setReading("idle");
		}
		try {
			try {
				try {
					await cycle();
				} catch (error) {
					if (resettingRef.current) throw error;
					await cycle();
				}
			} catch {
				if (resettingRef.current) return;
				if (navigator.onLine === false && started && cause !== "Sem conexão para o envio") cause = "Queda de conexão durante o envio";
				else if (down == null && cloudMiss && cause === "Recebimento de dados falhou") cause = "O problema está na saída";
				tellNow(cause);
				for (const line of linkFacts()) tell(line);
				tell("Medição sem sucesso");
				clearExec();
				setReading("none");
			}
			if (started && !resettingRef.current) {
				say("Medindo", "Consultando DNS...");
				setDnsWait(true);
				const [dns, phone] = await Promise.all([probeDns(), probePhoneDns()]);
				setDnsWait(false);
				if (dns.kind !== "none" && dns.ms != null) setDnsMs(dns.ms);
				tell(dns.kind === "none" ? "DNS sem retorno" : dns.kind === "late" ? "DNS demorou demais" : dns.kind === "slow" ? "DNS respondeu, mas devagar" : "DNS respondeu a tempo");
				const gap = dnsGap(dns.kind === "none" ? null : dns.ms, phone);
				if (gap) tell(gap);
				const door = await probeExit();
				const where = exitPhrase(door.city, pingMs, !linkSlow() && (dbm == null || dbm >= -100));
				if (where) tell(where);
				const who = carrierPhrase(door.carrier);
				if (who) tell(who);
				if (navigator.onLine) {
					say("Medindo", "Consultando páginas...");
					const pages = await probePages();
					for (const line of [...pages].reverse()) tell(line);
				}
				if (navigator.onLine) {
					const drops = await probeOutages(readPlace(), readCarrier());
					for (const line of drops) tell(line);
				}
				say("Medindo", "Apurando emissões...");
				const probe = await diagnosePacket();
				tell(diagnosisLine(probe.kind, probe.ms));
				if (navigator.onLine && (pingMs != null && pingMs >= 300 || lostPackets > 0)) {
					const outside = await probeOutside(readPlace()?.city || "");
					if (outside) tell(outside);
				}
				openInterruptions();
				clearExec();
			}
		} finally {
			runRef.current = false;
			if (resettingRef.current) return;
			if (!pokingRef.current) noteAction();
			applyMark(pokingRef.current);
			endLight();
			if (medirHeld.current) measure();
			else if (wakeHeld.current) wake();
		}
	}
	function wake() {
		if (runRef.current || pokingRef.current) return;
		pokingRef.current = true;
		applyMark(true);
		clearDiag();
		beginTune();
		setPoking(true);
		pokeNetwork((line) => say("Sintonizar", line)).then((result) => {
			tellNow(!result.http && result.udp ? "UDP retornou sem HTTP" : !result.http ? "Não respondeu" : result.revived ? "Voltou a responder" : result.woke ? "Mais rápido" : result.udp ? "UDP emitido com retorno" : "Respondeu · igual");
			clearExec();
		}).catch(() => {
			if (resettingRef.current) return;
			tellNow("Não respondeu");
			clearExec();
		}).finally(() => {
			if (resettingRef.current) return;
			pokingRef.current = false;
			if (!runRef.current) noteAction();
			applyMark(runRef.current);
			setPoking(false);
			endLight();
			if (wakeHeld.current) wake();
			else if (medirHeld.current) measure();
		});
	}
	function showDoing(doing) {
		queueRef.current = [];
		if (timerRef.current !== null) {
			window.clearTimeout(timerRef.current);
			timerRef.current = null;
		}
		closingRef.current = false;
		const next = {
			state: "Resetar",
			doing
		};
		shownRef.current = next;
		shownAtRef.current = performance.now();
		setShown(next);
		setFadeKey((n) => n + 1);
	}
	async function resetApp() {
		if (resettingRef.current) return;
		resettingRef.current = true;
		setResetting(true);
		medirHeld.current = false;
		wakeHeld.current = false;
		beginLight();
		showDoing("Restaurando configurações...");
		setReading("idle");
		setPoking(false);
		setLink(null);
		setDnsMs(null);
		setDnsWait(false);
		setDbm(null);
		setQuiet(true);
		setLane(null);
		laneRef.current = null;
		setMark("off");
		markRef.current = "off";
		clearDiag();
		await new Promise((resolve) => window.setTimeout(resolve, 1e3));
		showDoing("Cancelando operações...");
		haltCoil();
		runRef.current = false;
		pokingRef.current = false;
		await new Promise((resolve) => window.setTimeout(resolve, 500));
		showDoing("Limpando cache...");
		try {
			if ("caches" in window) {
				const keys = await caches.keys();
				await Promise.all(keys.map((key) => caches.delete(key)));
			}
		} catch {}
		try {
			sessionStorage.removeItem("coil-fault-tried");
			sessionStorage.removeItem("coil-fault-dead");
		} catch {}
		await new Promise((resolve) => window.setTimeout(resolve, 500));
		showDoing("Reiniciando bobina...");
		await new Promise((resolve) => window.setTimeout(resolve, 1e3));
		location.reload();
	}
	const pointerUsed = (0, import_react.useRef)(false);
	function holdStart(which, event) {
		if (event.button !== 0 || resettingRef.current) return;
		if (which === "reset") {
			event.preventDefault();
			pointerUsed.current = true;
			resetApp();
			return;
		}
		if (deadRef.current) return;
		event.preventDefault();
		pointerUsed.current = true;
		if (which === "medir") medirHeld.current = true;
		else wakeHeld.current = true;
		if (which === "medir") measure();
		else wake();
	}
	function holdEnd(which) {
		if (which === "reset") return;
		if (which === "medir") medirHeld.current = false;
		else wakeHeld.current = false;
		window.setTimeout(() => {
			pointerUsed.current = false;
		}, 0);
	}
	function pressClick(which) {
		if (which === "reset") {
			if (!pointerUsed.current) resetApp();
			pointerUsed.current = false;
			return;
		}
		if (deadRef.current || pointerUsed.current) {
			pointerUsed.current = false;
			return;
		}
		if (which === "medir") measure();
		else wake();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "franquia",
		chrome,
		bare: actions,
		live: actions,
		tone: actions ? tone : void 0,
		children: [actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlateLamps, {}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: actions ? "flex h-full flex-col px-5 pt-16" : "",
			children: [actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "plate-name",
				"aria-label": "Coil Jitter",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Coil Jitter" })
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: actions ? "coil-grid" : void 0,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: actions ? "coil-span descida-row" : void 0,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `speed-square ${quiet ? "" : visorFx} ${!quiet && sweeping ? "is-waking" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `fosforo-figure${quiet ? "" : " is-fading"}${segLong(downText) ? " is-long" : ""}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: blinking(downText) ? "caret" : "",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: downText })
									})
								}, downText),
								quiet ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "fosforo-unit",
									children: "Mb/s"
								}),
								quiet || !genText ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "fosforo-figure fosforo-gen",
									children: genText
								}),
								quiet ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
									className: "fosforo-scan",
									"aria-hidden": true
								})
							] }), quiet || downSweep.pass === 0 ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "coil-sweep is-on",
								onAnimationEnd: () => downSweep.done(downSweep.pass),
								"aria-hidden": true
							}, downSweep.pass)]
						}), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "net-stack",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "net-paths",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `net-mark is-path${quiet ? "" : online && lane === "wifi" ? " is-on" : ""}`,
											role: "status",
											"aria-label": "Wi-fi",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiGlyph, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "net-lit",
												"aria-hidden": true,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiGlyph, {})
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `net-mark is-path${quiet ? "" : online && lane === "cell" ? " is-on" : ""}`,
											role: "status",
											"aria-label": "Dados móveis",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CellGlyph, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "net-lit",
												"aria-hidden": true,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CellGlyph, {})
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `net-mark is-path${quiet ? "" : online && lane === "cable" ? " is-on" : ""}`,
											role: "status",
											"aria-label": "Cabo",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CableGlyph, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "net-lit",
												"aria-hidden": true,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CableGlyph, {})
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `net-mark is-path${quiet ? "" : online && lane === "bt" ? " is-on" : ""}`,
											role: "status",
											"aria-label": "Bluetooth",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtGlyph, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "net-lit",
												"aria-hidden": true,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BtGlyph, {})
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "net-paths",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `net-mark is-path${quiet ? "" : mark === "active" ? " is-on" : ""}`,
											role: "status",
											"aria-label": mark === "active" ? "Rede ativa" : "Rede inativa",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoltGlyph, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "net-lit",
												"aria-hidden": true,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoltGlyph, {})
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `net-mark is-path${quiet ? "" : mark === "slow" ? " is-on" : ""}`,
											role: "status",
											"aria-label": mark === "slow" ? "Rede lenta" : "Rede normal",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, {
												n: 9,
												size: 16
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "net-lit",
												"aria-hidden": true,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, {
													n: 9,
													size: 16
												})
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `net-mark is-path${quiet ? "" : mark === "idle" ? " is-on" : ""}`,
											role: "status",
											"aria-label": mark === "idle" ? "Rede ociosa" : "Rede em uso",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaneGlyph, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "net-lit",
												"aria-hidden": true,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaneGlyph, {})
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "net-paths",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `net-mark is-path${quiet || !flow.up ? "" : " is-on"}`,
										role: "status",
										"aria-label": flow.up ? "Saindo dados" : "Sem saída",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpArrowGlyph, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "net-lit",
											"aria-hidden": true,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpArrowGlyph, {})
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: `net-mark is-path${quiet || !flow.down ? "" : " is-on"}`,
										role: "status",
										"aria-label": flow.down ? "Entrando dados" : "Sem entrada",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownArrowGlyph, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "net-lit",
											"aria-hidden": true,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownArrowGlyph, {})
										})]
									})]
								})
							]
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "speed-side",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `speed-chip ${quiet ? "" : visorFx} ${!quiet && sweeping ? "is-waking" : ""}`,
							"aria-label": up == null && ping == null && jitter == null && dnsMs == null && !dnsWait && dbm == null ? "Visor de Medições" : `Visor de Medições. sobe ${upText}. ping ${pingText}. jitter ${jitterText}. dns ${dnsText}. sinal ${dbmText}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: quiet ? "measure-line" : "measure-line is-fading",
									children: quiet ? "" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "sobe" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `seg-num ${blinking(upText) ? "caret" : ""}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: upText })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mb/s" })
									] })
								}, `sobe-${upText}`),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: quiet ? "measure-line" : "measure-line is-fading",
									children: quiet ? "" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ping" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `seg-num ${blinking(pingText) ? "caret" : ""}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: pingText })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ms" })
									] })
								}, `ping-${pingText}`),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: quiet ? "measure-line" : "measure-line is-fading",
									children: quiet ? "" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "jitter" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `seg-num ${blinking(jitterText) ? "caret" : ""}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: jitterText })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ms" })
									] })
								}, `jitter-${jitterText}`),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "dns-corner",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: quiet ? "measure-line" : "measure-line is-fading",
										children: quiet ? "" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "sinal" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `seg-num ${blinking(dbmText) ? "caret" : ""}`,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: dbmText })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "dBm" })
										] })
									}, `dbm-${dbmText}`), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: quiet ? "measure-line" : "measure-line is-fading",
										children: quiet ? "" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "dns" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `seg-num ${blinking(dnsText) ? "caret" : ""}`,
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: dnsText })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ms" })
										] })
									}, `dns-${dnsText}`)]
								}),
								quiet ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
									className: "fosforo-scan",
									"aria-hidden": true
								})
							] }), quiet || sideSweep.pass === 0 ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "coil-sweep is-on",
								onAnimationEnd: () => sideSweep.done(sideSweep.pass),
								"aria-hidden": true
							}, sideSweep.pass)]
						})
					}),
					actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "key-stack",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "plate-key",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `speed-redo is-off ${chapaClass} ${!dead && reading === "busy" ? "is-busy" : ""} ${!dead && reading === "busy" && online ? "is-lit" : ""}`,
								"aria-label": "Medir",
								disabled: dead,
								onPointerDown: (event) => holdStart("medir", event),
								onPointerUp: () => holdEnd("medir"),
								onPointerCancel: () => holdEnd("medir"),
								onContextMenu: (event) => event.preventDefault(),
								onClick: () => pressClick("medir"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedoIcon, {
									size: 22,
									strokeWidth: 2.25
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "plate-key is-wake",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `speed-redo wake-redo is-off ${chapaClass} ${!dead && poking ? "is-busy" : ""} ${!dead && poking && online ? "is-lit" : ""}`,
								"aria-label": "Sintonizar",
								disabled: dead,
								onPointerDown: (event) => holdStart("wake", event),
								onPointerUp: () => holdEnd("wake"),
								onPointerCancel: () => holdEnd("wake"),
								onContextMenu: (event) => event.preventDefault(),
								onClick: () => pressClick("wake"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WakeIcon, {
									size: 22,
									strokeWidth: 2.25
								})
							})
						})]
					}) : null,
					actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: `clock-field coil-span ${visorFx} ${lit ? "is-waking" : ""}`,
							"aria-label": shown.doing ? `Visor de Execução. ${shown.doing}` : "Visor de Execução",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "clock-readout",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `clock-copy ${fadeKey ? "is-fading" : ""}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `clock-doing ${flick ? "is-flick" : ""}`,
										style: flick ? { ["--flick"]: `${flick}ms` } : void 0,
										children: shown.doing
									})
								}, fadeKey)
							}), execSweep.pass === 0 ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "coil-sweep is-on",
								onAnimationEnd: () => execSweep.done(execSweep.pass),
								"aria-hidden": true
							}, execSweep.pass)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: `clock-field clock-extra coil-span ${quiet ? "" : visorFx} ${!quiet && sweeping ? "is-waking" : ""}`,
							"aria-label": diagLines.length ? `Visor de Diagnóstico. ${diagLines.map((line) => line.text).join(". ")}` : "Visor de Diagnóstico",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "clock-readout",
								ref: diagScroll,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "clock-copy diag-lines",
									children: quiet ? null : diagLines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `clock-doing${i === 0 && diagKey ? " is-fading" : ""}${flick ? " is-flick" : ""}`,
										style: flick ? { ["--flick"]: `${flick}ms` } : void 0,
										children: line.text
									}, line.id))
								})
							}), quiet || diagSweep.pass === 0 ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "coil-sweep is-on",
								onAnimationEnd: () => diagSweep.done(diagSweep.pass),
								"aria-hidden": true
							}, diagSweep.pass)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "coil-span door-row",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "plate-key is-reset",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: `speed-redo is-off ${chapaClass} ${resetting ? "is-busy" : ""} ${resetting && online ? "is-lit" : ""}`,
									"aria-label": "Resetar",
									onPointerDown: (event) => holdStart("reset", event),
									onPointerUp: () => holdEnd("reset"),
									onPointerCancel: () => holdEnd("reset"),
									onContextMenu: (event) => event.preventDefault(),
									onClick: () => pressClick("reset"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
										size: 22,
										strokeWidth: 2.25
									})
								})
							})
						})
					] }) : null
				]
			})]
		})]
	});
}
function Pulso({ chrome }) {
	const w = 320;
	const h = 96;
	const max = Math.max(...pulse);
	const min = Math.min(...pulse);
	const d = pulse.map((v, i) => {
		const x = i / (pulse.length - 1) * w;
		const y = h - (v - min) / (max - min) * 88 - 4;
		return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
	}).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "pulso",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Pulso" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-6xl leading-none tabular-nums tracking-tight",
				children: [snapshot.ping, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "c-muted text-2xl",
					children: " ms"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: `0 0 ${w} ${h}`,
				className: "mt-8 h-24 w-full",
				"aria-hidden": true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d,
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					className: "c-accent"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "c-muted mt-3 text-sm",
				children: "Latência nos últimos minutos."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "c-accent mt-6 text-sm",
				children: "Pico de 48 ms às 07:40, na queda."
			})
		]
	});
}
function Barras({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "barras",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Barras" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 flex h-72 items-end gap-3",
				children: [
					1,
					2,
					3,
					4
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `flex-1 rounded-sm ${i <= snapshot.bars ? "c-fill" : "c-track"}`,
					style: { height: `${22 + i * 18}%` }
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-3xl leading-none",
				children: "Três de quatro."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-3 text-sm",
				children: [
					snapshot.carrier,
					" · ",
					snapshot.tech,
					" · ",
					snapshot.dbm,
					" dBm"
				]
			})
		]
	});
}
function Diario({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "diario",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Sexta, 2 de outubro" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "c-serif mt-3 text-4xl leading-none tracking-tight",
				children: "Diário da rede"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8",
				children: diary.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid grid-cols-[3.2rem_1fr] gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted pt-3 text-xs tabular-nums",
						children: item.t
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `c-rule py-3 ${index ? "border-t" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "c-muted text-sm",
							children: item.detail
						})]
					})]
				}, item.t))
			})
		]
	});
}
function Relogio({ chrome }) {
	const pct = .68;
	const r = 78;
	const circ = 2 * Math.PI * r;
	const dash = circ * pct;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "relogio",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Relógio · ", snapshot.carrier] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto mt-8 grid h-64 w-64 place-items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 200 200",
					className: "h-full w-full",
					"aria-hidden": true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r,
						className: "arc-track"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r,
						className: "arc-value",
						strokeDasharray: `${dash} ${circ - dash}`,
						transform: "rotate(-90 100 100)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-serif text-5xl leading-none",
						children: snapshot.quality
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "c-muted mt-2 text-sm tabular-nums",
						children: [snapshot.dbm, " dBm"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-6 text-center text-sm",
				children: [
					snapshot.tech,
					" · ",
					snapshot.ping,
					" ms · ",
					br(snapshot.down),
					" Mb/s"
				]
			})
		]
	});
}
function Cartoes({ chrome }) {
	const cards = [
		{
			k: "Sinal",
			v: snapshot.quality,
			s: `${snapshot.bars} de 4 · ${snapshot.dbm} dBm`
		},
		{
			k: "Velocidade",
			v: `${br(snapshot.down)} Mb/s`,
			s: `sobe ${br(snapshot.up)} · ping ${snapshot.ping} ms`
		},
		{
			k: "Plano",
			v: `${br(snapshot.usedGb)} GB`,
			s: `de ${snapshot.capGb} GB · ${snapshot.carrier}`
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "cartoes",
		chrome,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Cartões" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 flex flex-col gap-3",
			children: cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "c-surface rounded-2xl px-4 py-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "c-muted text-xs tracking-widest uppercase",
						children: card.k
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-3xl leading-none tracking-tight",
						children: card.v
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "c-muted mt-2 text-sm",
						children: card.s
					})
				]
			}, card.k))
		})]
	});
}
function Faixa({ chrome }) {
	const [open, setOpen] = (0, import_react.useState)(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "faixa",
		chrome,
		bare: true,
		children: [chrome ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "c-strip flex w-full items-center justify-between px-5 py-4 text-left",
			onClick: () => setOpen((v) => !v),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm font-medium",
				children: [
					snapshot.carrier,
					" ",
					snapshot.tech
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm tabular-nums",
				children: [snapshot.ping, " ms"]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "c-strip flex w-full items-center justify-between px-5 py-4 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm font-medium",
				children: [
					snapshot.carrier,
					" ",
					snapshot.tech
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm tabular-nums",
				children: [snapshot.ping, " ms"]
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-5 pb-28 pt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Por baixo da faixa" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-4xl leading-none tracking-tight",
					children: snapshot.quality
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "c-muted mt-3 text-sm",
					children: [
						snapshot.dbm,
						" dBm · desce ",
						br(snapshot.down),
						" · plano ",
						br(snapshot.usedGb),
						" de ",
						snapshot.capGb,
						" GB"
					]
				})
			]
		}) : null]
	});
}
function wavePath(amp, phase) {
	let d = "";
	for (let x = 0; x <= 320; x += 8) {
		const y = 28 + Math.sin(x / 320 * Math.PI * 3 + phase) * amp;
		d += `${x === 0 ? "M" : "L"}${x} ${y.toFixed(1)} `;
	}
	return d;
}
function Orbita({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "orbita",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Órbita · ", snapshot.tech] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto mt-8 grid h-64 w-64 place-items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 200 200",
					className: "absolute inset-0 h-full w-full",
					"aria-hidden": true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "100",
							cy: "100",
							rx: "88",
							ry: "32",
							className: "ring ring-dim",
							transform: "rotate(-22 100 100)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "100",
							cy: "100",
							rx: "70",
							ry: "26",
							className: "ring ring-dim",
							transform: "rotate(28 100 100)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "100",
							cy: "100",
							rx: "46",
							ry: "18",
							className: "ring ring-hot"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
							className: "orbit-spin",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "100",
								cy: "18",
								r: "4",
								fill: "currentColor",
								className: "c-accent"
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "glow c-accent text-5xl leading-none tabular-nums",
						children: snapshot.dbm
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted mt-1 text-xs",
						children: "dBm"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-6 text-center text-sm",
				children: [
					snapshot.carrier,
					" · ping ",
					snapshot.ping,
					" ms"
				]
			})
		]
	});
}
function Fosforo({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "fosforo",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["link / ", snapshot.carrier.toLowerCase()] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "glow c-accent mt-8 text-6xl leading-none tabular-nums",
				children: [snapshot.tech, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "caret",
					children: "_"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-8 space-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"rssi ",
						snapshot.dbm,
						" dBm"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"rtt ",
						snapshot.ping,
						" ms"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"down ",
						br(snapshot.down),
						" Mb/s"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "c-muted",
						children: [
							"up ",
							br(snapshot.up),
							" Mb/s · plano ",
							br(snapshot.usedGb),
							"/",
							snapshot.capGb
						]
					})
				]
			})
		]
	});
}
function Neon({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "neon",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: snapshot.place }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "neon-sign mt-8 text-7xl leading-none tracking-tight",
				children: snapshot.tech
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-2xl",
				children: snapshot.quality
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 flex h-24 items-end gap-2",
				children: [
					1,
					2,
					3,
					4
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `flex-1 ${i <= snapshot.bars ? "c-fill neon-bar" : "c-track"}`,
					style: { height: `${30 + i * 16}%` }
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-4 text-sm tabular-nums",
				children: [
					snapshot.dbm,
					" dBm · ",
					snapshot.ping,
					" ms"
				]
			})
		]
	});
}
function Visor({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "visor",
		chrome,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Visor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hud mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner hud-tl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner hud-tr" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner hud-bl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner hud-br" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "scan" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 grid place-items-center text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "c-muted text-xs tracking-widest",
							children: "LOCK"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "glow c-accent mt-2 text-5xl leading-none tabular-nums",
							children: snapshot.dbm
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 text-sm",
							children: [
								snapshot.carrier,
								" ",
								snapshot.tech
							]
						})
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "c-muted absolute bottom-3 left-4 text-xs tabular-nums",
					children: [snapshot.ping, " ms"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "c-muted absolute right-4 bottom-3 text-xs tabular-nums",
					children: [br(snapshot.down), " ↓"]
				})
			]
		})]
	});
}
function Ondas({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "ondas",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Ondas" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 space-y-3",
				children: [
					{
						name: "Desce",
						amp: 16,
						phase: .4
					},
					{
						name: "Sobe",
						amp: 9,
						phase: 1.3
					},
					{
						name: "Ping",
						amp: 6,
						phase: 2.1
					}
				].map((band) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "c-muted text-xs tracking-widest uppercase",
					children: band.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 320 56",
					className: "h-14 w-full",
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: wavePath(band.amp, band.phase),
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.6",
						className: "c-accent"
					})
				})] }, band.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm tabular-nums",
				children: [
					br(snapshot.down),
					" · ",
					br(snapshot.up),
					" · ",
					snapshot.ping,
					" ms"
				]
			})
		]
	});
}
function Selos({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "selos",
		chrome,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Correio da rede" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "c-surface mt-6 px-4 py-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "perf" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "c-muted mt-4 text-xs tracking-widest uppercase",
					children: [
						snapshot.place,
						" · ",
						snapshot.carrier
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-3 text-4xl leading-none",
					children: [snapshot.quality, " passagem"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-lg",
					children: [
						snapshot.tech,
						", ",
						snapshot.dbm,
						" dBm, ",
						snapshot.ping,
						" ms."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "stamp text-sm",
						children: "Sinal bom"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "perf" })
			]
		})]
	});
}
function Ceu({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "ceu",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Céu · ", snapshot.place] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 240 140",
				className: "mt-4 h-44 w-full",
				"aria-hidden": true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M70 18 L168 22 L214 58 L150 102 L92 88 Z",
					fill: "none",
					stroke: "currentColor",
					className: "c-muted",
					strokeWidth: "0.6"
				}), [
					[
						28,
						36,
						1.5
					],
					[
						70,
						18,
						2
					],
					[
						118,
						48,
						1.6
					],
					[
						168,
						22,
						4.2
					],
					[
						214,
						58,
						1.8
					],
					[
						92,
						88,
						2.2
					],
					[
						150,
						102,
						1.4
					],
					[
						206,
						96,
						2.6
					],
					[
						48,
						110,
						1.2
					]
				].map(([x, y, r]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: x,
					cy: y,
					r,
					fill: "currentColor",
					className: r > 3 ? "c-accent" : "c-muted"
				}, `${x}-${y}`))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-accent text-sm",
				children: [
					"O ponto claro é agora · ",
					snapshot.dbm,
					" dBm"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-2 text-sm",
				children: [
					snapshot.carrier,
					" ",
					snapshot.tech,
					" · ",
					snapshot.ping,
					" ms"
				]
			})
		]
	});
}
function Fita({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "fita",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Deck · ", snapshot.carrier] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "c-surface mt-6 space-y-4 rounded-xl px-4 py-4",
				children: [
					{
						name: "Desce",
						lit: 14
					},
					{
						name: "Sobe",
						lit: 8
					},
					{
						name: "Ping",
						lit: 6
					}
				].map((meter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "c-muted mb-2 text-xs tracking-widest uppercase",
					children: meter.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1",
					children: Array.from({ length: 16 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-5 flex-1 ${i < meter.lit ? i >= 12 ? "vu-hot" : "c-fill" : "c-track"}` }, i))
				})] }, meter.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-4 text-sm tabular-nums",
				children: [
					snapshot.dbm,
					" dBm · ",
					snapshot.tech
				]
			})
		]
	});
}
function Grade({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "grade",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Grade noturna" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 grid grid-cols-8 gap-1",
				children: Array.from({ length: 64 }, (_, i) => {
					const on = (i * 5 + 2) % 9 < snapshot.bars + 3;
					const hot = on && i % 7 === 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `aspect-square ${hot ? "vu-hot" : on ? "c-fill" : "c-track"}` }, i);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm",
				children: [
					snapshot.quality,
					" · ",
					snapshot.bars,
					" de 4 células fortes"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted text-sm tabular-nums",
				children: [
					snapshot.dbm,
					" dBm · ",
					br(snapshot.down),
					" Mb/s"
				]
			})
		]
	});
}
function Luneta({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "luneta",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Luneta" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lens mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-accent text-5xl leading-none tabular-nums",
						children: snapshot.dbm
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted mt-2 text-xs tracking-widest",
						children: "dBm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 text-sm",
						children: snapshot.quality
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-6 text-center text-sm",
				children: [
					snapshot.carrier,
					" ",
					snapshot.tech,
					" · ",
					snapshot.place
				]
			})
		]
	});
}
var redoIcons = {
	40: RadioTower,
	41: Antenna,
	42: Signal,
	43: Rss,
	44: Gauge,
	45: Radar,
	46: TowerControl,
	47: Wifi
};
var wakeIcons = {
	48: Radio,
	49: HeartPulse,
	50: Stethoscope,
	51: ScanSearch,
	52: Microscope,
	53: SatelliteDish,
	54: Ruler,
	55: DraftingCompass,
	56: TestTubes
};
function icone(kicker, title, note, Icon) {
	return function Botao({ chrome }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			slug: "botao",
			chrome,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: kicker }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-3xl leading-none",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "botao-stage",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "speed-redo is-armed",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							size: 22,
							strokeWidth: 2.25
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "c-muted mt-4 max-w-xs text-sm",
					children: note
				})
			]
		});
	};
}
function botao(title, note, Icon) {
	return icone("Medir", title, note, Icon);
}
function acordar(title, note, Icon) {
	return icone("Sintonizar", title, note, Icon);
}
function marca(title, note, glyph) {
	return function Marca({ chrome }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			slug: "botao",
			chrome,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Rede" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-3xl leading-none",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "botao-stage",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "speed-redo is-armed",
						"aria-hidden": true,
						children: glyph
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "c-muted mt-4 max-w-xs text-sm",
					children: note
				})
			]
		});
	};
}
function chapa(slug, title, note) {
	return function Chapa({ chrome }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			slug: "chapa",
			chrome,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Botões" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-3xl leading-none",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "chapa-stage",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `speed-redo chapa-${slug}`,
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, {
							size: 22,
							strokeWidth: 2.25
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `speed-redo chapa-${slug}`,
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SatelliteDish, {
							size: 22,
							strokeWidth: 2.25
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "c-muted mt-4 max-w-xs text-sm",
					children: note
				})
			]
		});
	};
}
function fundo(slug, title, note) {
	return function Fundo({ chrome }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			slug,
			chrome,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Fundo" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-3xl leading-none",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "c-muted mt-4 max-w-xs text-sm",
					children: note
				})
			]
		});
	};
}
function efeitoVisor(slug, title, note) {
	return function Efeito({ chrome }) {
		const flick = useRandomFlicker(slug === "cintilacao");
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			slug: "fosforo",
			chrome,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Efeito" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-3xl leading-none",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `speed-square efeito-${slug} ${flick ? "is-flick" : ""} mt-8`,
					style: flick ? { ["--flick"]: `${flick}ms` } : void 0,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "fosforo-figure",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: "42,6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "fosforo-unit",
							children: "Mb/s"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
							className: "fosforo-scan",
							"aria-hidden": true
						})
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "c-muted mt-4 max-w-xs text-sm",
					children: note
				})
			]
		});
	};
}
var views = {
	1: Campo,
	2: Sentenca,
	3: Cockpit,
	4: Franquia,
	5: Pulso,
	6: Barras,
	7: Diario,
	8: Relogio,
	9: Cartoes,
	10: Faixa,
	11: Orbita,
	12: Fosforo,
	13: Neon,
	14: Visor,
	15: Ondas,
	16: Selos,
	17: Ceu,
	18: Fita,
	19: Grade,
	20: Luneta,
	21: fundo("escovado", "Escovado", "Alumínio escovado, claro, como tampa de aparelho."),
	22: fundo("aco", "Aço", "Chapa de aço fosco, do tipo painel de instrumento."),
	23: fundo("anodizado", "Anodizado", "Alumínio anodizado preto, sem brilho de neon."),
	24: fundo("inox", "Inox", "Aço inoxidável escovado na diagonal."),
	25: fundo("jateado", "Jateado", "Alumínio jateado, fosco, sem direção de escova."),
	26: fundo("esmalte", "Esmalte", "Tinta eletrostática grafite, de chassi de equipamento."),
	27: fundo("fresagem", "Fresagem", "Alumínio escovado na vertical, com risco e reflexo de estúdio."),
	28: fundo("acovivo", "Aço vivo", "Aço laminado, grão fino e brilho de óleo."),
	29: fundo("negro", "Negro", "Alumínio anodizado preto, luz raspando a superfície."),
	30: fundo("espelho", "Espelho", "Inox escovado na diagonal, com reflexo do ambiente."),
	31: fundo("grao", "Grão", "Alumínio jateado, fosco, grão fechado."),
	32: fundo("chassi", "Chassi", "Tinta de equipamento, casca de laranja, emenda e parafusos."),
	33: fundo("liga", "Liga", "Inox do Espelho com a emenda e os parafusos do Chassi."),
	34: fundo("ferrugem", "Ferrugem", "Aço quase íntegro, com pequenas manchas de corrosão."),
	35: fundo("gasto", "Gasto", "Alumínio com risco, mancha fosca e oxidação na borda."),
	36: fundo("zinco", "Zinco", "Chapa galvanizada, corrosão pequena no canto."),
	37: fundo("parafusos", "Parafusos", "Placa grafite com quatro parafusos allen."),
	38: fundo("pregos", "Pregos", "Chapa clara com rebites e duas cabeças de prego."),
	39: fundo("fixacao", "Fixação", "Parafusos e um prego, com ferrugem só em volta deles."),
	40: botao("Torre", "Mastro com ondas no topo.", RadioTower),
	41: botao("Antena", "Haste única, como antena de rádio.", Antenna),
	42: botao("Sinal", "Barras crescendo. O sinal em pé.", Signal),
	43: botao("Onda", "Três arcos saindo de um ponto.", Rss),
	44: botao("Medidor", "Ponteiro de instrumento. É o ícone atual.", Gauge),
	45: botao("Radar", "Círculo com um braço varrendo.", Radar),
	46: botao("Poste", "Torre de controle, mais larga que o mastro.", TowerControl),
	47: botao("Wi-fi", "O arco familiar do Wi-fi.", Wifi),
	48: acordar("Rádio", "O rádio de antes.", Radio),
	49: acordar("Pulso", "Linha de pulso. Diagnóstico.", HeartPulse),
	50: acordar("Esteto", "Estetoscópio. Ausculta a rede.", Stethoscope),
	51: acordar("Varredura", "Uma busca varrendo o sinal.", ScanSearch),
	52: acordar("Lente", "Microscópio. Exame de perto.", Microscope),
	53: acordar("Prato", "Antena parabólica. É o ícone atual.", SatelliteDish),
	54: acordar("Régua", "Medida direta, em escala.", Ruler),
	55: acordar("Compasso", "Abre o arco e mede.", DraftingCompass),
	56: acordar("Tubos", "Análise de laboratório.", TestTubes),
	57: efeitoVisor("brilho", "Brilho", "O número ganha um halo de fósforo."),
	58: efeitoVisor("cintilacao", "Cintilação", "O visor pisca leve, como um tubo cansado."),
	59: efeitoVisor("fantasma", "Fantasma", "Uma cópia fraca do texto, um pouco ao lado."),
	60: efeitoVisor("grao", "Grão", "Granulação fina sobre o vidro."),
	61: efeitoVisor("vinheta", "Vinheta", "Os cantos do visor escurecem."),
	62: efeitoVisor("reflexo", "Reflexo", "Um brilho de vidro atravessa o visor."),
	63: efeitoVisor("moldura", "Moldura", "A borda interna acende e apaga."),
	64: efeitoVisor("linhas", "Linhas", "As linhas do tubo ficam mais fortes e descem."),
	65: efeitoVisor("nucleo", "Núcleo", "Um clarão parado atrás do número."),
	66: efeitoVisor("poeira", "Poeira", "Pontos pequenos parados no vidro."),
	67: efeitoVisor("vidro", "Vidro", "Reflexo fixo de vidro curvo no topo."),
	68: efeitoVisor("quente", "Quente", "O centro mais claro e a borda mais escura."),
	69: efeitoVisor("batida", "Batida", "O visor inteiro respira em brilho."),
	70: efeitoVisor("eco", "Eco", "O texto se repete, cada vez mais fraco."),
	71: efeitoVisor("neblina", "Neblina", "Uma névoa leve por cima do vidro."),
	87: marca("Rede lenta", "Ponteiro no começo do arco. A rede responde, mas arrasta.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowGlyph, { size: 22 })),
	88: marca("Rede ociosa", "Um ponto parado no círculo. A rede está no ar e não se move.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 2 })),
	89: marca("Ociosa 01 · Anel", "Círculo vazio. Nada dentro.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 1 })),
	90: marca("Ociosa 02 · Ponto", "Um ponto parado no meio do círculo.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 2 })),
	91: marca("Ociosa 03 · Traço", "Um traço curto no centro. Repouso.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 3 })),
	92: marca("Ociosa 04 · Diâmetro", "Uma linha atravessa o círculo e para.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 4 })),
	93: marca("Ociosa 05 · Pausa", "Duas barras. A rede está em pausa.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 5 })),
	94: marca("Ociosa 06 · Lua", "Uma lua. O rádio dorme.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 6 })),
	95: marca("Ociosa 07 · Pálpebra", "Um olho fechado. Sem movimento.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 7 })),
	96: marca("Ociosa 08 · Nível", "A bolha no centro. Nada pende.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 8 })),
	97: marca("Ociosa 09 · Ampulheta", "O tempo parado no meio.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 9 })),
	98: marca("Ociosa 10 · Quadro", "Um quadro vazio.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 10 })),
	99: marca("Ociosa 11 · Selo", "Um ponto dentro do quadro.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 11 })),
	100: marca("Ociosa 12 · Linha", "A onda virou um traço.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 12 })),
	101: marca("Ociosa 13 · Reticências", "Três pontos parados.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 13 })),
	102: marca("Ociosa 14 · Tigela", "Um arco deitado. Sem subir.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 14 })),
	103: marca("Ociosa 15 · Menos", "Um menos dentro do círculo.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleMark, { n: 15 })),
	104: marca("Lenta 01 · Ponteiro", "O ponteiro fica no começo do arco.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 1 })),
	105: marca("Lenta 02 · Rastro", "O ponto anda e deixa um rastro.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 2 })),
	106: marca("Lenta 03 · Arco", "Só o arco de baixo do sinal.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 3 })),
	107: marca("Lenta 04 · Barras", "A última barra não completa.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 4 })),
	108: marca("Lenta 05 · Descida", "A linha desce e demora.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 5 })),
	109: marca("Lenta 06 · Onda", "Uma onda longa e rasa.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 6 })),
	110: marca("Lenta 07 · Relógio", "O ponteiro já passou da hora.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 7 })),
	111: marca("Lenta 08 · Espaço", "Os pontos se afastam.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 8 })),
	112: marca("Lenta 09 · Freio", "Um corte no fundo do círculo.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 9 })),
	113: marca("Lenta 10 · Passo", "Dois passos, longe um do outro.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 10 })),
	114: marca("Lenta 11 · Cauda", "Traços atrás do ponto.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 11 })),
	115: marca("Lenta 12 · Ladeira", "A descida termina num ponto.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 12 })),
	116: marca("Lenta 13 · Meia", "O arco não fecha.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 13 })),
	117: marca("Lenta 14 · Elipse", "O círculo esticado no tempo.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 14 })),
	118: marca("Lenta 15 · Eco", "O segundo círculo chega atrasado.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlowMark, { n: 15 })),
	119: marca("Sono 01 · Pilha", "Z, zZ e zz subindo. O sono clássico.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepMark, { n: 1 })),
	120: marca("Sono 02 · ZzZzz", "A palavra ZzZzz, inclinada.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepMark, { n: 2 })),
	121: marca("Sono 03 · Pálpebra", "O olho fechado, com ZzZzz em cima.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepMark, { n: 3 })),
	122: marca("Sono 00 · Dois Z", "Dois Z sobrepostos, um maior que o outro.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepMark, { n: 4 })),
	123: marca("Z 01 · Alto", "O Z menor fica no alto, sobre o maior.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepMark, { n: 5 })),
	124: marca("Z 02 · Centro", "O Z menor cobre o meio do maior.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepMark, { n: 6 })),
	125: marca("Z 03 · Baixo", "O Z menor fica à esquerda, mais baixo.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepMark, { n: 7 })),
	126: marca("Z 04 · Torto", "O Z menor entra inclinado sobre o maior.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepMark, { n: 8 })),
	127: marca("Z 05 · Frente", "O Z da frente é o maior. O de trás fica atrás.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SleepMark, { n: 9 })),
	128: marca("Lua 01 · Chapa", "A lua minguante que está na chapa.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoonMark, { n: 1 })),
	129: marca("Lua 02 · Fina", "Uma lasca fina, barriga à direita.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoonMark, { n: 2 })),
	130: marca("Lua 03 · Larga", "Mais gorda, ainda minguante.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoonMark, { n: 3 })),
	131: marca("Lua 04 · Alta", "A mesma lua, com as pontas mais altas.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoonMark, { n: 4 })),
	132: marca("Lua 05 · Contorno", "Só o corte da lua, sem o miolo.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoonMark, { n: 5 })),
	72: chapa("polido", "Polido", "Alumínio novo. Sem marca de uso."),
	73: chapa("escova", "Escova", "Aço escovado na horizontal, ainda limpo."),
	74: chapa("jato", "Jato", "Fosco jateado. Quase nenhum brilho."),
	75: chapa("chumbo", "Chumbo", "Grafite escuro, liso, pouco manuseado."),
	76: chapa("frio", "Frio", "Inox com reflexo frio na diagonal."),
	77: chapa("niquel", "Níquel", "Metal morno, com um véu leve de dedo."),
	78: chapa("bronze", "Bronze", "Bronze escuro. Pátina só num canto."),
	79: chapa("oleo", "Óleo", "Aço com véu de óleo e uma marca de dedo."),
	80: chapa("dedos", "Dedos", "As bordas escureceram de tanto toque."),
	81: chapa("uso", "Uso", "Centro mais claro. Os cantos já gastaram."),
	82: chapa("oxido", "Óxido", "Zinco com pontos brancos de oxidação."),
	83: chapa("patina", "Pátina", "Bronze com verde só na borda."),
	84: chapa("pinta", "Pinta", "Aço com pintas pequenas de ferrugem."),
	85: chapa("tempera", "Têmpera", "Aço queimado. Azul e marrom de calor."),
	86: chapa("sucata", "Sucata", "O mais usado: escuro, manchado, ferrugem na quina.")
};
function Concept({ id, chrome = true, actions = false }) {
	const View = views[id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, {
		chrome,
		actions
	});
}
var KEY = "sinal-plano";
var listeners = /* @__PURE__ */ new Set();
function emit() {
	listeners.forEach((listener) => listener());
}
function valid(value) {
	return value.capGb > 0 && value.usedGb >= 0 && value.renewDay >= 1 && value.renewDay <= 31;
}
function hydratePlan() {
	try {
		if (valid(JSON.parse(localStorage.getItem(KEY) ?? "")));
	} catch {}
	emit();
}
function inUse(item, state) {
	if ("kind" in item && item.kind === "fundo") return state.fundo === item.id;
	if ("kind" in item && item.kind === "botao") return state.botao === item.id;
	if ("kind" in item && item.kind === "acordar") return state.acordar === item.id;
	if ("kind" in item && item.kind === "efeito") return state.efeito === item.id;
	if ("kind" in item && item.kind === "chapa") return state.chapa === item.id;
	return state.chosen === item.id;
}
var labOrder = [...concepts].sort((a, b) => {
	const rank = (item) => "kind" in item && item.kind === "marca" && item.slug.startsWith("lua-") ? -6 : "kind" in item && item.kind === "marca" && item.slug.startsWith("zz-") ? -5 : "kind" in item && item.kind === "marca" && item.slug === "sono-0" ? -4 : "kind" in item && item.kind === "marca" && item.slug.startsWith("sono-") ? -3 : "kind" in item && item.kind === "marca" && item.slug.startsWith("lenta-") ? -2 : "kind" in item && item.kind === "marca" && item.slug.startsWith("ociosa-") ? -1 : "kind" in item && item.kind === "chapa" ? 0 : 1;
	return rank(a) - rank(b);
});
function DevLab() {
	const chosen = useChosen();
	const fundo = useBackground();
	const botao = useButton();
	const acordar = useWakeIcon();
	const efeito = useVisorEffect();
	const chapa = useChapa();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [preview, setPreview] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		hydrateChoice();
		hydratePlan();
	}, []);
	function onLaunch() {
		if (open || preview) {
			setOpen(false);
			setPreview(null);
			return;
		}
		setOpen(true);
	}
	const current = concepts.find((item) => item.id === preview);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "dev-launch",
			"aria-label": open || preview ? "Fechar testes" : "Abrir testes",
			"aria-pressed": open || preview != null,
			onClick: onLaunch,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlaskConical, {
				size: 18,
				strokeWidth: 1.75
			})
		}),
		open && preview == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lab-layer",
			role: "dialog",
			"aria-label": "Testes do desenvolvedor",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "lab-kicker",
					children: "Desenvolvedor"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "lab-title",
					children: "Testes"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "lab-note",
					children: "As chapas dos botões vêm primeiro. Cada uma é o fundo real da tecla. Depois vêm a interface, os fundos, os ícones e os efeitos dos visores."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "lab-list",
					children: labOrder.map((item) => {
						const plate = "kind" in item && item.kind === "chapa";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "lab-row",
							onClick: () => setPreview(item.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: plate ? "thumb thumb-chapa" : "thumb",
								"aria-hidden": true,
								children: plate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `speed-redo chapa-${item.slug}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, {
										size: 20,
										strokeWidth: 2.25
									})
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "thumb-inner",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Concept, {
										id: item.id,
										chrome: false
									})
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "lab-num",
									children: String(item.id).padStart(2, "0")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "lab-name",
									children: item.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "lab-line",
									children: item.line
								}),
								inUse(item, {
									chosen,
									fundo,
									botao,
									acordar,
									efeito,
									chapa
								}) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "lab-flag",
									children: "Em uso"
								}) : null
							] })]
						}) }, item.id);
					})
				})
			]
		}) : null,
		preview != null && current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lab-layer p-0",
			role: "dialog",
			"aria-label": current.name,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Concept, { id: preview }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lab-dock",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPreview(null),
					children: "Voltar à lista"
				}), "kind" in current && current.kind === "marca" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "primary",
					onClick: () => chooseConcept(preview),
					children: inUse(current, {
						chosen,
						fundo,
						botao,
						acordar,
						efeito,
						chapa
					}) ? "Em uso" : "Usar esta"
				})]
			})]
		}) : null
	] });
}
var styles_default = "/assets/styles-CE005uu9.css";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Coil Jitter" },
			{
				name: "apple-mobile-web-app-title",
				content: "Coil Jitter"
			},
			{
				name: "theme-color",
				content: "#000000"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "desk",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "desk-note",
					children: "Android · 412 × 892"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "device",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DevLab, {})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter = () => import("./routes-BzEzUWub.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var fileEnv = null;
function readFileEnv() {
	if (fileEnv) return fileEnv;
	fileEnv = {};
	try {
		const text = readFileSync(`${process.cwd()}/.env`, "utf8");
		for (const line of text.split("\n")) {
			const trimmed = line.trim();
			if (!trimmed || trimmed.startsWith("#")) continue;
			const cut = trimmed.indexOf("=");
			if (cut < 1) continue;
			const key = trimmed.slice(0, cut).trim();
			if (!/^[A-Z0-9_]+$/.test(key) || key.startsWith("VITE_")) continue;
			fileEnv[key] = trimmed.slice(cut + 1).trim();
		}
	} catch {}
	return fileEnv;
}
function env(key) {
	return (process.env[key] ?? readFileEnv()[key])?.trim() || void 0;
}
var ASN = {
	TIM: [26615],
	VIVO: [27699, 26599],
	CLARO: [28573, 4230],
	OI: [7738],
	ALGAR: [16735]
};
function plain(value) {
	return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
function open(item) {
	if (!item.endDate) return true;
	const end = Date.parse(item.endDate);
	return Number.isFinite(end) && end > Date.now();
}
function regionHit(item, city, state, uf) {
	const spots = item.locationsDetails ?? [];
	const names = spots.map((spot) => plain(spot.name || ""));
	const codes = spots.map((spot) => (spot.code || "").toUpperCase());
	const ufCode = uf.toUpperCase();
	if (ufCode && codes.some((code) => code === ufCode || code.endsWith(`-${ufCode}`))) return true;
	if ([city, state].map((part) => plain(part)).filter((part) => part.length > 2).some((part) => names.some((name) => name.includes(part)))) return true;
	const places = (item.locations ?? []).map((code) => code.toUpperCase());
	return places.includes("BR") && places.every((code) => code === "BR") && spots.every((spot) => (spot.code || "").toUpperCase() === "BR") && !item.asns?.length;
}
function carrierHit(item, carrier) {
	if ((ASN[carrier] ?? []).some((asn) => item.asns?.includes(asn))) return true;
	const name = plain(carrier);
	return (item.asnsDetails ?? []).some((net) => plain(net.name || "").includes(name));
}
var Route$5 = createFileRoute("/api/outage")({ server: { handlers: { GET: async ({ request }) => {
	const quiet = Response.json({ lines: [] }, { headers: { "cache-control": "no-store" } });
	const token = env("CLOUDFLARE_API_TOKEN");
	if (!token) return quiet;
	const url = new URL(request.url);
	const city = url.searchParams.get("city") || "";
	const state = url.searchParams.get("state") || "";
	const uf = (url.searchParams.get("uf") || "").toUpperCase();
	const carrier = (url.searchParams.get("carrier") || "").toUpperCase();
	try {
		const response = await fetch("https://api.cloudflare.com/client/v4/radar/annotations/outages?dateRange=14d&location=BR&limit=40&format=json", {
			headers: {
				authorization: `Bearer ${token}`,
				accept: "application/json"
			},
			signal: AbortSignal.timeout(3500)
		});
		if (!response.ok) return quiet;
		const data = await response.json();
		const items = (data.result?.annotations ?? data.annotations ?? []).filter(open);
		const lines = [];
		if (items.some((item) => regionHit(item, city, state, uf))) lines.push("Queda aberta na região");
		if (carrier && items.some((item) => carrierHit(item, carrier))) lines.push("Queda aberta na operadora");
		return Response.json({ lines }, { headers: { "cache-control": "no-store" } });
	} catch {
		return quiet;
	}
} } } });
async function pull(url) {
	try {
		const response = await fetch(url, {
			signal: AbortSignal.timeout(3500),
			headers: { accept: "application/json" }
		});
		if (!response.ok) return null;
		return await response.json();
	} catch {
		return null;
	}
}
function cloudflare(data) {
	if (!data || typeof data !== "object") return "sem retorno";
	const indicator = data.status?.indicator;
	if (indicator === "none") return "normal";
	if (indicator === "minor") return "degradada";
	if (indicator === "major") return "parcial";
	if (indicator === "critical") return "fora";
	return "sem retorno";
}
function google(data, gender = "o") {
	if (!Array.isArray(data)) return "sem retorno";
	const open = data.filter((item) => item && typeof item === "object" && !item.end);
	if (open.some((item) => item.severity === "high")) return "fora";
	if (open.some((item) => item.severity === "medium")) return gender === "a" ? "degradada" : "degradado";
	return "normal";
}
function meta(lists) {
	const arrays = lists.filter((list) => Array.isArray(list));
	if (arrays.length === 0) return "sem retorno";
	if (arrays.some((list) => list.length > 0)) return "com falha";
	return "normal";
}
var Route$4 = createFileRoute("/api/pages")({ server: { handlers: { GET: async () => {
	const [cf, g, workspace, search, wa, msg, login] = await Promise.all([
		pull("https://www.cloudflarestatus.com/api/v2/summary.json"),
		pull("https://status.cloud.google.com/incidents.json"),
		pull("https://www.google.com/appsstatus/dashboard/incidents.json"),
		pull("https://status.search.google.com/incidents.json"),
		pull("https://metastatus.com/data/outages/whatsapp-business-api.json"),
		pull("https://metastatus.com/data/outages/messenger.json"),
		pull("https://metastatus.com/data/outages/facebook-login.json")
	]);
	const lines = [
		["Cloudflare", cloudflare(cf)],
		["Google Cloud", google(g)],
		["Google Workspace", google(workspace)],
		["Google Search", google(search, "a")],
		["Meta Business", meta([
			wa,
			msg,
			login
		])]
	].map(([name, level]) => `${name} ${level}`);
	return Response.json({ lines }, { headers: { "cache-control": "no-store" } });
} } } });
var UF = {
	Acre: "AC",
	Alagoas: "AL",
	Amapá: "AP",
	Amazonas: "AM",
	Bahia: "BA",
	Ceará: "CE",
	"Distrito Federal": "DF",
	"Espírito Santo": "ES",
	Goiás: "GO",
	Maranhão: "MA",
	"Mato Grosso": "MT",
	"Mato Grosso do Sul": "MS",
	"Minas Gerais": "MG",
	Pará: "PA",
	Paraíba: "PB",
	Paraná: "PR",
	Pernambuco: "PE",
	Piauí: "PI",
	"Rio de Janeiro": "RJ",
	"Rio Grande do Norte": "RN",
	"Rio Grande do Sul": "RS",
	Rondônia: "RO",
	Roraima: "RR",
	"Santa Catarina": "SC",
	"São Paulo": "SP",
	Sergipe: "SE",
	Tocantins: "TO"
};
var Route$3 = createFileRoute("/api/place")({ server: { handlers: { GET: async ({ request }) => {
	const url = new URL(request.url);
	const lat = Number(url.searchParams.get("lat"));
	const lon = Number(url.searchParams.get("lon"));
	if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return Response.json({
		city: "",
		state: "",
		uf: ""
	}, { status: 400 });
	try {
		const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&accept-language=pt-BR`, {
			signal: AbortSignal.timeout(4e3),
			headers: {
				accept: "application/json",
				"user-agent": "CoilJitter/1.0 (localidade do aparelho)"
			}
		});
		if (!response.ok) return Response.json({
			city: "",
			state: "",
			uf: ""
		}, { status: 502 });
		const address = (await response.json()).address ?? {};
		const city = address.city || address.town || address.municipality || address.village || "";
		const state = address.state || "";
		const uf = (address["ISO3166-2-lvl4"] || "").replace("BR-", "") || UF[state] || "";
		return Response.json({
			city,
			state,
			uf
		}, { headers: { "cache-control": "no-store" } });
	} catch {
		return Response.json({
			city: "",
			state: "",
			uf: ""
		}, { status: 502 });
	}
} } } });
var Route$2 = createFileRoute("/api/reach")({ server: { handlers: { GET: async () => new Response(null, {
	status: 204,
	headers: { "cache-control": "no-store" }
}) } } });
var MAX_BYTES = 12e6;
function randomStream(bytes) {
	let sent = 0;
	return new ReadableStream({ pull(controller) {
		const size = Math.min(65536, bytes - sent);
		const chunk = new Uint8Array(size);
		crypto.getRandomValues(chunk);
		sent += size;
		controller.enqueue(chunk);
		if (sent >= bytes) controller.close();
	} });
}
function noStore(extra) {
	return {
		"cache-control": "no-store, no-transform",
		...Object.fromEntries(new Headers(extra).entries())
	};
}
var Route$1 = createFileRoute("/api/speed")({ server: { handlers: {
	GET: async ({ request }) => {
		const url = new URL(request.url);
		const bytes = Math.min(MAX_BYTES, Math.max(0, Math.floor(Number(url.searchParams.get("bytes")) || 0)));
		return new Response(bytes === 0 ? null : randomStream(bytes), { headers: noStore({
			"content-type": "application/octet-stream",
			"content-length": String(bytes)
		}) });
	},
	POST: async ({ request }) => {
		const body = await request.arrayBuffer();
		return Response.json({ bytes: body.byteLength }, { headers: noStore({ "content-type": "application/json" }) });
	}
} } });
function publicIp(ip) {
	if (/^(\d{1,3}\.){3}\d{1,3}$/.test(ip)) {
		const parts = ip.split(".").map((part) => Number(part));
		if (parts.some((part) => part > 255)) return false;
		const [a, b] = parts;
		if (a === 10 || a === 127 || a === 0) return false;
		if (a === 169 && b === 254) return false;
		if (a === 172 && b >= 16 && b <= 31) return false;
		if (a === 192 && b === 168) return false;
		return true;
	}
	return /^[0-9a-f:]+$/i.test(ip) && ip.includes(":") && ip !== "::1" && !ip.toLowerCase().startsWith("fe80");
}
function pretty(holder) {
	const cut = holder.split(" - ").map((part) => part.trim()).filter(Boolean);
	return (cut.find((part) => /[a-z]/.test(part)) || cut[cut.length - 1] || holder).replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim();
}
var Route = createFileRoute("/api/who")({ server: { handlers: { GET: async ({ request }) => {
	const quiet = Response.json({ name: "" }, { headers: { "cache-control": "no-store" } });
	const ip = new URL(request.url).searchParams.get("ip")?.trim() || "";
	if (!publicIp(ip)) return quiet;
	try {
		const info = await fetch(`https://stat.ripe.net/data/network-info/data.json?resource=${encodeURIComponent(ip)}`, {
			signal: AbortSignal.timeout(3500),
			headers: { accept: "application/json" }
		});
		if (!info.ok) return quiet;
		const asn = (await info.json()).data?.asns?.[0];
		if (!asn) return quiet;
		const over = await fetch(`https://stat.ripe.net/data/as-overview/data.json?resource=AS${encodeURIComponent(asn)}`, {
			signal: AbortSignal.timeout(3500),
			headers: { accept: "application/json" }
		});
		if (!over.ok) return quiet;
		const name = pretty((await over.json()).data?.holder || "");
		return Response.json({ name }, { headers: { "cache-control": "no-store" } });
	} catch {
		return quiet;
	}
} } } });
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	ApiOutageRoute: Route$5.update({
		id: "/api/outage",
		path: "/api/outage",
		getParentRoute: () => Route$7
	}),
	ApiPagesRoute: Route$4.update({
		id: "/api/pages",
		path: "/api/pages",
		getParentRoute: () => Route$7
	}),
	ApiPlaceRoute: Route$3.update({
		id: "/api/place",
		path: "/api/place",
		getParentRoute: () => Route$7
	}),
	ApiReachRoute: Route$2.update({
		id: "/api/reach",
		path: "/api/reach",
		getParentRoute: () => Route$7
	}),
	ApiSpeedRoute: Route$1.update({
		id: "/api/speed",
		path: "/api/speed",
		getParentRoute: () => Route$7
	}),
	ApiWhoRoute: Route.update({
		id: "/api/who",
		path: "/api/who",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Concept as n, useChosen as r, router_exports as t };
