import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, _ as createFileRoute, b as require_jsx_runtime, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as FlaskConical, a as Stethoscope, c as SatelliteDish, d as Radio, f as RadioTower, g as Gauge, h as HeartPulse, i as TestTubes, l as Ruler, m as Microscope, n as TriangleAlert, o as Signal, p as Radar, r as TowerControl, s as ScanSearch, t as Wifi, u as Rss, v as DraftingCompass, y as Antenna } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DdBhx1d1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var CLOUD = "https://speed.cloudflare.com";
var WINDOW_MS = 4e3;
var DOWN_CAP = 12e6;
var PARALLEL = 6;
var UP_BYTES = 5e5;
var UP_PARALLEL = 2;
function mbps(bytes, ms) {
	if (ms < 1 || bytes < 1) return 0;
	return bytes * 8 / ms / 1e3;
}
function median(values) {
	const sorted = [...values].sort((a, b) => a - b);
	const mid = Math.floor(sorted.length / 2);
	return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}
function randomBody(bytes) {
	const buffer = new ArrayBuffer(bytes);
	const payload = new Uint8Array(buffer);
	for (let offset = 0; offset < bytes; offset += 65536) crypto.getRandomValues(payload.subarray(offset, Math.min(bytes, offset + 65536)));
	return buffer;
}
function cloudPaths(stamp) {
	return {
		ping: (i) => `${CLOUD}/__down?bytes=0&r=${stamp}-p${i}`,
		warm: (i) => `${CLOUD}/__down?bytes=400000&r=${stamp}-w${i}`,
		down: (i) => `${CLOUD}/__down?bytes=25000000&r=${stamp}-d${i}`,
		up: `${CLOUD}/__up?r=${stamp}-u`
	};
}
function ownPaths(stamp) {
	return {
		ping: (i) => `/api/speed?bytes=0&r=${stamp}-p${i}`,
		warm: (i) => `/api/speed?bytes=400000&r=${stamp}-w${i}`,
		down: (i) => `/api/speed?bytes=12000000&r=${stamp}-d${i}`,
		up: `/api/speed?r=${stamp}-u`
	};
}
async function cloudReachable() {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 2500);
	try {
		return (await fetch(`${CLOUD}/__down?bytes=0&r=${Date.now()}`, {
			cache: "no-store",
			signal: ctrl.signal
		})).ok;
	} catch {
		return false;
	} finally {
		clearTimeout(timer);
	}
}
async function pull(url, signal, add) {
	const response = await fetch(url, {
		cache: "no-store",
		signal
	});
	if (!response.ok || !response.body) throw new Error("medida falhou");
	const reader = response.body.getReader();
	try {
		while (!signal.aborted) {
			const { done, value } = await reader.read();
			if (done || !value) break;
			add(value.byteLength);
		}
	} catch (error) {
		if (signal.aborted) return;
		throw error;
	} finally {
		reader.cancel().catch(() => {});
	}
}
async function measurePing(url) {
	const samples = [];
	for (let i = 0; i < 5; i++) {
		const start = performance.now();
		const response = await fetch(url(i), { cache: "no-store" });
		if (!response.ok) throw new Error("medida falhou");
		await response.arrayBuffer();
		if (i > 0) samples.push(performance.now() - start);
	}
	let drift = 0;
	for (let i = 1; i < samples.length; i++) drift += Math.abs(samples[i] - samples[i - 1]);
	return {
		ping: median(samples),
		jitter: samples.length > 1 ? drift / (samples.length - 1) : 0
	};
}
function loadedMbps(ticks) {
	if (ticks.length < 2) return 0;
	const first = ticks[0];
	const last = ticks[ticks.length - 1];
	const span = last.t - first.t;
	if (span < 1) return 0;
	const cut = first.t + span * .25;
	const mark = ticks.find((tick) => tick.t >= cut);
	const from = mark && last.t - mark.t >= 600 && last.bytes - mark.bytes >= 6e4 ? mark : first;
	return mbps(last.bytes - from.bytes, last.t - from.t);
}
async function warmDownload(url) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 4e3);
	try {
		await Promise.all(Array.from({ length: PARALLEL }, (_, i) => pull(url(i), ctrl.signal, () => {})));
	} catch {} finally {
		clearTimeout(timer);
		ctrl.abort();
	}
}
async function measureDownload(url) {
	const ctrl = new AbortController();
	const ticks = [];
	let bytes = 0;
	let seq = 0;
	let windowTimer;
	const failsafe = setTimeout(() => ctrl.abort(), 12e3);
	const add = (n) => {
		windowTimer ??= setTimeout(() => ctrl.abort(), WINDOW_MS);
		bytes += n;
		ticks.push({
			t: performance.now(),
			bytes
		});
		if (bytes >= DOWN_CAP) ctrl.abort();
	};
	async function worker() {
		while (!ctrl.signal.aborted && bytes < DOWN_CAP) try {
			await pull(url(seq++), ctrl.signal, add);
		} catch (error) {
			if (ctrl.signal.aborted) return;
			throw error;
		}
	}
	try {
		await Promise.all(Array.from({ length: PARALLEL }, () => worker()));
	} finally {
		clearTimeout(failsafe);
		if (windowTimer) clearTimeout(windowTimer);
		ctrl.abort();
	}
	if (bytes < 5e4 || ticks.length < 2) throw new Error("medida falhou");
	return loadedMbps(ticks);
}
function sendUpload(url, body) {
	return new Promise((resolve, reject) => {
		const xhr = new XMLHttpRequest();
		const timer = setTimeout(() => {
			xhr.abort();
			reject(/* @__PURE__ */ new Error("medida falhou"));
		}, 12e3);
		xhr.open("POST", url);
		xhr.setRequestHeader("content-type", "application/octet-stream");
		xhr.upload.onload = () => {
			clearTimeout(timer);
			resolve();
		};
		xhr.upload.onerror = () => {
			clearTimeout(timer);
			reject(/* @__PURE__ */ new Error("medida falhou"));
		};
		xhr.onerror = () => {
			clearTimeout(timer);
			reject(/* @__PURE__ */ new Error("medida falhou"));
		};
		xhr.send(body);
	});
}
async function measureUpload(url, warm) {
	if (warm) try {
		await sendUpload(url, randomBody(64e3));
	} catch {}
	const bodies = Array.from({ length: UP_PARALLEL }, () => randomBody(UP_BYTES));
	const started = performance.now();
	await Promise.all(bodies.map((body) => sendUpload(url, body)));
	return mbps(UP_BYTES * bodies.length, performance.now() - started);
}
async function timedFetch(url) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 8e3);
	const start = performance.now();
	try {
		const response = await fetch(url, {
			cache: "no-store",
			signal: ctrl.signal
		});
		if (!response.ok) throw new Error("pacote falhou");
		await response.arrayBuffer();
		return performance.now() - start;
	} finally {
		clearTimeout(timer);
	}
}
var IDLE_MS = 1e4;
var lastTraffic = 0;
function touchTraffic() {
	lastTraffic = performance.now();
}
function linkFacts() {
	if (typeof navigator === "undefined" || navigator.onLine === false) return ["Off-line. Sem rede ativa."];
	const lines = ["Rede ativa."];
	const connection = navigator.connection;
	if (!connection) {
		lines.push("O aparelho não informa o tipo.");
		return lines;
	}
	if (connection.type === "wifi") lines.push("Caminho: Wi-fi.");
	else if (connection.type === "cellular") lines.push("Caminho: plano.");
	else if (connection.type === "ethernet") lines.push("Caminho: cabo.");
	else if (connection.type === "bluetooth") lines.push("Caminho: Bluetooth.");
	else if (connection.type === "none") lines.push("Sem interface de rede.");
	else if (connection.type) lines.push("Caminho não identificado.");
	if (connection.effectiveType === "slow-2g" || connection.effectiveType === "2g") lines.push("Geração estimada: 2G. Rede limitada.");
	else if (connection.effectiveType === "3g") lines.push("Geração estimada: 3G. Rede limitada.");
	else if (connection.effectiveType === "4g") lines.push("Geração estimada: 4G ou melhor.");
	if (connection.saveData) lines.push("Economia de dados ligada.");
	if (typeof connection.rtt === "number" && connection.rtt >= 1e3) lines.push(`O aparelho estima resposta muito alta · ${Math.round(connection.rtt)} ms`);
	else if (typeof connection.rtt === "number" && connection.rtt >= 300) lines.push(`O aparelho estima resposta alta · ${Math.round(connection.rtt)} ms`);
	if (typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < .5) lines.push("O aparelho estima a descida muito baixa.");
	else if (typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < 1.5) lines.push("O aparelho estima a descida baixa.");
	return lines;
}
function looksSlow() {
	const connection = navigator.connection;
	if (!connection) return false;
	if (connection.effectiveType === "slow-2g" || connection.effectiveType === "2g" || connection.effectiveType === "3g") return true;
	if (typeof connection.rtt === "number" && connection.rtt >= 300) return true;
	return typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < 1.5;
}
async function sendMicro() {
	const stamp = Date.now();
	try {
		return await timedFetch(`${CLOUD}/__down?bytes=5000&r=${stamp}-prime`);
	} catch {
		return await timedFetch(`/api/speed?bytes=5000&r=${stamp}-prime`);
	}
}
async function primeLink(onStep) {
	const idle = lastTraffic === 0 || performance.now() - lastTraffic > IDLE_MS;
	const slow = looksSlow();
	if (!idle && !slow) return {
		primed: false,
		waitMs: 0
	};
	onStep(idle ? "ociosa" : "lenta");
	await new Promise((resolve) => setTimeout(resolve, 350));
	onStep("pacote");
	const took = await sendMicro();
	const waitMs = Math.round(Math.min(500, Math.max(100, took < 120 ? 180 : took < 300 ? 320 : 480)));
	onStep("espera", waitMs);
	await new Promise((resolve) => setTimeout(resolve, waitMs));
	touchTraffic();
	onStep("pronta");
	return {
		primed: true,
		waitMs
	};
}
async function kickUdp() {
	if (typeof RTCPeerConnection === "undefined") return false;
	const pc = new RTCPeerConnection({ iceServers: [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }] });
	try {
		pc.createDataChannel("coil");
		await pc.setLocalDescription(await pc.createOffer());
		return await new Promise((resolve) => {
			let done = false;
			const finish = (hit) => {
				if (done) return;
				done = true;
				clearTimeout(timer);
				resolve(hit);
			};
			const timer = setTimeout(() => finish(false), 2500);
			pc.onicecandidate = (event) => {
				const cand = event.candidate?.candidate ?? "";
				if (cand.includes("typ srflx") || cand.includes("typ relay")) finish(true);
				else if (!event.candidate) finish(false);
			};
		});
	} catch {
		return false;
	} finally {
		pc.close();
	}
}
async function kick(url) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 4e3);
	try {
		await fetch(url, {
			cache: "no-store",
			mode: "no-cors",
			signal: ctrl.signal
		});
		return true;
	} catch {
		return false;
	} finally {
		clearTimeout(timer);
	}
}
async function pokeNetwork(onStep) {
	const stamp = Date.now();
	const say = (line) => onStep?.(line);
	const base = await cloudReachable() ? `${CLOUD}/__down` : "/api/speed";
	let before = 0;
	let dead = false;
	try {
		before = await timedFetch(`${base}?bytes=0&r=${stamp}-a`);
	} catch {
		dead = true;
	}
	say("Emitindo pulso...");
	try {
		await timedFetch(`${base}?bytes=5000&r=${stamp}-b1`);
	} catch {
		dead = true;
	}
	await new Promise((resolve) => setTimeout(resolve, 200));
	say("Emitindo pulso...");
	try {
		await timedFetch(`${base}?bytes=5000&r=${stamp}-b2`);
	} catch {
		dead = true;
	}
	say("Enviando UDP");
	const udp = await kickUdp();
	const opened = (await Promise.all([
		kick(`${CLOUD}/__down?bytes=1000&r=${stamp}-k1`),
		kick(`https://cp.cloudflare.com/generate_204?r=${stamp}`),
		kick(`https://www.gstatic.com/generate_204?r=${stamp}`),
		kick(`/api/speed?bytes=1000&r=${stamp}-k2`)
	])).filter(Boolean).length;
	for (let beat = 1; beat <= 3; beat++) {
		try {
			await timedFetch(`${base}?bytes=1000&r=${stamp}-beat${beat}`);
		} catch {
			dead = true;
		}
		if (beat < 3) await new Promise((resolve) => setTimeout(resolve, 160));
	}
	await new Promise((resolve) => setTimeout(resolve, 300));
	let after = 0;
	let http = true;
	try {
		after = await timedFetch(`${base}?bytes=0&r=${stamp}-c`);
	} catch {
		http = false;
	}
	const woke = http && !dead && before - after > 100 && after < before * .65;
	touchTraffic();
	return {
		before: Math.round(before),
		after: Math.round(after),
		woke,
		revived: dead && http,
		opened,
		udp,
		http
	};
}
async function diagnosePacket() {
	if (typeof navigator !== "undefined" && navigator.onLine === false) return {
		kind: "off",
		ms: null
	};
	const stamp = Date.now();
	const url = await cloudReachable() ? `${CLOUD}/__down?bytes=0&r=${stamp}-diag` : `/api/speed?bytes=0&r=${stamp}-diag`;
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 3e3);
	const start = performance.now();
	try {
		const response = await fetch(url, {
			cache: "no-store",
			signal: ctrl.signal
		});
		if (!response.ok) throw new Error("pacote falhou");
		await response.arrayBuffer();
		return judgeResponse(performance.now() - start);
	} catch {
		return {
			kind: typeof navigator !== "undefined" && navigator.onLine === false ? "off" : "none",
			ms: null
		};
	} finally {
		clearTimeout(timer);
	}
}
function judgeResponse(ms) {
	const time = Math.round(ms);
	if (time >= 1e3) return {
		kind: "late",
		ms: time
	};
	if (time >= 300) return {
		kind: "slow",
		ms: time
	};
	return {
		kind: "ok",
		ms: time
	};
}
function diagnosisLine(kind, ms) {
	if (kind === "off") return "Sem conexão. O pacote não saiu.";
	if (kind === "none") return "O pacote saiu e não voltou.";
	if (kind === "late") return `Demorou demais · ${ms} ms`;
	if (kind === "slow") return `Respondeu, mas devagar · ${ms} ms`;
	return `Respondeu a tempo · ${ms} ms`;
}
async function openSpeedLane() {
	const stamp = Date.now();
	const cloud = await cloudReachable();
	const paths = cloud ? cloudPaths(stamp) : ownPaths(stamp);
	return {
		async down(warm = false) {
			if (warm) await warmDownload(paths.warm);
			const value = await measureDownload(paths.down);
			touchTraffic();
			return value;
		},
		async up(warm = false) {
			let value;
			try {
				value = await measureUpload(paths.up, warm);
			} catch (error) {
				if (!cloud) throw error;
				value = await measureUpload(ownPaths(stamp).up, false);
			}
			touchTraffic();
			return value;
		},
		async ping() {
			const reading = await measurePing(paths.ping);
			touchTraffic();
			return {
				ping: Math.round(reading.ping),
				jitter: Math.round(reading.jitter)
			};
		}
	};
}
var snapshot = {
	carrier: "Vivo",
	tech: "5G",
	place: "Londrina",
	dbm: -78,
	bars: 3,
	down: 42.6,
	up: 11.4,
	ping: 28,
	usedGb: 6.4,
	capGb: 20,
	renewIn: 12,
	quality: "Boa"
};
var diary = [
	{
		t: "06:58",
		title: "Acordou no Wi-Fi Casa",
		detail: "Sinal cheio"
	},
	{
		t: "07:31",
		title: "Saiu de casa",
		detail: "Passou para Vivo 5G"
	},
	{
		t: "07:40",
		title: "Queda de 11 segundos",
		detail: "No 5G, sozinho"
	},
	{
		t: "07:41",
		title: "Voltou",
		detail: "−81 dBm"
	},
	{
		t: "07:44",
		title: "Agora",
		detail: "−78 dBm · 28 ms"
	}
];
var pulse = [
	22,
	24,
	26,
	25,
	31,
	48,
	36,
	29,
	28,
	27,
	30,
	28,
	26,
	28
];
function br(n, digits = 1) {
	return n.toLocaleString("pt-BR", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	});
}
var concepts = [
	{
		id: 1,
		slug: "campo",
		name: "Campo",
		line: "Rádio de campo. O número em dBm é o herói."
	},
	{
		id: 2,
		slug: "sentenca",
		name: "Sentença",
		line: "Uma frase. O resto só aparece se você pedir."
	},
	{
		id: 3,
		slug: "cockpit",
		name: "Cockpit",
		line: "Quatro instrumentos. Nenhum protagoniza."
	},
	{
		id: 4,
		slug: "franquia",
		name: "Franquia",
		line: "O plano vem primeiro. O sinal é nota de rodapé."
	},
	{
		id: 5,
		slug: "pulso",
		name: "Pulso",
		line: "A latência desenhada ao longo dos minutos."
	},
	{
		id: 6,
		slug: "barras",
		name: "Barras",
		line: "As barrinhas ocupam a tela inteira."
	},
	{
		id: 7,
		slug: "diario",
		name: "Diário",
		line: "O dia da rede, escrito em ordem."
	},
	{
		id: 8,
		slug: "relogio",
		name: "Relógio",
		line: "Um arco, como instrumento de pulso."
	},
	{
		id: 9,
		slug: "cartoes",
		name: "Cartões",
		line: "Três cartões. Um assunto em cada."
	},
	{
		id: 10,
		slug: "faixa",
		name: "Faixa",
		line: "Uma linha de status. O detalhe fica embaixo."
	},
	{
		id: 11,
		slug: "orbita",
		name: "Órbita",
		line: "O sinal é um satélite girando em volta do número."
	},
	{
		id: 12,
		slug: "fosforo",
		name: "Fósforo",
		line: "Terminal de fósforo verde, com varredura de tela."
	},
	{
		id: 13,
		slug: "neon",
		name: "Neon",
		line: "Letreiro aceso. A rede como fachada de noite."
	},
	{
		id: 14,
		slug: "visor",
		name: "Visor",
		line: "HUD de capacete: cantos, mira e leitura fria."
	},
	{
		id: 15,
		slug: "ondas",
		name: "Ondas",
		line: "Três ondas de rádio, uma para cada medida."
	},
	{
		id: 16,
		slug: "selos",
		name: "Selos",
		line: "Um selo carimbado. A rede como correspondência."
	},
	{
		id: 17,
		slug: "ceu",
		name: "Céu",
		line: "Constelação. O ponto mais claro é o agora."
	},
	{
		id: 18,
		slug: "fita",
		name: "Fita",
		line: "Medidores de estúdio. O sinal sobe em segmentos."
	},
	{
		id: 19,
		slug: "grade",
		name: "Grade",
		line: "Uma cidade de células acesas conforme a rede."
	},
	{
		id: 20,
		slug: "luneta",
		name: "Luneta",
		line: "Tudo visto por uma lente redonda."
	},
	{
		id: 21,
		slug: "escovado",
		name: "Escovado",
		kind: "fundo",
		line: "Alumínio escovado, claro, como tampa de aparelho."
	},
	{
		id: 22,
		slug: "aco",
		name: "Aço",
		kind: "fundo",
		line: "Chapa de aço fosco, do tipo painel de instrumento."
	},
	{
		id: 23,
		slug: "anodizado",
		name: "Anodizado",
		kind: "fundo",
		line: "Alumínio anodizado preto, sem brilho de neon."
	},
	{
		id: 24,
		slug: "inox",
		name: "Inox",
		kind: "fundo",
		line: "Aço inoxidável escovado na diagonal."
	},
	{
		id: 25,
		slug: "jateado",
		name: "Jateado",
		kind: "fundo",
		line: "Alumínio jateado, fosco, sem direção de escova."
	},
	{
		id: 26,
		slug: "esmalte",
		name: "Esmalte",
		kind: "fundo",
		line: "Tinta eletrostática grafite, de chassi de equipamento."
	},
	{
		id: 27,
		slug: "fresagem",
		name: "Fresagem",
		kind: "fundo",
		line: "Alumínio escovado na vertical, com risco e reflexo de estúdio."
	},
	{
		id: 28,
		slug: "acovivo",
		name: "Aço vivo",
		kind: "fundo",
		line: "Aço laminado, grão fino e brilho de óleo."
	},
	{
		id: 29,
		slug: "negro",
		name: "Negro",
		kind: "fundo",
		line: "Alumínio anodizado preto, luz raspando a superfície."
	},
	{
		id: 30,
		slug: "espelho",
		name: "Espelho",
		kind: "fundo",
		line: "Inox escovado na diagonal, com reflexo do ambiente."
	},
	{
		id: 31,
		slug: "grao",
		name: "Grão",
		kind: "fundo",
		line: "Alumínio jateado, fosco, grão fechado."
	},
	{
		id: 32,
		slug: "chassi",
		name: "Chassi",
		kind: "fundo",
		line: "Tinta de equipamento, casca de laranja, emenda e parafusos."
	},
	{
		id: 33,
		slug: "liga",
		name: "Liga",
		kind: "fundo",
		line: "Inox do Espelho com a emenda e os parafusos do Chassi."
	},
	{
		id: 34,
		slug: "ferrugem",
		name: "Ferrugem",
		kind: "fundo",
		line: "Aço quase íntegro, com pequenas manchas de corrosão."
	},
	{
		id: 35,
		slug: "gasto",
		name: "Gasto",
		kind: "fundo",
		line: "Alumínio com risco, mancha fosca e oxidação na borda."
	},
	{
		id: 36,
		slug: "zinco",
		name: "Zinco",
		kind: "fundo",
		line: "Chapa galvanizada, corrosão pequena no canto."
	},
	{
		id: 37,
		slug: "parafusos",
		name: "Parafusos",
		kind: "fundo",
		line: "Placa grafite com quatro parafusos allen."
	},
	{
		id: 38,
		slug: "pregos",
		name: "Pregos",
		kind: "fundo",
		line: "Chapa clara com rebites e duas cabeças de prego."
	},
	{
		id: 39,
		slug: "fixacao",
		name: "Fixação",
		kind: "fundo",
		line: "Parafusos e um prego, com ferrugem só em volta deles."
	},
	{
		id: 40,
		slug: "torre",
		name: "Torre",
		kind: "botao",
		line: "Mastro com ondas no topo."
	},
	{
		id: 41,
		slug: "antena",
		name: "Antena",
		kind: "botao",
		line: "Haste única, como antena de rádio."
	},
	{
		id: 42,
		slug: "sinal",
		name: "Sinal",
		kind: "botao",
		line: "Barras crescendo. O sinal em pé."
	},
	{
		id: 43,
		slug: "onda",
		name: "Onda",
		kind: "botao",
		line: "Três arcos saindo de um ponto."
	},
	{
		id: 44,
		slug: "prato",
		name: "Medidor",
		kind: "botao",
		line: "Ponteiro de instrumento. É o ícone atual."
	},
	{
		id: 45,
		slug: "radar",
		name: "Radar",
		kind: "botao",
		line: "Círculo com um braço varrendo."
	},
	{
		id: 46,
		slug: "poste",
		name: "Poste",
		kind: "botao",
		line: "Torre de controle, mais larga que o mastro."
	},
	{
		id: 47,
		slug: "wifi",
		name: "Wi-fi",
		kind: "botao",
		line: "O arco familiar do Wi-fi."
	},
	{
		id: 48,
		slug: "radio",
		name: "Rádio",
		kind: "acordar",
		line: "O rádio de antes."
	},
	{
		id: 49,
		slug: "batida",
		name: "Pulso",
		kind: "acordar",
		line: "Linha de pulso. Diagnóstico."
	},
	{
		id: 50,
		slug: "esteto",
		name: "Esteto",
		kind: "acordar",
		line: "Estetoscópio. Ausculta a rede."
	},
	{
		id: 51,
		slug: "varredura",
		name: "Varredura",
		kind: "acordar",
		line: "Uma busca varrendo o sinal."
	},
	{
		id: 52,
		slug: "lente",
		name: "Lente",
		kind: "acordar",
		line: "Microscópio. Exame de perto."
	},
	{
		id: 53,
		slug: "medidor",
		name: "Prato",
		kind: "acordar",
		line: "Antena parabólica. É o ícone atual."
	},
	{
		id: 54,
		slug: "regua",
		name: "Régua",
		kind: "acordar",
		line: "Medida direta, em escala."
	},
	{
		id: 55,
		slug: "compasso",
		name: "Compasso",
		kind: "acordar",
		line: "Abre o arco e mede."
	},
	{
		id: 56,
		slug: "tubos",
		name: "Tubos",
		kind: "acordar",
		line: "Análise de laboratório."
	},
	{
		id: 57,
		slug: "brilho",
		name: "Brilho",
		kind: "efeito",
		line: "O número ganha um halo de fósforo."
	},
	{
		id: 58,
		slug: "cintilacao",
		name: "Cintilação",
		kind: "efeito",
		line: "O visor pisca leve, como um tubo cansado."
	},
	{
		id: 59,
		slug: "fantasma",
		name: "Fantasma",
		kind: "efeito",
		line: "Uma cópia fraca do texto, um pouco ao lado."
	},
	{
		id: 60,
		slug: "grao",
		name: "Grão",
		kind: "efeito",
		line: "Granulação fina sobre o vidro."
	},
	{
		id: 61,
		slug: "vinheta",
		name: "Vinheta",
		kind: "efeito",
		line: "Os cantos do visor escurecem."
	},
	{
		id: 62,
		slug: "reflexo",
		name: "Reflexo",
		kind: "efeito",
		line: "Um brilho de vidro atravessa o visor."
	},
	{
		id: 63,
		slug: "moldura",
		name: "Moldura",
		kind: "efeito",
		line: "A borda interna acende e apaga."
	},
	{
		id: 64,
		slug: "linhas",
		name: "Linhas",
		kind: "efeito",
		line: "As linhas do tubo ficam mais fortes e descem."
	},
	{
		id: 65,
		slug: "nucleo",
		name: "Núcleo",
		kind: "efeito",
		line: "Um clarão parado atrás do número."
	},
	{
		id: 66,
		slug: "poeira",
		name: "Poeira",
		kind: "efeito",
		line: "Pontos pequenos parados no vidro."
	},
	{
		id: 67,
		slug: "vidro",
		name: "Vidro",
		kind: "efeito",
		line: "Reflexo fixo de vidro curvo no topo."
	},
	{
		id: 68,
		slug: "quente",
		name: "Quente",
		kind: "efeito",
		line: "O centro mais claro e a borda mais escura."
	},
	{
		id: 69,
		slug: "batida",
		name: "Batida",
		kind: "efeito",
		line: "O visor inteiro respira em brilho."
	},
	{
		id: 70,
		slug: "eco",
		name: "Eco",
		kind: "efeito",
		line: "O texto se repete, cada vez mais fraco."
	},
	{
		id: 71,
		slug: "neblina",
		name: "Neblina",
		kind: "efeito",
		line: "Uma névoa leve por cima do vidro."
	},
	{
		id: 72,
		slug: "polido",
		name: "Polido",
		kind: "chapa",
		line: "Alumínio novo. Sem marca de uso."
	},
	{
		id: 73,
		slug: "escova",
		name: "Escova",
		kind: "chapa",
		line: "Aço escovado na horizontal, ainda limpo."
	},
	{
		id: 74,
		slug: "jato",
		name: "Jato",
		kind: "chapa",
		line: "Fosco jateado. Quase nenhum brilho."
	},
	{
		id: 75,
		slug: "chumbo",
		name: "Chumbo",
		kind: "chapa",
		line: "Grafite escuro, liso, pouco manuseado."
	},
	{
		id: 76,
		slug: "frio",
		name: "Frio",
		kind: "chapa",
		line: "Inox com reflexo frio na diagonal."
	},
	{
		id: 77,
		slug: "niquel",
		name: "Níquel",
		kind: "chapa",
		line: "Metal morno, com um véu leve de dedo."
	},
	{
		id: 78,
		slug: "bronze",
		name: "Bronze",
		kind: "chapa",
		line: "Bronze escuro. Pátina só num canto."
	},
	{
		id: 79,
		slug: "oleo",
		name: "Óleo",
		kind: "chapa",
		line: "Aço com véu de óleo e uma marca de dedo."
	},
	{
		id: 80,
		slug: "dedos",
		name: "Dedos",
		kind: "chapa",
		line: "As bordas escureceram de tanto toque."
	},
	{
		id: 81,
		slug: "uso",
		name: "Uso",
		kind: "chapa",
		line: "Centro mais claro. Os cantos já gastaram."
	},
	{
		id: 82,
		slug: "oxido",
		name: "Óxido",
		kind: "chapa",
		line: "Zinco com pontos brancos de oxidação."
	},
	{
		id: 83,
		slug: "patina",
		name: "Pátina",
		kind: "chapa",
		line: "Bronze com verde só na borda."
	},
	{
		id: 84,
		slug: "pinta",
		name: "Pinta",
		kind: "chapa",
		line: "Aço com pintas pequenas de ferrugem."
	},
	{
		id: 85,
		slug: "tempera",
		name: "Têmpera",
		kind: "chapa",
		line: "Aço queimado. Azul e marrom de calor."
	},
	{
		id: 86,
		slug: "sucata",
		name: "Sucata",
		kind: "chapa",
		line: "O mais usado: escuro, manchado, ferrugem na quina."
	}
];
var KEY$1 = "sinal-interface";
var FUNDO_KEY = "coil-fundo";
var BOTAO_KEY = "coil-botao";
var ACORDAR_KEY = "coil-acordar";
var EFEITO_KEY = "coil-efeito";
var CHAPA_KEY = "coil-chapa";
var DEFAULT_ID = 4;
var DEFAULT_FUNDO = 32;
var DEFAULT_BOTAO = 44;
var DEFAULT_ACORDAR = 53;
var DEFAULT_EFEITO = 60;
var chosen = DEFAULT_ID;
var fundo$1 = DEFAULT_FUNDO;
var botao$1 = DEFAULT_BOTAO;
var acordar$1 = DEFAULT_ACORDAR;
var efeito = DEFAULT_EFEITO;
var chapa$1 = null;
var listeners$1 = /* @__PURE__ */ new Set();
function emit$1() {
	listeners$1.forEach((listener) => listener());
}
function subscribeChoice(listener) {
	listeners$1.add(listener);
	return () => listeners$1.delete(listener);
}
function getChosen() {
	return chosen;
}
function getServerChosen() {
	return DEFAULT_ID;
}
function hasKind(id, kind) {
	return concepts.some((item) => item.id === id && "kind" in item && item.kind === kind);
}
function isFundo(id) {
	return hasKind(id, "fundo");
}
function isBotao(id) {
	return hasKind(id, "botao");
}
function isAcordar(id) {
	return hasKind(id, "acordar");
}
function isEfeito(id) {
	return hasKind(id, "efeito");
}
function isChapa(id) {
	return hasKind(id, "chapa");
}
function isTela(id) {
	return concepts.some((item) => item.id === id && !isFundo(id) && !isBotao(id) && !isAcordar(id) && !isEfeito(id) && !isChapa(id));
}
function hydrateChoice() {
	const n = Number(localStorage.getItem(KEY$1));
	chosen = isTela(n) ? n : DEFAULT_ID;
	if (!isTela(n)) localStorage.setItem(KEY$1, String(DEFAULT_ID));
	const f = Number(localStorage.getItem(FUNDO_KEY));
	fundo$1 = isFundo(f) ? f : DEFAULT_FUNDO;
	const b = Number(localStorage.getItem(BOTAO_KEY));
	botao$1 = isBotao(b) ? b : DEFAULT_BOTAO;
	const a = Number(localStorage.getItem(ACORDAR_KEY));
	acordar$1 = isAcordar(a) ? a : DEFAULT_ACORDAR;
	const e = Number(localStorage.getItem(EFEITO_KEY));
	efeito = isEfeito(e) ? e : DEFAULT_EFEITO;
	const c = Number(localStorage.getItem(CHAPA_KEY));
	chapa$1 = isChapa(c) ? c : null;
	emit$1();
}
function chooseConcept(id) {
	if (isFundo(id)) {
		fundo$1 = id;
		localStorage.setItem(FUNDO_KEY, String(id));
		emit$1();
		return;
	}
	if (isBotao(id)) {
		botao$1 = id;
		localStorage.setItem(BOTAO_KEY, String(id));
		emit$1();
		return;
	}
	if (isAcordar(id)) {
		acordar$1 = id;
		localStorage.setItem(ACORDAR_KEY, String(id));
		emit$1();
		return;
	}
	if (isEfeito(id)) {
		efeito = id;
		localStorage.setItem(EFEITO_KEY, String(id));
		emit$1();
		return;
	}
	if (isChapa(id)) {
		chapa$1 = id;
		localStorage.setItem(CHAPA_KEY, String(id));
		emit$1();
		return;
	}
	chosen = id;
	localStorage.setItem(KEY$1, String(id));
	emit$1();
}
function useChosen() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, getChosen, getServerChosen);
}
function useBackground() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, () => fundo$1, () => DEFAULT_FUNDO);
}
function useButton() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, () => botao$1, () => DEFAULT_BOTAO);
}
function useWakeIcon() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, () => acordar$1, () => DEFAULT_ACORDAR);
}
function useVisorEffect() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, () => efeito, () => DEFAULT_EFEITO);
}
function useChapa() {
	return (0, import_react.useSyncExternalStore)(subscribeChoice, () => chapa$1, () => null);
}
function useRandomFlicker(active = true) {
	const [ms, setMs] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!active) return;
		let alive = true;
		let timer = 0;
		const play = () => {
			if (!alive) return;
			const dur = 1700 + Math.random() * 700;
			setMs(dur);
			timer = window.setTimeout(() => {
				if (!alive) return;
				setMs(null);
				timer = window.setTimeout(play, 250 + Math.random() * 3250);
			}, dur);
		};
		timer = window.setTimeout(play, 250 + Math.random() * 3250);
		return () => {
			alive = false;
			window.clearTimeout(timer);
		};
	}, [active]);
	return ms;
}
function SegNum({ value }) {
	const comma = value.indexOf(",");
	if (comma < 0) return value;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		value.slice(0, comma).replaceAll(".", ""),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
			className: "seg-dec",
			children: ","
		}),
		value.slice(comma + 1)
	] });
}
function segLong(value) {
	return value.replace(/\D/g, "").length >= 5;
}
function Shell({ slug, chrome, children, bare, live, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: `concept concept-${slug} ${chrome ? "concept-chrome" : ""} ${live ? "concept-live" : ""} ${tone ? `bg-${tone}` : ""} ${bare ? "" : "px-5 pb-28 pt-5"}`,
		children
	});
}
function Kicker({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "c-muted text-xs tracking-widest uppercase",
		children
	});
}
function Campo({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "campo",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: [
				"Campo · ",
				snapshot.carrier,
				" ",
				snapshot.tech
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto mt-10 grid h-56 w-56 place-items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 200 200",
					className: "absolute inset-0 h-full w-full",
					"aria-hidden": true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "92",
							className: "ring ring-dim"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "68",
							className: "ring ring-dim"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "44",
							className: "ring ring-hot"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-accent text-5xl leading-none tabular-nums",
						children: snapshot.dbm
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted mt-1 text-xs tracking-widest",
						children: "dBm"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-10 grid grid-cols-3 gap-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted text-xs",
						children: "Desce"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-lg tabular-nums",
						children: br(snapshot.down)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted text-xs",
						children: "Sobe"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-lg tabular-nums",
						children: br(snapshot.up)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted text-xs",
						children: "Ping"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-lg tabular-nums",
						children: snapshot.ping
					})] })
				]
			})
		]
	});
}
function Sentenca({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "sentenca",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: snapshot.place }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 text-6xl leading-none tracking-tight",
				children: "Sinal bom."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-6 max-w-xs text-2xl leading-snug",
				children: [
					snapshot.carrier,
					" ",
					snapshot.tech,
					", ",
					snapshot.dbm,
					" dBm."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "c-rule mt-16 grid grid-cols-3 gap-4 border-t pt-5 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted",
						children: "Ping"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 tabular-nums",
						children: [snapshot.ping, " ms"]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted",
						children: "Desce"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 tabular-nums",
						children: br(snapshot.down)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "c-muted",
						children: "Plano"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 tabular-nums",
						children: [br(snapshot.usedGb), " GB"]
					})] })
				]
			})
		]
	});
}
function Cockpit({ chrome }) {
	const tiles = [
		{
			k: "Sinal",
			v: `${snapshot.bars}/4`,
			u: `${snapshot.dbm} dBm`
		},
		{
			k: "Ping",
			v: String(snapshot.ping),
			u: "ms"
		},
		{
			k: "Desce",
			v: br(snapshot.down),
			u: "Mb/s"
		},
		{
			k: "Sobe",
			v: br(snapshot.up),
			u: "Mb/s"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "cockpit",
		chrome,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Cockpit · ", snapshot.tech] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 grid grid-cols-2 gap-3",
			children: tiles.map((tile) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "c-surface rounded-xl px-3 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted text-xs tracking-widest uppercase",
						children: tile.k
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-accent mt-3 text-4xl leading-none tabular-nums",
						children: tile.v
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted mt-2 text-xs",
						children: tile.u
					})
				]
			}, tile.k))
		})]
	});
}
function Franquia({ chrome, actions }) {
	const fundo = useBackground();
	const botao = useButton();
	const acordar = useWakeIcon();
	const efeito = useVisorEffect();
	const chapa = useChapa();
	const RedoIcon = redoIcons[botao] ?? RadioTower;
	const WakeIcon = wakeIcons[acordar] ?? Radio;
	const tone = concepts.find((item) => item.id === fundo)?.slug;
	const efeitoClass = efeito ? `efeito-${concepts.find((item) => item.id === efeito)?.slug ?? ""}` : "";
	const chapaClass = chapa ? `chapa-${concepts.find((item) => item.id === chapa)?.slug ?? ""}` : "";
	const [link, setLink] = (0, import_react.useState)(null);
	const [net, setNet] = (0, import_react.useState)(null);
	const [reading, setReading] = (0, import_react.useState)("idle");
	const [poking, setPoking] = (0, import_react.useState)(false);
	const runRef = (0, import_react.useRef)(false);
	const medirHeld = (0, import_react.useRef)(false);
	const wakeHeld = (0, import_react.useRef)(false);
	const pokingRef = (0, import_react.useRef)(false);
	const queueRef = (0, import_react.useRef)([]);
	const shownRef = (0, import_react.useRef)({
		state: "Pronto",
		doing: "Carregando bobina..."
	});
	const timerRef = (0, import_react.useRef)(null);
	const holdRef = (0, import_react.useRef)(false);
	const litRef = (0, import_react.useRef)(false);
	const tuneRef = (0, import_react.useRef)(false);
	const [shown, setShown] = (0, import_react.useState)(shownRef.current);
	const visorFx = efeitoClass === "efeito-grao" && shown.doing === "Carregando bobina..." ? "" : efeitoClass;
	const [fadeKey, setFadeKey] = (0, import_react.useState)(0);
	const [lit, setLit] = (0, import_react.useState)(false);
	const [tune, setTune] = (0, import_react.useState)(false);
	const [diag, setDiag] = (0, import_react.useState)("");
	const [diagKey, setDiagKey] = (0, import_react.useState)(0);
	const diagQueue = (0, import_react.useRef)([]);
	const diagTimer = (0, import_react.useRef)(null);
	const diagShown = (0, import_react.useRef)("");
	const flick = useRandomFlicker();
	function playDiag() {
		if (diagTimer.current !== null) return;
		const next = diagQueue.current.shift();
		if (!next) return;
		diagShown.current = next;
		setDiag(next);
		setDiagKey((n) => n + 1);
		diagTimer.current = window.setTimeout(() => {
			diagTimer.current = null;
			playDiag();
		}, 1800);
	}
	function tell(line) {
		if ((diagQueue.current.at(-1) ?? diagShown.current) === line) return;
		diagQueue.current.push(line);
		playDiag();
	}
	function tellNow(line) {
		diagQueue.current = [];
		if (diagTimer.current !== null) {
			window.clearTimeout(diagTimer.current);
			diagTimer.current = null;
		}
		diagShown.current = "";
		tell(line);
	}
	function releaseLight() {
		if (holdRef.current || timerRef.current !== null || queueRef.current.length > 0) return;
		if (!litRef.current) return;
		litRef.current = false;
		setLit(false);
		if (tuneRef.current) {
			tuneRef.current = false;
			setTune(false);
		}
	}
	function playNext() {
		if (timerRef.current !== null) return;
		const next = queueRef.current.shift();
		if (!next) {
			releaseLight();
			return;
		}
		shownRef.current = next;
		setShown(next);
		setFadeKey((n) => n + 1);
		timerRef.current = window.setTimeout(() => {
			timerRef.current = null;
			playNext();
		}, 500);
	}
	function say(state, doing) {
		const last = queueRef.current.at(-1) ?? shownRef.current;
		if (last.state === state && last.doing === doing) return;
		queueRef.current.push({
			state,
			doing
		});
		playNext();
	}
	function beginLight() {
		holdRef.current = true;
		if (litRef.current) return;
		litRef.current = true;
		setLit(true);
	}
	function beginTune() {
		tuneRef.current = true;
		setTune(true);
		beginLight();
	}
	function endLight() {
		holdRef.current = false;
		releaseLight();
	}
	(0, import_react.useEffect)(() => {
		timerRef.current = window.setTimeout(() => {
			timerRef.current = null;
			playNext();
		}, 500);
		const report = () => say("Pronto", navigator.onLine ? "On-line" : "Off-line");
		const bootOnline = actions && navigator.onLine;
		if (!bootOnline) {
			if (document.readyState === "complete") report();
			else window.addEventListener("load", report, { once: true });
		}
		window.addEventListener("online", report);
		window.addEventListener("offline", report);
		const releaseHold = () => {
			medirHeld.current = false;
			wakeHeld.current = false;
		};
		window.addEventListener("pointerup", releaseHold);
		window.addEventListener("pointercancel", releaseHold);
		let alive = true;
		const boot = window.setTimeout(() => {
			if (alive && bootOnline) measure();
		}, 0);
		return () => {
			alive = false;
			window.clearTimeout(boot);
			window.removeEventListener("load", report);
			window.removeEventListener("online", report);
			window.removeEventListener("offline", report);
			window.removeEventListener("pointerup", releaseHold);
			window.removeEventListener("pointercancel", releaseHold);
			if (timerRef.current !== null) window.clearTimeout(timerRef.current);
			if (diagTimer.current !== null) window.clearTimeout(diagTimer.current);
		};
	}, []);
	const down = link?.down ?? null;
	const up = link?.up ?? null;
	const ping = link?.ping ?? null;
	const jitter = link?.jitter ?? null;
	const downText = reading === "busy" && down == null ? "…" : down != null ? br(down) : "_";
	const upText = reading === "busy" && up == null ? "…" : up != null ? br(up) : "—";
	const pingText = reading === "busy" && ping == null ? "…" : ping != null ? String(ping) : "—";
	const jitterText = reading === "busy" && jitter == null ? "…" : jitter != null ? String(jitter) : "—";
	const netText = reading === "busy" && net == null ? "…" : net ?? "—";
	const blinking = (text) => text === "—" || text === "…" || text === "_";
	const sweeping = lit && !tune;
	function pause() {
		return new Promise((resolve) => setTimeout(resolve, 1e3));
	}
	async function measure() {
		if (runRef.current || pokingRef.current) return;
		runRef.current = true;
		beginLight();
		const kind = navigator.connection?.type;
		const pc = !navigator.userAgentData?.mobile && !/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
		setNet(pc || kind === "wifi" || kind === "ethernet" ? "Wi-fi" : kind === "cellular" ? "Plano" : null);
		setReading("busy");
		setLink(null);
		let down = null;
		let up = null;
		let cause = "O pacote saiu e não voltou.";
		async function cycle() {
			if (navigator.onLine === false) {
				cause = "Sem conexão. O pacote não saiu.";
				throw new Error("off");
			}
			let lane = null;
			const path = async () => lane ??= await openSpeedLane();
			if (down == null) {
				cause = "O pacote saiu e não voltou.";
				tellNow("Enviando pacote...");
				const probe = await diagnosePacket();
				tellNow(diagnosisLine(probe.kind, probe.ms));
				if (probe.kind === "off" || probe.kind === "none") {
					cause = diagnosisLine(probe.kind, probe.ms);
					throw new Error("diag");
				}
				cause = "A descida não voltou.";
				const prime = await primeLink((step) => {
					say("Medindo", step === "ociosa" ? "Rede ociosa" : step === "lenta" ? "Rede lenta" : step === "pacote" ? "Preparando medição..." : step === "espera" ? "Aguardando retorno" : "Conexão iniciada");
				});
				say("Medindo", prime.primed ? "Conexão iniciada" : "Rede ativa");
				if (prime.primed) tell(`Esperou ${prime.waitMs} ms`);
				const road = await path();
				say("Medindo", "Recebendo dados...");
				const down1 = await road.down(true);
				await pause();
				down = (down1 + await road.down(false)) / 2;
				setLink({
					down,
					up: null,
					ping: null,
					jitter: null
				});
			}
			if (up == null) {
				cause = "A subida não voltou.";
				const road = await path();
				say("Medindo", "Transferindo dados...");
				const up1 = await road.up(true);
				await pause();
				up = (up1 + await road.up(false)) / 2;
				setLink({
					down,
					up,
					ping: null,
					jitter: null
				});
				await pause();
			}
			cause = "O ping não voltou.";
			const road = await path();
			say("Medindo", "Calculando latência...");
			const ping1 = await road.ping();
			setLink({
				down,
				up,
				ping: ping1.ping,
				jitter: ping1.jitter
			});
			await pause();
			const ping2 = await road.ping();
			const ping = Math.round((ping1.ping + ping2.ping) / 2);
			const jitter = Math.round((ping1.jitter + ping2.jitter) / 2);
			setLink({
				down,
				up,
				ping,
				jitter
			});
			const reply = judgeResponse(ping);
			tellNow(diagnosisLine(reply.kind, reply.ms));
			for (const line of linkFacts()) tell(line);
			say("Pronto", navigator.onLine ? "On-line" : "Off-line");
			setReading("idle");
		}
		try {
			try {
				await cycle();
			} catch {
				await cycle();
			}
		} catch {
			tellNow(cause);
			for (const line of linkFacts()) tell(line);
			say("Falhou", "Medição sem sucesso");
			setReading("none");
		} finally {
			runRef.current = false;
			endLight();
			if (medirHeld.current) measure();
			else if (wakeHeld.current) wake();
		}
	}
	function wake() {
		if (runRef.current || pokingRef.current) return;
		pokingRef.current = true;
		beginTune();
		setPoking(true);
		pokeNetwork((line) => say("Sintonizar", line)).then((result) => {
			say("Sintonizar", !result.http && result.udp ? "UDP retornou sem HTTP" : !result.http ? "Não respondeu" : result.revived ? `Voltou a responder · ${result.after} ms` : result.woke ? `Mais rápido · ${result.before} → ${result.after} ms` : result.udp ? `Respondeu · ${result.after} ms · UDP saiu` : `Respondeu · ${result.after} ms · igual`);
		}).catch(() => say("Sintonizar", "Não respondeu")).finally(() => {
			pokingRef.current = false;
			setPoking(false);
			endLight();
			if (wakeHeld.current) wake();
			else if (medirHeld.current) measure();
		});
	}
	const pointerUsed = (0, import_react.useRef)(false);
	function holdStart(which, event) {
		if (event.button !== 0) return;
		event.preventDefault();
		pointerUsed.current = true;
		if (which === "medir") medirHeld.current = true;
		else wakeHeld.current = true;
		if (which === "medir") measure();
		else wake();
	}
	function holdEnd(which) {
		if (which === "medir") medirHeld.current = false;
		else wakeHeld.current = false;
		window.setTimeout(() => {
			pointerUsed.current = false;
		}, 0);
	}
	function pressClick(which) {
		if (pointerUsed.current) {
			pointerUsed.current = false;
			return;
		}
		if (which === "medir") measure();
		else wake();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		slug: "franquia",
		chrome,
		bare: actions,
		live: actions,
		tone: actions ? tone : void 0,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: actions ? "flex h-full flex-col px-5 pt-16" : "",
			children: [actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "plate-name",
				"aria-label": "Coil Jitter",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Coil Jitter" })
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: actions ? "coil-grid" : void 0,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: actions ? "coil-span" : void 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `speed-square ${visorFx} ${sweeping ? "is-waking" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `fosforo-figure is-fading${segLong(downText) ? " is-long" : ""}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: blinking(downText) ? "caret" : "",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: downText })
									})
								}, downText),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "fosforo-unit",
									children: "Mb/s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
									className: "fosforo-scan",
									"aria-hidden": true
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "coil-sweep",
								"aria-hidden": true
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "speed-side",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `speed-chip ${visorFx} ${sweeping ? "is-waking" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "is-fading",
									children: [
										"sobe ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `seg-num ${blinking(upText) ? "caret" : ""}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: upText })
										}),
										" Mb/s"
									]
								}, `sobe-${upText}`),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "is-fading",
									children: [
										"ping ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `seg-num ${blinking(pingText) ? "caret" : ""}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: pingText })
										}),
										" ms"
									]
								}, `ping-${pingText}`),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "is-fading",
									children: [
										"jitter ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `seg-num ${blinking(jitterText) ? "caret" : ""}`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: jitterText })
										}),
										" ms"
									]
								}, `jitter-${jitterText}`),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
									className: "fosforo-scan",
									"aria-hidden": true
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "coil-sweep",
								"aria-hidden": true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `speed-chip ${visorFx} ${sweeping ? "is-waking" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "is-fading",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: blinking(netText) ? "caret" : "",
									children: netText
								})
							}, netText), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "fosforo-scan",
								"aria-hidden": true
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "coil-sweep",
								"aria-hidden": true
							})]
						})]
					}),
					actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "plate-key",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `speed-redo is-off ${chapaClass} ${reading === "busy" ? "is-busy" : ""}`,
							"aria-label": "Medir",
							onPointerDown: (event) => holdStart("medir", event),
							onPointerUp: () => holdEnd("medir"),
							onPointerCancel: () => holdEnd("medir"),
							onContextMenu: (event) => event.preventDefault(),
							onClick: () => pressClick("medir"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedoIcon, {
								size: 22,
								strokeWidth: 2.25
							})
						})
					}) : null,
					actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: `clock-field coil-span ${visorFx} ${lit ? "is-waking" : ""}`,
							"aria-label": `Visor de Estado. ${shown.doing}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "clock-readout",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `clock-copy ${fadeKey ? "is-fading" : ""}`,
									children: [shown.state === "Pronto" || shown.state === "Medindo" || shown.state === "Sintonizar" || shown.state === "Falhou" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `clock-state ${flick ? "is-flick" : ""}`,
										style: flick ? { ["--flick"]: `${flick}ms` } : void 0,
										children: shown.state
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `clock-doing ${flick ? "is-flick" : ""}`,
										style: flick ? { ["--flick"]: `${flick}ms` } : void 0,
										children: shown.doing
									})]
								}, fadeKey)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "coil-sweep",
								"aria-hidden": true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: `clock-field clock-extra coil-span ${visorFx} ${sweeping ? "is-waking" : ""}`,
							"aria-label": diag || "Diagnóstico",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "clock-readout",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `clock-copy ${diagKey ? "is-fading" : ""}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `clock-doing ${flick ? "is-flick" : ""}`,
										style: flick ? { ["--flick"]: `${flick}ms` } : void 0,
										children: diag
									})
								}, diagKey)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "coil-sweep",
								"aria-hidden": true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "plate-key is-wake",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `speed-redo wake-redo is-off ${chapaClass} ${poking ? "is-busy" : ""}`,
								"aria-label": "Sintonizar",
								onPointerDown: (event) => holdStart("wake", event),
								onPointerUp: () => holdEnd("wake"),
								onPointerCancel: () => holdEnd("wake"),
								onContextMenu: (event) => event.preventDefault(),
								onClick: () => pressClick("wake"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WakeIcon, {
									size: 22,
									strokeWidth: 2.25
								})
							})
						})
					] }) : null
				]
			})]
		})
	});
}
function Pulso({ chrome }) {
	const w = 320;
	const h = 96;
	const max = Math.max(...pulse);
	const min = Math.min(...pulse);
	const d = pulse.map((v, i) => {
		const x = i / (pulse.length - 1) * w;
		const y = h - (v - min) / (max - min) * 88 - 4;
		return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
	}).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "pulso",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Pulso" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-6xl leading-none tabular-nums tracking-tight",
				children: [snapshot.ping, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "c-muted text-2xl",
					children: " ms"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: `0 0 ${w} ${h}`,
				className: "mt-8 h-24 w-full",
				"aria-hidden": true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d,
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					className: "c-accent"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "c-muted mt-3 text-sm",
				children: "Latência nos últimos minutos."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "c-accent mt-6 text-sm",
				children: "Pico de 48 ms às 07:40, na queda."
			})
		]
	});
}
function Barras({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "barras",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Barras" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 flex h-72 items-end gap-3",
				children: [
					1,
					2,
					3,
					4
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `flex-1 rounded-sm ${i <= snapshot.bars ? "c-fill" : "c-track"}`,
					style: { height: `${22 + i * 18}%` }
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-3xl leading-none",
				children: "Três de quatro."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-3 text-sm",
				children: [
					snapshot.carrier,
					" · ",
					snapshot.tech,
					" · ",
					snapshot.dbm,
					" dBm"
				]
			})
		]
	});
}
function Diario({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "diario",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Sexta, 2 de outubro" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "c-serif mt-3 text-4xl leading-none tracking-tight",
				children: "Diário da rede"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8",
				children: diary.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid grid-cols-[3.2rem_1fr] gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted pt-3 text-xs tabular-nums",
						children: item.t
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `c-rule py-3 ${index ? "border-t" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "c-muted text-sm",
							children: item.detail
						})]
					})]
				}, item.t))
			})
		]
	});
}
function Relogio({ chrome }) {
	const pct = .68;
	const r = 78;
	const circ = 2 * Math.PI * r;
	const dash = circ * pct;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "relogio",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Relógio · ", snapshot.carrier] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto mt-8 grid h-64 w-64 place-items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 200 200",
					className: "h-full w-full",
					"aria-hidden": true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r,
						className: "arc-track"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r,
						className: "arc-value",
						strokeDasharray: `${dash} ${circ - dash}`,
						transform: "rotate(-90 100 100)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-serif text-5xl leading-none",
						children: snapshot.quality
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "c-muted mt-2 text-sm tabular-nums",
						children: [snapshot.dbm, " dBm"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-6 text-center text-sm",
				children: [
					snapshot.tech,
					" · ",
					snapshot.ping,
					" ms · ",
					br(snapshot.down),
					" Mb/s"
				]
			})
		]
	});
}
function Cartoes({ chrome }) {
	const cards = [
		{
			k: "Sinal",
			v: snapshot.quality,
			s: `${snapshot.bars} de 4 · ${snapshot.dbm} dBm`
		},
		{
			k: "Velocidade",
			v: `${br(snapshot.down)} Mb/s`,
			s: `sobe ${br(snapshot.up)} · ping ${snapshot.ping} ms`
		},
		{
			k: "Plano",
			v: `${br(snapshot.usedGb)} GB`,
			s: `de ${snapshot.capGb} GB · ${snapshot.carrier}`
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "cartoes",
		chrome,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Cartões" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 flex flex-col gap-3",
			children: cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "c-surface rounded-2xl px-4 py-4 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "c-muted text-xs tracking-widest uppercase",
						children: card.k
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-3xl leading-none tracking-tight",
						children: card.v
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "c-muted mt-2 text-sm",
						children: card.s
					})
				]
			}, card.k))
		})]
	});
}
function Faixa({ chrome }) {
	const [open, setOpen] = (0, import_react.useState)(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "faixa",
		chrome,
		bare: true,
		children: [chrome ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "c-strip flex w-full items-center justify-between px-5 py-4 text-left",
			onClick: () => setOpen((v) => !v),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm font-medium",
				children: [
					snapshot.carrier,
					" ",
					snapshot.tech
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm tabular-nums",
				children: [snapshot.ping, " ms"]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "c-strip flex w-full items-center justify-between px-5 py-4 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm font-medium",
				children: [
					snapshot.carrier,
					" ",
					snapshot.tech
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm tabular-nums",
				children: [snapshot.ping, " ms"]
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-5 pb-28 pt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Por baixo da faixa" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-4xl leading-none tracking-tight",
					children: snapshot.quality
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "c-muted mt-3 text-sm",
					children: [
						snapshot.dbm,
						" dBm · desce ",
						br(snapshot.down),
						" · plano ",
						br(snapshot.usedGb),
						" de ",
						snapshot.capGb,
						" GB"
					]
				})
			]
		}) : null]
	});
}
function wavePath(amp, phase) {
	let d = "";
	for (let x = 0; x <= 320; x += 8) {
		const y = 28 + Math.sin(x / 320 * Math.PI * 3 + phase) * amp;
		d += `${x === 0 ? "M" : "L"}${x} ${y.toFixed(1)} `;
	}
	return d;
}
function Orbita({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "orbita",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Órbita · ", snapshot.tech] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto mt-8 grid h-64 w-64 place-items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 200 200",
					className: "absolute inset-0 h-full w-full",
					"aria-hidden": true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "100",
							cy: "100",
							rx: "88",
							ry: "32",
							className: "ring ring-dim",
							transform: "rotate(-22 100 100)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "100",
							cy: "100",
							rx: "70",
							ry: "26",
							className: "ring ring-dim",
							transform: "rotate(28 100 100)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
							cx: "100",
							cy: "100",
							rx: "46",
							ry: "18",
							className: "ring ring-hot"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
							className: "orbit-spin",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "100",
								cy: "18",
								r: "4",
								fill: "currentColor",
								className: "c-accent"
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "glow c-accent text-5xl leading-none tabular-nums",
						children: snapshot.dbm
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted mt-1 text-xs",
						children: "dBm"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-6 text-center text-sm",
				children: [
					snapshot.carrier,
					" · ping ",
					snapshot.ping,
					" ms"
				]
			})
		]
	});
}
function Fosforo({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "fosforo",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["link / ", snapshot.carrier.toLowerCase()] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "glow c-accent mt-8 text-6xl leading-none tabular-nums",
				children: [snapshot.tech, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "caret",
					children: "_"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-8 space-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"rssi ",
						snapshot.dbm,
						" dBm"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"rtt ",
						snapshot.ping,
						" ms"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"down ",
						br(snapshot.down),
						" Mb/s"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "c-muted",
						children: [
							"up ",
							br(snapshot.up),
							" Mb/s · plano ",
							br(snapshot.usedGb),
							"/",
							snapshot.capGb
						]
					})
				]
			})
		]
	});
}
function Neon({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "neon",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: snapshot.place }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "neon-sign mt-8 text-7xl leading-none tracking-tight",
				children: snapshot.tech
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-2xl",
				children: snapshot.quality
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 flex h-24 items-end gap-2",
				children: [
					1,
					2,
					3,
					4
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `flex-1 ${i <= snapshot.bars ? "c-fill neon-bar" : "c-track"}`,
					style: { height: `${30 + i * 16}%` }
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-4 text-sm tabular-nums",
				children: [
					snapshot.dbm,
					" dBm · ",
					snapshot.ping,
					" ms"
				]
			})
		]
	});
}
function Visor({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "visor",
		chrome,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Visor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hud mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner hud-tl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner hud-tr" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner hud-bl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner hud-br" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "scan" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 grid place-items-center text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "c-muted text-xs tracking-widest",
							children: "LOCK"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "glow c-accent mt-2 text-5xl leading-none tabular-nums",
							children: snapshot.dbm
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 text-sm",
							children: [
								snapshot.carrier,
								" ",
								snapshot.tech
							]
						})
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "c-muted absolute bottom-3 left-4 text-xs tabular-nums",
					children: [snapshot.ping, " ms"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "c-muted absolute right-4 bottom-3 text-xs tabular-nums",
					children: [br(snapshot.down), " ↓"]
				})
			]
		})]
	});
}
function Ondas({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "ondas",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Ondas" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 space-y-3",
				children: [
					{
						name: "Desce",
						amp: 16,
						phase: .4
					},
					{
						name: "Sobe",
						amp: 9,
						phase: 1.3
					},
					{
						name: "Ping",
						amp: 6,
						phase: 2.1
					}
				].map((band) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "c-muted text-xs tracking-widest uppercase",
					children: band.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 320 56",
					className: "h-14 w-full",
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: wavePath(band.amp, band.phase),
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.6",
						className: "c-accent"
					})
				})] }, band.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm tabular-nums",
				children: [
					br(snapshot.down),
					" · ",
					br(snapshot.up),
					" · ",
					snapshot.ping,
					" ms"
				]
			})
		]
	});
}
function Selos({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "selos",
		chrome,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Correio da rede" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "c-surface mt-6 px-4 py-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "perf" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "c-muted mt-4 text-xs tracking-widest uppercase",
					children: [
						snapshot.place,
						" · ",
						snapshot.carrier
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-3 text-4xl leading-none",
					children: [snapshot.quality, " passagem"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-lg",
					children: [
						snapshot.tech,
						", ",
						snapshot.dbm,
						" dBm, ",
						snapshot.ping,
						" ms."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "stamp text-sm",
						children: "Sinal bom"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "perf" })
			]
		})]
	});
}
function Ceu({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "ceu",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Céu · ", snapshot.place] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 240 140",
				className: "mt-4 h-44 w-full",
				"aria-hidden": true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M70 18 L168 22 L214 58 L150 102 L92 88 Z",
					fill: "none",
					stroke: "currentColor",
					className: "c-muted",
					strokeWidth: "0.6"
				}), [
					[
						28,
						36,
						1.5
					],
					[
						70,
						18,
						2
					],
					[
						118,
						48,
						1.6
					],
					[
						168,
						22,
						4.2
					],
					[
						214,
						58,
						1.8
					],
					[
						92,
						88,
						2.2
					],
					[
						150,
						102,
						1.4
					],
					[
						206,
						96,
						2.6
					],
					[
						48,
						110,
						1.2
					]
				].map(([x, y, r]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: x,
					cy: y,
					r,
					fill: "currentColor",
					className: r > 3 ? "c-accent" : "c-muted"
				}, `${x}-${y}`))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-accent text-sm",
				children: [
					"O ponto claro é agora · ",
					snapshot.dbm,
					" dBm"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-2 text-sm",
				children: [
					snapshot.carrier,
					" ",
					snapshot.tech,
					" · ",
					snapshot.ping,
					" ms"
				]
			})
		]
	});
}
function Fita({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "fita",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: ["Deck · ", snapshot.carrier] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "c-surface mt-6 space-y-4 rounded-xl px-4 py-4",
				children: [
					{
						name: "Desce",
						lit: 14
					},
					{
						name: "Sobe",
						lit: 8
					},
					{
						name: "Ping",
						lit: 6
					}
				].map((meter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "c-muted mb-2 text-xs tracking-widest uppercase",
					children: meter.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1",
					children: Array.from({ length: 16 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-5 flex-1 ${i < meter.lit ? i >= 12 ? "vu-hot" : "c-fill" : "c-track"}` }, i))
				})] }, meter.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-4 text-sm tabular-nums",
				children: [
					snapshot.dbm,
					" dBm · ",
					snapshot.tech
				]
			})
		]
	});
}
function Grade({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "grade",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Grade noturna" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 grid grid-cols-8 gap-1",
				children: Array.from({ length: 64 }, (_, i) => {
					const on = (i * 5 + 2) % 9 < snapshot.bars + 3;
					const hot = on && i % 7 === 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `aspect-square ${hot ? "vu-hot" : on ? "c-fill" : "c-track"}` }, i);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm",
				children: [
					snapshot.quality,
					" · ",
					snapshot.bars,
					" de 4 células fortes"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted text-sm tabular-nums",
				children: [
					snapshot.dbm,
					" dBm · ",
					br(snapshot.down),
					" Mb/s"
				]
			})
		]
	});
}
function Luneta({ chrome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		slug: "luneta",
		chrome,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Luneta" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lens mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-accent text-5xl leading-none tabular-nums",
						children: snapshot.dbm
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "c-muted mt-2 text-xs tracking-widest",
						children: "dBm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 text-sm",
						children: snapshot.quality
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "c-muted mt-6 text-center text-sm",
				children: [
					snapshot.carrier,
					" ",
					snapshot.tech,
					" · ",
					snapshot.place
				]
			})
		]
	});
}
var redoIcons = {
	40: RadioTower,
	41: Antenna,
	42: Signal,
	43: Rss,
	44: Gauge,
	45: Radar,
	46: TowerControl,
	47: Wifi
};
var wakeIcons = {
	48: Radio,
	49: HeartPulse,
	50: Stethoscope,
	51: ScanSearch,
	52: Microscope,
	53: SatelliteDish,
	54: Ruler,
	55: DraftingCompass,
	56: TestTubes
};
function icone(kicker, title, note, Icon) {
	return function Botao({ chrome }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			slug: "botao",
			chrome,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: kicker }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-3xl leading-none",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "botao-stage",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "speed-redo is-armed",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							size: 22,
							strokeWidth: 2.25
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "c-muted mt-4 max-w-xs text-sm",
					children: note
				})
			]
		});
	};
}
function botao(title, note, Icon) {
	return icone("Medir", title, note, Icon);
}
function acordar(title, note, Icon) {
	return icone("Sintonizar", title, note, Icon);
}
function chapa(slug, title, note) {
	return function Chapa({ chrome }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			slug: "chapa",
			chrome,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Botões" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-3xl leading-none",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "chapa-stage",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `speed-redo chapa-${slug}`,
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, {
							size: 22,
							strokeWidth: 2.25
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `speed-redo chapa-${slug}`,
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SatelliteDish, {
							size: 22,
							strokeWidth: 2.25
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "c-muted mt-4 max-w-xs text-sm",
					children: note
				})
			]
		});
	};
}
function fundo(slug, title, note) {
	return function Fundo({ chrome }) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			slug,
			chrome,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Fundo" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-3xl leading-none",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "c-muted mt-4 max-w-xs text-sm",
					children: note
				})
			]
		});
	};
}
function efeitoVisor(slug, title, note) {
	return function Efeito({ chrome }) {
		const flick = useRandomFlicker(slug === "cintilacao");
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			slug: "fosforo",
			chrome,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Efeito" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-3xl leading-none",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `speed-square efeito-${slug} ${flick ? "is-flick" : ""} mt-8`,
					style: flick ? { ["--flick"]: `${flick}ms` } : void 0,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "fosforo-figure",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegNum, { value: "42,6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "fosforo-unit",
							children: "Mb/s"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
							className: "fosforo-scan",
							"aria-hidden": true
						})
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "c-muted mt-4 max-w-xs text-sm",
					children: note
				})
			]
		});
	};
}
var views = {
	1: Campo,
	2: Sentenca,
	3: Cockpit,
	4: Franquia,
	5: Pulso,
	6: Barras,
	7: Diario,
	8: Relogio,
	9: Cartoes,
	10: Faixa,
	11: Orbita,
	12: Fosforo,
	13: Neon,
	14: Visor,
	15: Ondas,
	16: Selos,
	17: Ceu,
	18: Fita,
	19: Grade,
	20: Luneta,
	21: fundo("escovado", "Escovado", "Alumínio escovado, claro, como tampa de aparelho."),
	22: fundo("aco", "Aço", "Chapa de aço fosco, do tipo painel de instrumento."),
	23: fundo("anodizado", "Anodizado", "Alumínio anodizado preto, sem brilho de neon."),
	24: fundo("inox", "Inox", "Aço inoxidável escovado na diagonal."),
	25: fundo("jateado", "Jateado", "Alumínio jateado, fosco, sem direção de escova."),
	26: fundo("esmalte", "Esmalte", "Tinta eletrostática grafite, de chassi de equipamento."),
	27: fundo("fresagem", "Fresagem", "Alumínio escovado na vertical, com risco e reflexo de estúdio."),
	28: fundo("acovivo", "Aço vivo", "Aço laminado, grão fino e brilho de óleo."),
	29: fundo("negro", "Negro", "Alumínio anodizado preto, luz raspando a superfície."),
	30: fundo("espelho", "Espelho", "Inox escovado na diagonal, com reflexo do ambiente."),
	31: fundo("grao", "Grão", "Alumínio jateado, fosco, grão fechado."),
	32: fundo("chassi", "Chassi", "Tinta de equipamento, casca de laranja, emenda e parafusos."),
	33: fundo("liga", "Liga", "Inox do Espelho com a emenda e os parafusos do Chassi."),
	34: fundo("ferrugem", "Ferrugem", "Aço quase íntegro, com pequenas manchas de corrosão."),
	35: fundo("gasto", "Gasto", "Alumínio com risco, mancha fosca e oxidação na borda."),
	36: fundo("zinco", "Zinco", "Chapa galvanizada, corrosão pequena no canto."),
	37: fundo("parafusos", "Parafusos", "Placa grafite com quatro parafusos allen."),
	38: fundo("pregos", "Pregos", "Chapa clara com rebites e duas cabeças de prego."),
	39: fundo("fixacao", "Fixação", "Parafusos e um prego, com ferrugem só em volta deles."),
	40: botao("Torre", "Mastro com ondas no topo.", RadioTower),
	41: botao("Antena", "Haste única, como antena de rádio.", Antenna),
	42: botao("Sinal", "Barras crescendo. O sinal em pé.", Signal),
	43: botao("Onda", "Três arcos saindo de um ponto.", Rss),
	44: botao("Medidor", "Ponteiro de instrumento. É o ícone atual.", Gauge),
	45: botao("Radar", "Círculo com um braço varrendo.", Radar),
	46: botao("Poste", "Torre de controle, mais larga que o mastro.", TowerControl),
	47: botao("Wi-fi", "O arco familiar do Wi-fi.", Wifi),
	48: acordar("Rádio", "O rádio de antes.", Radio),
	49: acordar("Pulso", "Linha de pulso. Diagnóstico.", HeartPulse),
	50: acordar("Esteto", "Estetoscópio. Ausculta a rede.", Stethoscope),
	51: acordar("Varredura", "Uma busca varrendo o sinal.", ScanSearch),
	52: acordar("Lente", "Microscópio. Exame de perto.", Microscope),
	53: acordar("Prato", "Antena parabólica. É o ícone atual.", SatelliteDish),
	54: acordar("Régua", "Medida direta, em escala.", Ruler),
	55: acordar("Compasso", "Abre o arco e mede.", DraftingCompass),
	56: acordar("Tubos", "Análise de laboratório.", TestTubes),
	57: efeitoVisor("brilho", "Brilho", "O número ganha um halo de fósforo."),
	58: efeitoVisor("cintilacao", "Cintilação", "O visor pisca leve, como um tubo cansado."),
	59: efeitoVisor("fantasma", "Fantasma", "Uma cópia fraca do texto, um pouco ao lado."),
	60: efeitoVisor("grao", "Grão", "Granulação fina sobre o vidro."),
	61: efeitoVisor("vinheta", "Vinheta", "Os cantos do visor escurecem."),
	62: efeitoVisor("reflexo", "Reflexo", "Um brilho de vidro atravessa o visor."),
	63: efeitoVisor("moldura", "Moldura", "A borda interna acende e apaga."),
	64: efeitoVisor("linhas", "Linhas", "As linhas do tubo ficam mais fortes e descem."),
	65: efeitoVisor("nucleo", "Núcleo", "Um clarão parado atrás do número."),
	66: efeitoVisor("poeira", "Poeira", "Pontos pequenos parados no vidro."),
	67: efeitoVisor("vidro", "Vidro", "Reflexo fixo de vidro curvo no topo."),
	68: efeitoVisor("quente", "Quente", "O centro mais claro e a borda mais escura."),
	69: efeitoVisor("batida", "Batida", "O visor inteiro respira em brilho."),
	70: efeitoVisor("eco", "Eco", "O texto se repete, cada vez mais fraco."),
	71: efeitoVisor("neblina", "Neblina", "Uma névoa leve por cima do vidro."),
	72: chapa("polido", "Polido", "Alumínio novo. Sem marca de uso."),
	73: chapa("escova", "Escova", "Aço escovado na horizontal, ainda limpo."),
	74: chapa("jato", "Jato", "Fosco jateado. Quase nenhum brilho."),
	75: chapa("chumbo", "Chumbo", "Grafite escuro, liso, pouco manuseado."),
	76: chapa("frio", "Frio", "Inox com reflexo frio na diagonal."),
	77: chapa("niquel", "Níquel", "Metal morno, com um véu leve de dedo."),
	78: chapa("bronze", "Bronze", "Bronze escuro. Pátina só num canto."),
	79: chapa("oleo", "Óleo", "Aço com véu de óleo e uma marca de dedo."),
	80: chapa("dedos", "Dedos", "As bordas escureceram de tanto toque."),
	81: chapa("uso", "Uso", "Centro mais claro. Os cantos já gastaram."),
	82: chapa("oxido", "Óxido", "Zinco com pontos brancos de oxidação."),
	83: chapa("patina", "Pátina", "Bronze com verde só na borda."),
	84: chapa("pinta", "Pinta", "Aço com pintas pequenas de ferrugem."),
	85: chapa("tempera", "Têmpera", "Aço queimado. Azul e marrom de calor."),
	86: chapa("sucata", "Sucata", "O mais usado: escuro, manchado, ferrugem na quina.")
};
function Concept({ id, chrome = true, actions = false }) {
	const View = views[id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, {
		chrome,
		actions
	});
}
var KEY = "sinal-plano";
var listeners = /* @__PURE__ */ new Set();
function emit() {
	listeners.forEach((listener) => listener());
}
function valid(value) {
	return value.capGb > 0 && value.usedGb >= 0 && value.renewDay >= 1 && value.renewDay <= 31;
}
function hydratePlan() {
	try {
		if (valid(JSON.parse(localStorage.getItem(KEY) ?? "")));
	} catch {}
	emit();
}
function inUse(item, state) {
	if ("kind" in item && item.kind === "fundo") return state.fundo === item.id;
	if ("kind" in item && item.kind === "botao") return state.botao === item.id;
	if ("kind" in item && item.kind === "acordar") return state.acordar === item.id;
	if ("kind" in item && item.kind === "efeito") return state.efeito === item.id;
	if ("kind" in item && item.kind === "chapa") return state.chapa === item.id;
	return state.chosen === item.id;
}
function DevLab() {
	const chosen = useChosen();
	const fundo = useBackground();
	const botao = useButton();
	const acordar = useWakeIcon();
	const efeito = useVisorEffect();
	const chapa = useChapa();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [preview, setPreview] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		hydrateChoice();
		hydratePlan();
	}, []);
	function onLaunch() {
		if (open || preview) {
			setOpen(false);
			setPreview(null);
			return;
		}
		setOpen(true);
	}
	const current = concepts.find((item) => item.id === preview);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "dev-launch",
			"aria-label": open || preview ? "Fechar testes" : "Abrir testes",
			"aria-pressed": open || preview != null,
			onClick: onLaunch,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlaskConical, {
				size: 18,
				strokeWidth: 1.75
			})
		}),
		open && preview == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lab-layer",
			role: "dialog",
			"aria-label": "Testes do desenvolvedor",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "lab-kicker",
					children: "Desenvolvedor"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "lab-title",
					children: "Testes"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "lab-note",
					children: "Só você vê esta tela. A interface vem primeiro. Depois, fundos. No fim, ícones, o metal dos botões e os efeitos dos visores."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "lab-list",
					children: concepts.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "lab-row",
						onClick: () => setPreview(item.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "thumb",
							"aria-hidden": true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "thumb-inner",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Concept, {
									id: item.id,
									chrome: false
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "lab-num",
								children: String(item.id).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "lab-name",
								children: item.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "lab-line",
								children: item.line
							}),
							inUse(item, {
								chosen,
								fundo,
								botao,
								acordar,
								efeito,
								chapa
							}) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "lab-flag",
								children: "Em uso"
							}) : null
						] })]
					}) }, item.id))
				})
			]
		}) : null,
		preview != null && current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "lab-layer p-0",
			role: "dialog",
			"aria-label": current.name,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Concept, { id: preview }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lab-dock",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPreview(null),
					children: "Voltar à lista"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "primary",
					onClick: () => chooseConcept(preview),
					children: inUse(current, {
						chosen,
						fundo,
						botao,
						acordar,
						efeito,
						chapa
					}) ? "Em uso" : "Usar esta"
				})]
			})]
		}) : null
	] });
}
var styles_default = "/assets/styles-DJ-TcM1z.css";
var Route$2 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Coil Jitter" },
			{
				name: "apple-mobile-web-app-title",
				content: "Coil Jitter"
			},
			{
				name: "theme-color",
				content: "#000000"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "desk",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "desk-note",
					children: "Android · 412 × 892"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "device",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DevLab, {})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter = () => import("./routes-CKphYgl_.mjs");
var Route$1 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var MAX_BYTES = 12e6;
function randomStream(bytes) {
	let sent = 0;
	return new ReadableStream({ pull(controller) {
		const size = Math.min(65536, bytes - sent);
		const chunk = new Uint8Array(size);
		crypto.getRandomValues(chunk);
		sent += size;
		controller.enqueue(chunk);
		if (sent >= bytes) controller.close();
	} });
}
function noStore(extra) {
	return {
		"cache-control": "no-store, no-transform",
		...Object.fromEntries(new Headers(extra).entries())
	};
}
var Route = createFileRoute("/api/speed")({ server: { handlers: {
	GET: async ({ request }) => {
		const url = new URL(request.url);
		const bytes = Math.min(MAX_BYTES, Math.max(0, Math.floor(Number(url.searchParams.get("bytes")) || 0)));
		return new Response(bytes === 0 ? null : randomStream(bytes), { headers: noStore({
			"content-type": "application/octet-stream",
			"content-length": String(bytes)
		}) });
	},
	POST: async ({ request }) => {
		const body = await request.arrayBuffer();
		return Response.json({ bytes: body.byteLength }, { headers: noStore({ "content-type": "application/json" }) });
	}
} } });
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$2
	}),
	ApiSpeedRoute: Route.update({
		id: "/api/speed",
		path: "/api/speed",
		getParentRoute: () => Route$2
	})
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Concept as n, useChosen as r, router_exports as t };
