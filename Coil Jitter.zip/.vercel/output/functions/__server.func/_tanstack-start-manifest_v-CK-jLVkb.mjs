//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CK-jLVkb.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/outage",
			"/api/pages",
			"/api/place",
			"/api/reach",
			"/api/speed",
			"/api/who"
		],
		preloads: ["/assets/index-0jTXwzOH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-0jTXwzOH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-EFoNUmIN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
