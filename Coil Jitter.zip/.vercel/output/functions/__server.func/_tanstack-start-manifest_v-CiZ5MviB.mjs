//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CiZ5MviB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/speed"],
		preloads: ["/assets/index-1jennlWP.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-1jennlWP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CZDk4HFp.js"]
	}
} });
//#endregion
export { tsrStartManifest };
