import { createFileRoute } from "@tanstack/react-router";

const UF: Record<string, string> = {
  Acre: "AC",
  Alagoas: "AL",
  Amapá: "AP",
  Amazonas: "AM",
  Bahia: "BA",
  Ceará: "CE",
  "Distrito Federal": "DF",
  "Espírito Santo": "ES",
  Goiás: "GO",
  Maranhão: "MA",
  "Mato Grosso": "MT",
  "Mato Grosso do Sul": "MS",
  "Minas Gerais": "MG",
  Pará: "PA",
  Paraíba: "PB",
  Paraná: "PR",
  Pernambuco: "PE",
  Piauí: "PI",
  "Rio de Janeiro": "RJ",
  "Rio Grande do Norte": "RN",
  "Rio Grande do Sul": "RS",
  Rondônia: "RO",
  Roraima: "RR",
  "Santa Catarina": "SC",
  "São Paulo": "SP",
  Sergipe: "SE",
  Tocantins: "TO",
};

export const Route = createFileRoute("/api/place")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const lat = Number(url.searchParams.get("lat"));
        const lon = Number(url.searchParams.get("lon"));
        if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
          return Response.json({ city: "", state: "", uf: "" }, { status: 400 });
        }
        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&accept-language=pt-BR`,
            {
              signal: AbortSignal.timeout(4000),
              headers: {
                accept: "application/json",
                "user-agent": "CoilJitter/1.0 (localidade do aparelho)",
              },
            },
          );
          if (!response.ok) return Response.json({ city: "", state: "", uf: "" }, { status: 502 });
          const data = (await response.json()) as {
            address?: { city?: string; town?: string; municipality?: string; village?: string; state?: string; "ISO3166-2-lvl4"?: string };
          };
          const address = data.address ?? {};
          const city = address.city || address.town || address.municipality || address.village || "";
          const state = address.state || "";
          const uf = (address["ISO3166-2-lvl4"] || "").replace("BR-", "") || UF[state] || "";
          return Response.json({ city, state, uf }, { headers: { "cache-control": "no-store" } });
        } catch {
          return Response.json({ city: "", state: "", uf: "" }, { status: 502 });
        }
      },
    },
  },
});
