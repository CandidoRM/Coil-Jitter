import { createFileRoute } from "@tanstack/react-router";
import { env } from "@/lib/env.server";

const ASN: Record<string, number[]> = {
  TIM: [26615],
  VIVO: [27699, 26599],
  CLARO: [28573, 4230],
  OI: [7738],
  ALGAR: [16735],
};

type Spot = { code?: string; name?: string };
type Net = { asn?: number; name?: string };
type Outage = {
  startDate?: string;
  endDate?: string | null;
  locations?: string[];
  locationsDetails?: Spot[];
  asns?: number[];
  asnsDetails?: Net[];
};

function plain(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function open(item: Outage) {
  if (!item.endDate) return true;
  const end = Date.parse(item.endDate);
  return Number.isFinite(end) && end > Date.now();
}

function regionHit(item: Outage, city: string, state: string, uf: string) {
  const spots = item.locationsDetails ?? [];
  const names = spots.map((spot) => plain(spot.name || ""));
  const codes = spots.map((spot) => (spot.code || "").toUpperCase());
  const ufCode = uf.toUpperCase();
  if (ufCode && codes.some((code) => code === ufCode || code.endsWith(`-${ufCode}`))) return true;
  const wanted = [city, state].map((part) => plain(part)).filter((part) => part.length > 2);
  if (wanted.some((part) => names.some((name) => name.includes(part)))) return true;
  const places = (item.locations ?? []).map((code) => code.toUpperCase());
  const countryOnly = places.includes("BR") && places.every((code) => code === "BR") && spots.every((spot) => (spot.code || "").toUpperCase() === "BR");
  return countryOnly && !(item.asns?.length);
}

function carrierHit(item: Outage, carrier: string) {
  const known = ASN[carrier] ?? [];
  if (known.some((asn) => item.asns?.includes(asn))) return true;
  const name = plain(carrier);
  return (item.asnsDetails ?? []).some((net) => plain(net.name || "").includes(name));
}

export const Route = createFileRoute("/api/outage")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const quiet = Response.json({ lines: [] as string[] }, { headers: { "cache-control": "no-store" } });
        const token = env("CLOUDFLARE_API_TOKEN");
        if (!token) return quiet;
        const url = new URL(request.url);
        const city = url.searchParams.get("city") || "";
        const state = url.searchParams.get("state") || "";
        const uf = (url.searchParams.get("uf") || "").toUpperCase();
        const carrier = (url.searchParams.get("carrier") || "").toUpperCase();
        try {
          const response = await fetch(
            "https://api.cloudflare.com/client/v4/radar/annotations/outages?dateRange=14d&location=BR&limit=40&format=json",
            { headers: { authorization: `Bearer ${token}`, accept: "application/json" }, signal: AbortSignal.timeout(3500) },
          );
          if (!response.ok) return quiet;
          const data = (await response.json()) as { result?: { annotations?: Outage[] }; annotations?: Outage[] };
          const items = (data.result?.annotations ?? data.annotations ?? []).filter(open);
          const lines: string[] = [];
          if (items.some((item) => regionHit(item, city, state, uf))) lines.push("Queda aberta na região");
          if (carrier && items.some((item) => carrierHit(item, carrier))) lines.push("Queda aberta na operadora");
          return Response.json({ lines }, { headers: { "cache-control": "no-store" } });
        } catch {
          return quiet;
        }
      },
    },
  },
});
