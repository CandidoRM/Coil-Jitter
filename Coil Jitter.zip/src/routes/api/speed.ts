import { createFileRoute } from "@tanstack/react-router";

const MAX_BYTES = 12_000_000;

function randomStream(bytes: number) {
  let sent = 0;
  return new ReadableStream<Uint8Array>({
    pull(controller) {
      const size = Math.min(65536, bytes - sent);
      const chunk = new Uint8Array(size);
      crypto.getRandomValues(chunk);
      sent += size;
      controller.enqueue(chunk);
      if (sent >= bytes) controller.close();
    },
  });
}

function noStore(extra?: HeadersInit) {
  return {
    "cache-control": "no-store, no-transform",
    ...Object.fromEntries(new Headers(extra).entries()),
  };
}

export const Route = createFileRoute("/api/speed")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const bytes = Math.min(MAX_BYTES, Math.max(0, Math.floor(Number(url.searchParams.get("bytes")) || 0)));
        return new Response(bytes === 0 ? null : randomStream(bytes), {
          headers: noStore({
            "content-type": "application/octet-stream",
            "content-length": String(bytes),
          }),
        });
      },
      POST: async ({ request }) => {
        const body = await request.arrayBuffer();
        return Response.json(
          { bytes: body.byteLength },
          { headers: noStore({ "content-type": "application/json" }) },
        );
      },
    },
  },
});
