import { createFileRoute } from "@tanstack/react-router";

function publicIp(ip: string) {
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(ip)) {
    const parts = ip.split(".").map((part) => Number(part));
    if (parts.some((part) => part > 255)) return false;
    const [a, b] = parts;
    if (a === 10 || a === 127 || a === 0) return false;
    if (a === 169 && b === 254) return false;
    if (a === 172 && b >= 16 && b <= 31) return false;
    if (a === 192 && b === 168) return false;
    return true;
  }
  return /^[0-9a-f:]+$/i.test(ip) && ip.includes(":") && ip !== "::1" && !ip.toLowerCase().startsWith("fe80");
}

function pretty(holder: string) {
  const cut = holder.split(" - ").map((part) => part.trim()).filter(Boolean);
  const named = cut.find((part) => /[a-z]/.test(part)) || cut[cut.length - 1] || holder;
  return named.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim();
}

export const Route = createFileRoute("/api/who")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const quiet = Response.json({ name: "" }, { headers: { "cache-control": "no-store" } });
        const ip = new URL(request.url).searchParams.get("ip")?.trim() || "";
        if (!publicIp(ip)) return quiet;
        try {
          const info = await fetch(`https://stat.ripe.net/data/network-info/data.json?resource=${encodeURIComponent(ip)}`, {
            signal: AbortSignal.timeout(3500),
            headers: { accept: "application/json" },
          });
          if (!info.ok) return quiet;
          const body = (await info.json()) as { data?: { asns?: string[] } };
          const asn = body.data?.asns?.[0];
          if (!asn) return quiet;
          const over = await fetch(`https://stat.ripe.net/data/as-overview/data.json?resource=AS${encodeURIComponent(asn)}`, {
            signal: AbortSignal.timeout(3500),
            headers: { accept: "application/json" },
          });
          if (!over.ok) return quiet;
          const data = (await over.json()) as { data?: { holder?: string } };
          const name = pretty(data.data?.holder || "");
          return Response.json({ name }, { headers: { "cache-control": "no-store" } });
        } catch {
          return quiet;
        }
      },
    },
  },
});
