import { createFileRoute } from "@tanstack/react-router";

type Level = "normal" | "degradada" | "degradado" | "parcial" | "fora" | "com falha" | "sem retorno";

async function pull(url: string): Promise<unknown | null> {
  try {
    const response = await fetch(url, {
      signal: AbortSignal.timeout(3500),
      headers: { accept: "application/json" },
    });
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  }
}

function cloudflare(data: unknown): Level {
  if (!data || typeof data !== "object") return "sem retorno";
  const indicator = (data as { status?: { indicator?: string } }).status?.indicator;
  if (indicator === "none") return "normal";
  if (indicator === "minor") return "degradada";
  if (indicator === "major") return "parcial";
  if (indicator === "critical") return "fora";
  return "sem retorno";
}

function google(data: unknown, gender: "a" | "o" = "o"): Level {
  if (!Array.isArray(data)) return "sem retorno";
  const open = data.filter((item) => item && typeof item === "object" && !(item as { end?: string }).end);
  if (open.some((item) => (item as { severity?: string }).severity === "high")) return "fora";
  if (open.some((item) => (item as { severity?: string }).severity === "medium")) return gender === "a" ? "degradada" : "degradado";
  return "normal";
}

function meta(lists: unknown[]): Level {
  const arrays = lists.filter((list) => Array.isArray(list));
  if (arrays.length === 0) return "sem retorno";
  if (arrays.some((list) => list.length > 0)) return "com falha";
  return "normal";
}

export const Route = createFileRoute("/api/pages")({
  server: {
    handlers: {
      GET: async () => {
        const [cf, g, workspace, search, wa, msg, login] = await Promise.all([
          pull("https://www.cloudflarestatus.com/api/v2/summary.json"),
          pull("https://status.cloud.google.com/incidents.json"),
          pull("https://www.google.com/appsstatus/dashboard/incidents.json"),
          pull("https://status.search.google.com/incidents.json"),
          pull("https://metastatus.com/data/outages/whatsapp-business-api.json"),
          pull("https://metastatus.com/data/outages/messenger.json"),
          pull("https://metastatus.com/data/outages/facebook-login.json"),
        ]);
        const rows: [string, Level][] = [
          ["Cloudflare", cloudflare(cf)],
          ["Google Cloud", google(g)],
          ["Google Workspace", google(workspace)],
          ["Google Search", google(search, "a")],
          ["Meta Business", meta([wa, msg, login])],
        ];
        const lines = rows.map(([name, level]) => `${name} ${level}`);
        return Response.json({ lines }, { headers: { "cache-control": "no-store" } });
      },
    },
  },
});
