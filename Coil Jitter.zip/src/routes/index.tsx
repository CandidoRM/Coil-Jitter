import { createFileRoute } from "@tanstack/react-router";
import { Concept } from "@/components/coil";
import { useChosen } from "@/lib/choice";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const chosen = useChosen();
  return (
    <main>
      <Concept id={chosen} chrome={false} actions />
    </main>
  );
}
