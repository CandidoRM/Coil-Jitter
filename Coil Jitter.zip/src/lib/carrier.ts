const KEY = "coil-carrier";

type Box = { status: "denied" } | { status: "saved"; name: string };

function memory() {
  try {
    return typeof localStorage === "undefined" ? null : localStorage;
  } catch {
    return null;
  }
}

function readBox(): Box | null {
  const raw = memory()?.getItem(KEY);
  if (!raw) return null;
  try {
    const data = JSON.parse(raw) as Box;
    if (data?.status === "denied") return data;
    if (data?.status === "saved" && data.name) return data;
  } catch {
    /* segue */
  }
  return null;
}

export function matchCarrier(raw: string) {
  const text = raw
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase();
  if (text.includes("TIM") || text.includes("CORREIOS")) return "TIM";
  if (text.includes("CLARO")) return "CLARO";
  if (text.includes("VIVO") || text.includes("TELEFONICA")) return "VIVO";
  if (/(^|[^A-Z])OI([^A-Z]|$)/.test(text)) return "OI";
  if (text.includes("ALGAR")) return "ALGAR";
  if (text.includes("SERCOMTEL")) return "SERCOMTEL";
  if (text.includes("BRISANET")) return "BRISANET";
  return "";
}

export function readCarrier() {
  const box = readBox();
  const name = box?.status === "saved" ? box.name : "";
  if (typeof window !== "undefined" && name) (window as Window & { CoilCarrier?: { name: string } }).CoilCarrier = { name };
  return name;
}

export function saveCarrier(raw: string) {
  const name = matchCarrier(raw);
  if (!name) return "";
  memory()?.setItem(KEY, JSON.stringify({ status: "saved", name }));
  readCarrier();
  return name;
}

export function denyCarrier() {
  memory()?.setItem(KEY, JSON.stringify({ status: "denied" }));
}

export function ensureCarrier() {
  if (typeof window === "undefined") return;
  const host = window as Window & {
    CoilSaveCarrier?: (raw: string) => string;
    CoilDenyCarrier?: () => void;
    CoilNative?: { carrier?: string; requestCarrier?: () => void };
  };
  host.CoilSaveCarrier = saveCarrier;
  host.CoilDenyCarrier = denyCarrier;
  if (readCarrier() || readBox()?.status === "denied") return;
  if (host.CoilNative?.carrier) {
    saveCarrier(host.CoilNative.carrier);
    return;
  }
  host.CoilNative?.requestCarrier?.();
}
