const TRIED = "coil-fault-tried";
const DEAD = "coil-fault-dead";
const EPOCH = "coil-fault-epoch";
const epoch = "3";

const NOISE = /medida falhou|pacote falhou|AbortError|Failed to fetch|Load failed|NetworkError|The user aborted|ResizeObserver|^off$/i;

function memory() {
  try {
    return typeof sessionStorage === "undefined" ? null : sessionStorage;
  } catch {
    return null;
  }
}

function forgetOldFault() {
  const box = memory();
  if (!box || box.getItem(EPOCH) === epoch) return;
  box.removeItem(DEAD);
  box.removeItem(TRIED);
  box.setItem(EPOCH, epoch);
}

forgetOldFault();

export function faultDead() {
  return memory()?.getItem(DEAD) === "1";
}

function lock() {
  try {
    memory()?.setItem(DEAD, "1");
  } catch {
    /* o próprio armazenamento falhou */
  }
  if (typeof window !== "undefined") window.dispatchEvent(new Event("coil-dead"));
}

let busy = false;

export function noteFault(reason?: unknown) {
  const text = reason instanceof Error ? `${reason.name} ${reason.message}` : String(reason ?? "");
  if (!text || NOISE.test(text)) return "ignore" as const;
  const box = memory();
  if (!box) {
    lock();
    return "dead" as const;
  }
  if (box.getItem(DEAD) === "1") return "dead" as const;
  if (busy) return box.getItem(TRIED) === "1" ? "dead" as const : "restart" as const;
  busy = true;
  if (box.getItem(TRIED) === "1") {
    lock();
    return "dead" as const;
  }
  try {
    box.setItem(TRIED, "1");
    const timer = window.setTimeout(() => lock(), 4000);
    window.addEventListener("pagehide", () => window.clearTimeout(timer), { once: true });
    location.reload();
  } catch {
    lock();
    return "dead" as const;
  }
  return "restart" as const;
}

export function forgiveRestart() {
  if (faultDead()) return;
  try {
    memory()?.removeItem(TRIED);
  } catch {
    /* segue */
  }
}

let armed = false;

export function armFaultWatch() {
  if (armed || typeof window === "undefined") return;
  armed = true;
  window.addEventListener(
    "error",
    (event) => {
      const target = event.target;
      if (target && target !== window) {
        if (target instanceof HTMLScriptElement) noteFault(new Error("arquivo do Coil falhou"));
        if (target instanceof HTMLLinkElement && target.rel === "stylesheet") noteFault(new Error("arquivo do Coil falhou"));
        return;
      }
      noteFault(event.error ?? event.message);
    },
    true,
  );
  window.addEventListener("unhandledrejection", (event) => {
    noteFault(event.reason);
  });
}

armFaultWatch();
