export type SpeedReading = { down: number; up: number; ping: number };
export type SpeedPhase = "ping" | "descida" | "subida";

const CLOUD = "https://speed.cloudflare.com";
const WINDOW_MS = 4_000;
const DOWN_CAP = 12_000_000;
const PARALLEL = 6;
const UP_BYTES = 500_000;
const UP_PARALLEL = 2;

function mbps(bytes: number, ms: number) {
  if (ms < 1 || bytes < 1) return 0;
  return (bytes * 8) / ms / 1000;
}

function median(values: number[]) {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}

function randomBody(bytes: number) {
  const buffer = new ArrayBuffer(bytes);
  const payload = new Uint8Array(buffer);
  for (let offset = 0; offset < bytes; offset += 65536) {
    crypto.getRandomValues(payload.subarray(offset, Math.min(bytes, offset + 65536)));
  }
  return buffer;
}

function cloudPaths(stamp: number) {
  return {
    ping: (i: number) => `${CLOUD}/__down?bytes=0&r=${stamp}-p${i}`,
    warm: (i: number) => `${CLOUD}/__down?bytes=400000&r=${stamp}-w${i}`,
    down: (i: number) => `${CLOUD}/__down?bytes=25000000&r=${stamp}-d${i}`,
    up: `${CLOUD}/__up?r=${stamp}-u`,
  };
}

function ownPaths(stamp: number) {
  return {
    ping: (i: number) => `/api/speed?bytes=0&r=${stamp}-p${i}`,
    warm: (i: number) => `/api/speed?bytes=400000&r=${stamp}-w${i}`,
    down: (i: number) => `/api/speed?bytes=12000000&r=${stamp}-d${i}`,
    up: `/api/speed?r=${stamp}-u`,
  };
}

async function cloudReachable() {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 2500);
  try {
    const response = await fetch(`${CLOUD}/__down?bytes=0&r=${Date.now()}`, {
      cache: "no-store",
      signal: ctrl.signal,
    });
    return response.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

async function pull(url: string, signal: AbortSignal, add: (bytes: number) => void) {
  const response = await fetch(url, { cache: "no-store", signal });
  if (!response.ok || !response.body) throw new Error("medida falhou");
  const reader = response.body.getReader();
  try {
    while (!signal.aborted) {
      const { done, value } = await reader.read();
      if (done || !value) break;
      add(value.byteLength);
    }
  } catch (error) {
    if (signal.aborted) return;
    throw error;
  } finally {
    reader.cancel().catch(() => {});
  }
}

async function measurePing(url: (i: number) => string) {
  const samples = [];
  for (let i = 0; i < 5; i++) {
    const start = performance.now();
    const response = await fetch(url(i), { cache: "no-store" });
    if (!response.ok) throw new Error("medida falhou");
    await response.arrayBuffer();
    if (i > 0) samples.push(performance.now() - start);
  }
  let drift = 0;
  for (let i = 1; i < samples.length; i++) drift += Math.abs(samples[i] - samples[i - 1]);
  return {
    ping: median(samples),
    jitter: samples.length > 1 ? drift / (samples.length - 1) : 0,
  };
}

function loadedMbps(ticks: { t: number; bytes: number }[]) {
  if (ticks.length < 2) return 0;
  const first = ticks[0];
  const last = ticks[ticks.length - 1];
  const span = last.t - first.t;
  if (span < 1) return 0;
  const cut = first.t + span * 0.25;
  const mark = ticks.find((tick) => tick.t >= cut);
  const from = mark && last.t - mark.t >= 600 && last.bytes - mark.bytes >= 60_000 ? mark : first;
  return mbps(last.bytes - from.bytes, last.t - from.t);
}

async function warmDownload(url: (i: number) => string) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 4000);
  try {
    await Promise.all(Array.from({ length: PARALLEL }, (_, i) => pull(url(i), ctrl.signal, () => {})));
  } catch {
    /* abre a conexão; o volume não entra na conta */
  } finally {
    clearTimeout(timer);
    ctrl.abort();
  }
}

async function oneLoadedPing(url: string) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 4000);
  const start = performance.now();
  try {
    const response = await fetch(url, { cache: "no-store", signal: ctrl.signal });
    if (!response.ok) return null;
    await response.arrayBuffer();
    return Math.round(performance.now() - start);
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function measureDownload(url: (i: number) => string, probe?: (i: number) => string) {
  const ctrl = new AbortController();
  const ticks: { t: number; bytes: number }[] = [];
  let bytes = 0;
  let seq = 0;
  let windowTimer: ReturnType<typeof setTimeout> | undefined;
  let loadedTask: Promise<number | null> | null = null;
  const failsafe = setTimeout(() => ctrl.abort(), WINDOW_MS + 8_000);
  const add = (n: number) => {
    windowTimer ??= setTimeout(() => ctrl.abort(), WINDOW_MS);
    bytes += n;
    ticks.push({ t: performance.now(), bytes });
    if (probe && !loadedTask) {
      loadedTask = new Promise((resolve) => {
        setTimeout(() => resolve(oneLoadedPing(probe(90))), 800);
      });
    }
    if (bytes >= DOWN_CAP) ctrl.abort();
  };
  async function worker() {
    while (!ctrl.signal.aborted && bytes < DOWN_CAP) {
      try {
        await pull(url(seq++), ctrl.signal, add);
      } catch (error) {
        if (ctrl.signal.aborted) return;
        throw error;
      }
    }
  }
  try {
    await Promise.all(Array.from({ length: PARALLEL }, () => worker()));
  } finally {
    clearTimeout(failsafe);
    if (windowTimer) clearTimeout(windowTimer);
    ctrl.abort();
  }
  if (bytes < 50_000 || ticks.length < 2) throw new Error("medida falhou");
  return { mbps: loadedMbps(ticks), loaded: loadedTask ? await loadedTask : null };
}

function sendUpload(url: string, body: ArrayBuffer) {
  return new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const timer = setTimeout(() => {
      xhr.abort();
      reject(new Error("medida falhou"));
    }, 12_000);
    xhr.open("POST", url);
    xhr.setRequestHeader("content-type", "application/octet-stream");
    xhr.upload.onload = () => {
      clearTimeout(timer);
      resolve();
    };
    xhr.upload.onerror = () => {
      clearTimeout(timer);
      reject(new Error("medida falhou"));
    };
    xhr.onerror = () => {
      clearTimeout(timer);
      reject(new Error("medida falhou"));
    };
    xhr.send(body);
  });
}

async function measureUpload(url: string, warm: boolean) {
  if (warm) {
    try {
      await sendUpload(url, randomBody(64_000));
    } catch {
      /* aquecimento */
    }
  }
  const bodies = Array.from({ length: UP_PARALLEL }, () => randomBody(UP_BYTES));
  const started = performance.now();
  await Promise.all(bodies.map((body) => sendUpload(url, body)));
  return mbps(UP_BYTES * bodies.length, performance.now() - started);
}

async function timedFetch(url: string) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  const start = performance.now();
  try {
    const response = await fetch(url, { cache: "no-store", signal: ctrl.signal });
    if (!response.ok) throw new Error("pacote falhou");
    await response.arrayBuffer();
    return performance.now() - start;
  } finally {
    clearTimeout(timer);
  }
}

const IDLE_MS = 10_000;
let lastTraffic = 0;

function touchTraffic() {
  lastTraffic = performance.now();
}

export function linkIdle() {
  return lastTraffic === 0 || performance.now() - lastTraffic > IDLE_MS;
}

export function generationLine(mbps: number): string {
  const connection = (navigator as Navigator & { connection?: { effectiveType?: string } }).connection;
  const reported = connection?.effectiveType;
  const phone = reported === "slow-2g" || reported === "2g" ? 2 : reported === "3g" ? 3 : reported === "4g" ? 4 : null;
  const speed = mbps < 0.3 ? 2 : mbps < 5 ? 3 : mbps < 50 ? 4 : 5;
  const name = (n: number) => `${n}G`;
  if (phone == null) return `O celular não informa a geração · a descida parece ${name(speed)}`;
  if (Math.abs(phone - speed) >= 2) {
    const mid = (phone + speed) / 2;
    if (Number.isInteger(mid)) return `Destoa do celular · média ${name(mid)}`;
    return `Destoa do celular · entre ${name(Math.floor(mid))} e ${name(Math.ceil(mid))}`;
  }
  if (phone === 4 && speed >= 4) return "Perto do celular · 4G ou mais";
  return `Confere com o celular · ${name(phone)}`;
}

export function linkFacts() {
  if (typeof navigator === "undefined" || navigator.onLine === false) return [];
  const lines: string[] = [];
  const connection = (navigator as Navigator & {
    connection?: {
      type?: string;
      effectiveType?: string;
      rtt?: number;
      downlink?: number;
      saveData?: boolean;
    };
  }).connection;
  if (!connection) {
    lines.push("O aparelho não informa o tipo.");
    return lines;
  }
  if (connection.type === "wifi") lines.push("Caminho: Wi-fi.");
  else if (connection.type === "cellular") lines.push("Caminho: plano.");
  else if (connection.type === "ethernet") lines.push("Caminho: cabo.");
  else if (connection.type === "bluetooth") lines.push("Caminho: Bluetooth.");
  else if (connection.type === "none") lines.push("Sem interface de rede.");
  else if (connection.type) lines.push("Caminho não identificado.");
  if (connection.saveData) lines.push("Economia de dados ligada.");
  if (typeof connection.rtt === "number" && connection.rtt >= 1000) lines.push(`O aparelho estima resposta muito alta · ${Math.round(connection.rtt)} ms`);
  else if (typeof connection.rtt === "number" && connection.rtt >= 300) lines.push(`O aparelho estima resposta alta · ${Math.round(connection.rtt)} ms`);
  if (typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < 0.5) lines.push("O aparelho estima a descida muito baixa.");
  else if (typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < 1.5) lines.push("O aparelho estima a descida baixa.");
  return lines;
}

function looksSlow() {
  const connection = (navigator as Navigator & {
    connection?: { effectiveType?: string; rtt?: number; downlink?: number };
  }).connection;
  if (!connection) return false;
  if (connection.effectiveType === "slow-2g" || connection.effectiveType === "2g" || connection.effectiveType === "3g") {
    return true;
  }
  if (typeof connection.rtt === "number" && connection.rtt >= 300) return true;
  return typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < 1.5;
}

export function linkSlow() {
  return looksSlow();
}

let activeUntil = 0;

export function noteAction() {
  activeUntil = performance.now() + IDLE_MS;
}

export function linkMark(busy: boolean): "off" | "slow" | "idle" | "active" {
  if (typeof navigator !== "undefined" && navigator.onLine === false) return "off";
  if (looksSlow()) return "slow";
  if (busy || performance.now() < activeUntil) return "active";
  return "idle";
}

async function sendMicro() {
  const stamp = Date.now();
  try {
    return await timedFetch(`${CLOUD}/__down?bytes=5000&r=${stamp}-prime`);
  } catch {
    return await timedFetch(`/api/speed?bytes=5000&r=${stamp}-prime`);
  }
}

export async function primeLink(onStep: (step: "ociosa" | "lenta" | "pacote" | "espera" | "pronta", waitMs?: number) => void) {
  const idle = lastTraffic === 0 || performance.now() - lastTraffic > IDLE_MS;
  const slow = looksSlow();
  if (!idle && !slow) return { primed: false, waitMs: 0 };

  onStep(idle ? "ociosa" : "lenta");
  await new Promise((resolve) => setTimeout(resolve, 350));
  onStep("pacote");
  const took = await sendMicro();
  const waitMs = Math.round(Math.min(500, Math.max(100, took < 120 ? 180 : took < 300 ? 320 : 480)));
  onStep("espera", waitMs);
  await new Promise((resolve) => setTimeout(resolve, waitMs));
  touchTraffic();
  onStep("pronta");
  return { primed: true, waitMs };
}

async function kickUdp() {
  if (typeof RTCPeerConnection === "undefined") return false;
  const pc = new RTCPeerConnection({
    iceServers: [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }],
  });
  try {
    pc.createDataChannel("coil");
    await pc.setLocalDescription(await pc.createOffer());
    return await new Promise<boolean>((resolve) => {
      let done = false;
      const finish = (hit: boolean) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve(hit);
      };
      const timer = setTimeout(() => finish(false), 2500);
      pc.onicecandidate = (event) => {
        const cand = event.candidate?.candidate ?? "";
        if (cand.includes("typ srflx") || cand.includes("typ relay")) finish(true);
        else if (!event.candidate) finish(false);
      };
    });
  } catch {
    return false;
  } finally {
    pc.close();
  }
}

async function kick(url: string) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 4000);
  try {
    await fetch(url, { cache: "no-store", mode: "no-cors", signal: ctrl.signal });
    return true;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

export async function probeDns() {
  // Nativo, depois: trocar o DNS de verdade com VpnService, só para os nomes, apontando para 1.1.1.1.
  // O usuário autoriza a VPN uma vez. Não aumenta megabit. O navegador não consegue fazer isso.
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 2500);
  const t0 = performance.now();
  try {
    const res = await fetch("https://cloudflare-dns.com/dns-query?name=one.one.one.one&type=A", {
      headers: { accept: "application/dns-json" },
      cache: "no-store",
      signal: ctrl.signal,
    });
    if (!res.ok) return { kind: "none" as const, ms: null };
    const data = (await res.json()) as { Status?: number };
    const ms = Math.round(performance.now() - t0);
    if (data.Status !== 0) return { kind: "none" as const, ms };
    if (ms >= 1000) return { kind: "late" as const, ms };
    if (ms >= 300) return { kind: "slow" as const, ms };
    return { kind: "ok" as const, ms };
  } catch {
    return { kind: "none" as const, ms: null };
  } finally {
    clearTimeout(timer);
  }
}

export async function pokeNetwork(onStep?: (line: string) => void) {
  const stamp = Date.now();
  const say = (line: string) => onStep?.(line);
  say("Sintonizando redes...");
  const cloud = await cloudReachable();
  const base = cloud ? `${CLOUD}/__down` : "/api/speed";
  let before = 0;
  let dead = false;
  try {
    before = await timedFetch(`${base}?bytes=0&r=${stamp}-a`);
  } catch {
    dead = true;
  }
  say("Emitindo pulso...");
  try {
    await timedFetch(`${base}?bytes=5000&r=${stamp}-b1`);
  } catch {
    dead = true;
  }
  await new Promise((resolve) => setTimeout(resolve, 200));
  say("Emitindo pulso...");
  try {
    await timedFetch(`${base}?bytes=5000&r=${stamp}-b2`);
  } catch {
    dead = true;
  }
  say("Enviando UDP...");
  const udp = await kickUdp();
  const opened = (
    await Promise.all([
      kick(`${CLOUD}/__down?bytes=1000&r=${stamp}-k1`),
      kick(`https://cp.cloudflare.com/generate_204?r=${stamp}`),
      kick(`https://www.gstatic.com/generate_204?r=${stamp}`),
      kick(`/api/speed?bytes=1000&r=${stamp}-k2`),
    ])
  ).filter(Boolean).length;
  for (let beat = 1; beat <= 3; beat++) {
    try {
      await timedFetch(`${base}?bytes=1000&r=${stamp}-beat${beat}`);
    } catch {
      dead = true;
    }
    if (beat < 3) await new Promise((resolve) => setTimeout(resolve, 160));
  }
  await new Promise((resolve) => setTimeout(resolve, 300));
  let after = 0;
  let http = true;
  try {
    after = await timedFetch(`${base}?bytes=0&r=${stamp}-c`);
  } catch {
    http = false;
  }
  const woke = http && !dead && before - after > 100 && after < before * 0.65;
  touchTraffic();
  return {
    before: Math.round(before),
    after: Math.round(after),
    woke,
    revived: dead && http,
    opened,
    udp,
    http,
  };
}

export async function runSpeedTest(
  onPhase: (phase: SpeedPhase) => void,
  options?: { warm?: boolean },
): Promise<SpeedReading> {
  const stamp = Date.now();
  const warm = options?.warm !== false;
  const cloud = await cloudReachable();
  const paths = cloud ? cloudPaths(stamp) : ownPaths(stamp);

  onPhase("ping");
  const ping = await measurePing(paths.ping);

  onPhase("descida");
  if (warm) await warmDownload(paths.warm);
  const down = (await measureDownload(paths.down)).mbps;

  onPhase("subida");
  let up: number;
  try {
    up = await measureUpload(paths.up, warm);
  } catch (error) {
    if (!cloud) throw error;
    up = await measureUpload(ownPaths(stamp).up, false);
  }

  touchTraffic();
  return { down, up, ping: Math.round(ping.ping) };
}

export async function diagnosePacket() {
  if (typeof navigator !== "undefined" && navigator.onLine === false) return { kind: "off" as const, ms: null };
  const stamp = Date.now();
  const cloud = await cloudReachable();
  const url = cloud ? `${CLOUD}/__down?bytes=0&r=${stamp}-diag` : `/api/speed?bytes=0&r=${stamp}-diag`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 3000);
  const start = performance.now();
  try {
    const response = await fetch(url, { cache: "no-store", signal: ctrl.signal });
    if (!response.ok) throw new Error("pacote falhou");
    await response.arrayBuffer();
    return judgeResponse(performance.now() - start);
  } catch {
    return { kind: (typeof navigator !== "undefined" && navigator.onLine === false ? "off" : "none") as "off" | "none", ms: null };
  } finally {
    clearTimeout(timer);
  }
}

export function judgeResponse(ms: number) {
  const time = Math.round(ms);
  if (time >= 1000) return { kind: "late" as const, ms: time };
  if (time >= 300) return { kind: "slow" as const, ms: time };
  return { kind: "ok" as const, ms: time };
}

export function loadLine(idle: number, loaded: number | null) {
  if (loaded == null) return "Ping não voltou na descida";
  const clog = loaded >= idle + 150 && loaded >= Math.round(idle * 1.8);
  return clog ? `Rede entope na descida · ${loaded} ms` : `Ping firme na descida · ${loaded} ms`;
}

export function diagnosisLine(kind: "off" | "none" | "late" | "slow" | "ok", ms: number | null) {
  if (kind === "off") return "Queda de conexão durante o envio";
  if (kind === "none") return "Dados enviados sem retorno";
  if (kind === "late") return `Demorou demais · ${ms} ms`;
  if (kind === "slow") return `Respondeu, mas devagar · ${ms} ms`;
  return `Respondeu a tempo · ${ms} ms`;
}

export async function openSpeedLane() {
  const stamp = Date.now();
  const cloud = await cloudReachable();
  const paths = cloud ? cloudPaths(stamp) : ownPaths(stamp);
  return {
    cloud,
    async down(warm = false) {
      if (warm) await warmDownload(paths.warm);
      const reading = await measureDownload(paths.down, paths.ping);
      touchTraffic();
      return reading;
    },
    async up(warm = false) {
      let value: number;
      try {
        value = await measureUpload(paths.up, warm);
      } catch (error) {
        if (!cloud) throw error;
        value = await measureUpload(ownPaths(stamp).up, false);
      }
      touchTraffic();
      return value;
    },
    async ping() {
      const reading = await measurePing(paths.ping);
      touchTraffic();
      return { ping: Math.round(reading.ping), jitter: Math.round(reading.jitter) };
    },
  };
}
