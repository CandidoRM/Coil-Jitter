const KEY = "coil-place";

type Box = { status: "denied" } | { status: "saved"; city: string; state: string; uf: string };

export type CoilPlace = { city: string; state: string; uf: string; start: string; startBr: string };

function memory() {
  try {
    return typeof localStorage === "undefined" ? null : localStorage;
  } catch {
    return null;
  }
}

function readBox(): Box | null {
  const raw = memory()?.getItem(KEY);
  if (!raw) return null;
  try {
    const data = JSON.parse(raw) as Box;
    if (data?.status === "denied") return data;
    if (data?.status === "saved" && data.city && data.state) return data;
  } catch {
    /* segue */
  }
  return null;
}

function startDates() {
  const day = new Date();
  day.setDate(day.getDate() - 3);
  const y = day.getFullYear();
  const m = String(day.getMonth() + 1).padStart(2, "0");
  const d = String(day.getDate()).padStart(2, "0");
  return { start: `${y}-${m}-${d}`, startBr: `${d}/${m}/${y}` };
}

export function readPlace(): CoilPlace | null {
  const box = readBox();
  if (!box || box.status !== "saved") return null;
  const dates = startDates();
  const place = { city: box.city, state: box.state, uf: box.uf, start: dates.start, startBr: dates.startBr };
  if (typeof window !== "undefined") (window as Window & { CoilPlace?: CoilPlace }).CoilPlace = place;
  return place;
}

export async function ensurePlace() {
  if (typeof window === "undefined" || !navigator.geolocation) return;
  if (readPlace()) return;
  if (readBox()?.status === "denied") return;
  const outcome = await new Promise<"denied" | "later" | GeolocationPosition>((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve(pos),
      (error) => resolve(error.code === 1 ? "denied" : "later"),
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 300_000 },
    );
  });
  if (outcome === "denied") {
    memory()?.setItem(KEY, JSON.stringify({ status: "denied" }));
    return;
  }
  if (outcome === "later") return;
  try {
    const response = await fetch(`/api/place?lat=${outcome.coords.latitude}&lon=${outcome.coords.longitude}`, { cache: "no-store" });
    if (!response.ok) return;
    const data = (await response.json()) as { city?: string; state?: string; uf?: string };
    if (!data.city || !data.state) return;
    memory()?.setItem(KEY, JSON.stringify({ status: "saved", city: data.city, state: data.state, uf: data.uf || "" }));
    readPlace();
  } catch {
    /* a próxima abertura tenta de novo */
  }
}
