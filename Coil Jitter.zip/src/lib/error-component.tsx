import { useEffect, useState } from "react";
import type { ErrorComponentProps } from "@tanstack/react-router";
import { faultDead, noteFault } from "@/lib/fault";

export function AppErrorComponent({ error }: ErrorComponentProps) {
  const [dead, setDead] = useState(faultDead);
  useEffect(() => {
    const result = noteFault(error);
    if (result === "dead" || faultDead()) setDead(true);
  }, [error]);
  if (!dead) return null;
  return (
    <main className="flex h-full flex-col items-center justify-center gap-6 px-6 text-center">
      <p className="clock-doing">Coil Jitter Off-line</p>
      <div className="key-stack">
        <button type="button" className="speed-redo is-off" disabled aria-label="Medir" />
        <button type="button" className="speed-redo wake-redo is-off" disabled aria-label="Sintonizar" />
      </div>
    </main>
  );
}