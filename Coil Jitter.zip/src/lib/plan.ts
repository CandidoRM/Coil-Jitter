import { useSyncExternalStore } from "react";

const KEY = "sinal-plano";

export type Plan = {
  capGb: number;
  usedGb: number;
  renewDay: number;
};

const fallback: Plan = { capGb: 20, usedGb: 6.4, renewDay: 14 };

let plan: Plan = fallback;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((listener) => listener());
}

function valid(value: Plan) {
  return (
    value.capGb > 0 &&
    value.usedGb >= 0 &&
    value.renewDay >= 1 &&
    value.renewDay <= 31
  );
}

export function subscribePlan(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function getPlan() {
  return plan;
}

export function getServerPlan() {
  return fallback;
}

export function hydratePlan() {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? "") as Plan;
    if (valid(raw)) plan = raw;
  } catch {
    plan = fallback;
  }
  emit();
}

export function savePlan(next: Plan) {
  if (!valid(next)) return;
  plan = next;
  localStorage.setItem(KEY, JSON.stringify(next));
  emit();
}

export function usePlan() {
  return useSyncExternalStore(subscribePlan, getPlan, getServerPlan);
}

export function daysUntilRenew(day: number, now = new Date()) {
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  let target = new Date(now.getFullYear(), now.getMonth(), day);
  if (target < start) target = new Date(now.getFullYear(), now.getMonth() + 1, day);
  return Math.round((target.getTime() - start.getTime()) / 86400000);
}
