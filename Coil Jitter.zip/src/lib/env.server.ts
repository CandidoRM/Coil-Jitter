import { readFileSync } from "node:fs";

let fileEnv: Record<string, string> | null = null;

function readFileEnv() {
  if (fileEnv) return fileEnv;
  fileEnv = {};
  try {
    const text = readFileSync(`${process.cwd()}/.env`, "utf8");
    for (const line of text.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const cut = trimmed.indexOf("=");
      if (cut < 1) continue;
      const key = trimmed.slice(0, cut).trim();
      if (!/^[A-Z0-9_]+$/.test(key) || key.startsWith("VITE_")) continue;
      fileEnv[key] = trimmed.slice(cut + 1).trim();
    }
  } catch {
    /* sem arquivo */
  }
  return fileEnv;
}

export function env(key: string): string | undefined {
  const v = (process.env[key] ?? readFileEnv()[key])?.trim();
  return v || undefined;
}

/**
 * Workspace preview vs deployed app. The deployer writes GROK_PROJECT_ID on
 * every publish; the sandbox preview never has it. Single source of truth for
 * the split — gate audience, gate endpoints and connector-token semantics all
 * key off this predicate.
 */
export function isWorkspacePreview(): boolean {
  return !env("GROK_PROJECT_ID");
}
