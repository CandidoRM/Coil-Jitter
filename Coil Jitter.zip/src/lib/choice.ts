import { useSyncExternalStore } from "react";
import { concepts, type ConceptId } from "@/lib/net";

const KEY = "sinal-interface";
const FUNDO_KEY = "coil-fundo";
const BOTAO_KEY = "coil-botao";
const ACORDAR_KEY = "coil-acordar";
const EFEITO_KEY = "coil-efeito";
const CHAPA_KEY = "coil-chapa";
const DEFAULT_ID = 4 as ConceptId;
const DEFAULT_FUNDO = 32 as ConceptId;
const DEFAULT_BOTAO = 44 as ConceptId;
const DEFAULT_ACORDAR = 53 as ConceptId;
const DEFAULT_EFEITO = 60 as ConceptId;
const DEFAULT_CHAPA = 81 as ConceptId;
const CHAPA_PICK = "coil-chapa-pick";

let chosen: ConceptId = DEFAULT_ID;
let fundo: ConceptId = DEFAULT_FUNDO;
let botao: ConceptId = DEFAULT_BOTAO;
let acordar: ConceptId = DEFAULT_ACORDAR;
let efeito: ConceptId = DEFAULT_EFEITO;
let chapa: ConceptId | null = DEFAULT_CHAPA;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((listener) => listener());
}

export function subscribeChoice(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function getChosen() {
  return chosen;
}

export function getServerChosen() {
  return DEFAULT_ID;
}

function hasKind(id: number, kind: string) {
  return concepts.some((item) => item.id === id && "kind" in item && item.kind === kind);
}

function isFundo(id: number) {
  return hasKind(id, "fundo");
}

function isBotao(id: number) {
  return hasKind(id, "botao");
}

function isAcordar(id: number) {
  return hasKind(id, "acordar");
}

function isEfeito(id: number) {
  return hasKind(id, "efeito");
}

function isChapa(id: number) {
  return hasKind(id, "chapa");
}

function isTela(id: number) {
  return concepts.some((item) => item.id === id && !isFundo(id) && !isBotao(id) && !isAcordar(id) && !isEfeito(id) && !isChapa(id));
}

export function hydrateChoice() {
  const n = Number(localStorage.getItem(KEY));
  chosen = isTela(n) ? (n as ConceptId) : DEFAULT_ID;
  if (!isTela(n)) localStorage.setItem(KEY, String(DEFAULT_ID));
  const f = Number(localStorage.getItem(FUNDO_KEY));
  fundo = isFundo(f) ? (f as ConceptId) : DEFAULT_FUNDO;
  const b = Number(localStorage.getItem(BOTAO_KEY));
  botao = isBotao(b) ? (b as ConceptId) : DEFAULT_BOTAO;
  const a = Number(localStorage.getItem(ACORDAR_KEY));
  acordar = isAcordar(a) ? (a as ConceptId) : DEFAULT_ACORDAR;
  const e = Number(localStorage.getItem(EFEITO_KEY));
  efeito = isEfeito(e) ? (e as ConceptId) : DEFAULT_EFEITO;
  const c = Number(localStorage.getItem(CHAPA_KEY));
  if (localStorage.getItem(CHAPA_PICK) !== "uso") {
    chapa = DEFAULT_CHAPA;
    localStorage.setItem(CHAPA_KEY, String(DEFAULT_CHAPA));
    localStorage.setItem(CHAPA_PICK, "uso");
  } else {
    chapa = isChapa(c) ? (c as ConceptId) : DEFAULT_CHAPA;
    if (!isChapa(c)) localStorage.setItem(CHAPA_KEY, String(DEFAULT_CHAPA));
  }
  emit();
}

export function chooseConcept(id: ConceptId) {
  if (isFundo(id)) {
    fundo = id;
    localStorage.setItem(FUNDO_KEY, String(id));
    emit();
    return;
  }
  if (isBotao(id)) {
    botao = id;
    localStorage.setItem(BOTAO_KEY, String(id));
    emit();
    return;
  }
  if (isAcordar(id)) {
    acordar = id;
    localStorage.setItem(ACORDAR_KEY, String(id));
    emit();
    return;
  }
  if (isEfeito(id)) {
    efeito = id;
    localStorage.setItem(EFEITO_KEY, String(id));
    emit();
    return;
  }
  if (isChapa(id)) {
    chapa = id;
    localStorage.setItem(CHAPA_KEY, String(id));
    emit();
    return;
  }
  chosen = id;
  localStorage.setItem(KEY, String(id));
  emit();
}

export function useChosen() {
  return useSyncExternalStore(subscribeChoice, getChosen, getServerChosen);
}

export function useBackground() {
  return useSyncExternalStore(subscribeChoice, () => fundo, () => DEFAULT_FUNDO);
}

export function useButton() {
  return useSyncExternalStore(subscribeChoice, () => botao, () => DEFAULT_BOTAO);
}

export function useWakeIcon() {
  return useSyncExternalStore(subscribeChoice, () => acordar, () => DEFAULT_ACORDAR);
}

export function useVisorEffect() {
  return useSyncExternalStore(subscribeChoice, () => efeito, () => DEFAULT_EFEITO);
}

export function useChapa() {
  return useSyncExternalStore(subscribeChoice, () => chapa, () => DEFAULT_CHAPA);
}
