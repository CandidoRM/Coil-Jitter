export type SpeedReading = { down: number; up: number; ping: number };
export type SpeedPhase = "ping" | "descida" | "subida";

const CLOUD = "https://speed.cloudflare.com";
const WINDOW_MS = 4_000;
const DOWN_CAP = 12_000_000;
const PARALLEL = 6;
const UP_BYTES = 500_000;
const UP_PARALLEL = 2;

let halt = new AbortController();

export function haltCoil() {
  halt.abort();
  halt = new AbortController();
}

function liveCtrl() {
  const ctrl = new AbortController();
  if (halt.signal.aborted) {
    ctrl.abort();
    return ctrl;
  }
  const stop = () => ctrl.abort();
  halt.signal.addEventListener("abort", stop, { once: true });
  ctrl.signal.addEventListener("abort", () => halt.signal.removeEventListener("abort", stop), { once: true });
  return ctrl;
}

function mbps(bytes: number, ms: number) {
  if (ms < 1 || bytes < 1) return 0;
  return (bytes * 8) / ms / 1000;
}

function median(values: number[]) {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}

const bodyCache = new Map<number, ArrayBuffer>();

function randomBody(bytes: number) {
  const cached = bodyCache.get(bytes);
  if (cached) return cached;
  const buffer = new ArrayBuffer(bytes);
  const payload = new Uint8Array(buffer);
  for (let offset = 0; offset < bytes; offset += 65536) {
    crypto.getRandomValues(payload.subarray(offset, Math.min(bytes, offset + 65536)));
  }
  bodyCache.set(bytes, buffer);
  return buffer;
}

function warmUploadBodies() {
  randomBody(64_000);
  randomBody(UP_BYTES);
}

if (typeof window !== "undefined") {
  const idle = (window as Window & { requestIdleCallback?: (fn: () => void) => number }).requestIdleCallback;
  if (idle) idle(() => warmUploadBodies());
  else window.setTimeout(warmUploadBodies, 1200);
}

function cloudPaths(stamp: number) {
  return {
    ping: (i: number) => `${CLOUD}/__down?bytes=0&r=${stamp}-p${i}`,
    warm: (i: number) => `${CLOUD}/__down?bytes=400000&r=${stamp}-w${i}`,
    down: (i: number) => `${CLOUD}/__down?bytes=25000000&r=${stamp}-d${i}`,
    up: `${CLOUD}/__up?r=${stamp}-u`,
  };
}

function ownPaths(stamp: number) {
  return {
    ping: (i: number) => `/api/speed?bytes=0&r=${stamp}-p${i}`,
    warm: (i: number) => `/api/speed?bytes=400000&r=${stamp}-w${i}`,
    down: (i: number) => `/api/speed?bytes=12000000&r=${stamp}-d${i}`,
    up: `/api/speed?r=${stamp}-u`,
  };
}

async function cloudReachable() {
  const ctrl = liveCtrl();
  const timer = setTimeout(() => ctrl.abort(), 2500);
  try {
    const response = await fetch(`${CLOUD}/__down?bytes=0&r=${Date.now()}`, {
      cache: "no-store",
      signal: ctrl.signal,
    });
    return response.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

async function pull(url: string, signal: AbortSignal, add: (bytes: number) => void) {
  const response = await fetch(url, { cache: "no-store", signal });
  if (!response.ok || !response.body) throw new Error("medida falhou");
  const reader = response.body.getReader();
  try {
    while (!signal.aborted) {
      const { done, value } = await reader.read();
      if (done || !value) break;
      add(value.byteLength);
      noteRx(value.byteLength);
    }
  } catch (error) {
    if (signal.aborted) return;
    throw error;
  } finally {
    reader.cancel().catch(() => {});
  }
}

async function measurePing(url: (i: number) => string) {
  const samples = [];
  let lost = 0;
  for (let i = 0; i < 5; i++) {
    const start = performance.now();
    try {
      const response = await fetch(url(i), { cache: "no-store" });
      if (!response.ok) throw new Error("medida falhou");
      const pingBody = await response.arrayBuffer();
      noteRx(pingBody.byteLength || 1);
      if (i > 0) samples.push(performance.now() - start);
    } catch (error) {
      if (i === 0) throw error;
      lost += 1;
    }
  }
  if (!samples.length) throw new Error("medida falhou");
  let drift = 0;
  for (let i = 1; i < samples.length; i++) drift += Math.abs(samples[i] - samples[i - 1]);
  return {
    ping: median(samples),
    jitter: samples.length > 1 ? drift / (samples.length - 1) : 0,
    lost,
  };
}

function loadedMbps(ticks: { t: number; bytes: number }[]) {
  if (ticks.length < 2) return 0;
  const first = ticks[0];
  const last = ticks[ticks.length - 1];
  const span = last.t - first.t;
  if (span < 1) return 0;
  const cut = first.t + span * 0.25;
  const mark = ticks.find((tick) => tick.t >= cut);
  const from = mark && last.t - mark.t >= 600 && last.bytes - mark.bytes >= 60_000 ? mark : first;
  return mbps(last.bytes - from.bytes, last.t - from.t);
}

async function warmDownload(url: (i: number) => string) {
  const ctrl = liveCtrl();
  const timer = setTimeout(() => ctrl.abort(), 4000);
  try {
    await Promise.all(Array.from({ length: PARALLEL }, (_, i) => pull(url(i), ctrl.signal, () => {})));
  } catch {
    /* abre a conexão; o volume não entra na conta */
  } finally {
    clearTimeout(timer);
    ctrl.abort();
  }
}

async function oneLoadedPing(url: string) {
  const ctrl = liveCtrl();
  const timer = setTimeout(() => ctrl.abort(), 4000);
  const start = performance.now();
  try {
    const response = await fetch(url, { cache: "no-store", signal: ctrl.signal });
    if (!response.ok) return null;
    const loadedBody = await response.arrayBuffer();
    noteRx(loadedBody.byteLength || 1);
    return Math.round(performance.now() - start);
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

const NEAR_DOWN = [
  "https://sao.download.datapacket.com/100mb.bin",
  "https://eze.download.datapacket.com/100mb.bin",
  "https://scl.download.datapacket.com/100mb.bin",
  "https://bog.download.datapacket.com/100mb.bin",
  "https://lim.download.datapacket.com/100mb.bin",
];

async function firstByte(url: string) {
  const ctrl = liveCtrl();
  const timer = setTimeout(() => ctrl.abort(), 1800);
  const start = performance.now();
  try {
    const response = await fetch(`${url}?r=${Date.now()}`, { cache: "no-store", signal: ctrl.signal });
    if (!response.ok || !response.body) return null;
    const reader = response.body.getReader();
    const { value } = await reader.read();
    reader.cancel().catch(() => {});
    if (!value) return null;
    return performance.now() - start;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
    ctrl.abort();
  }
}

export async function closestDownloads(count = 2) {
  const scored = await Promise.all(NEAR_DOWN.map(async (url) => ({ url, ms: await firstByte(url) })));
  return scored
    .filter((row): row is { url: string; ms: number } => row.ms != null)
    .sort((a, b) => a.ms - b.ms)
    .slice(0, count)
    .map((row) => row.url);
}

export function fairDown(values: number[]) {
  const ready = values.filter((n) => Number.isFinite(n) && n > 0);
  if (ready.length <= 1) return ready[0] ?? 0;
  const kept = ready.filter((value, index) => {
    const others = ready.filter((_, i) => i !== index);
    const mid = others.reduce((sum, n) => sum + n, 0) / others.length;
    return value >= mid * 0.6;
  });
  const use = kept.length ? kept : ready;
  return use.reduce((sum, n) => sum + n, 0) / use.length;
}

export async function onceDownload(fileUrl: string) {
  const stamp = Date.now();
  try {
    const reading = await measureDownload((i) => `${fileUrl}?r=${stamp}-${i}`);
    touchTraffic();
    return reading.mbps;
  } catch {
    return null;
  }
}

async function measureDownload(url: (i: number) => string, probe?: (i: number) => string): Promise<{ mbps: number; loaded: number | null }> {
  const ctrl = liveCtrl();
  const ticks: { t: number; bytes: number }[] = [];
  let bytes = 0;
  let seq = 0;
  let windowTimer: ReturnType<typeof setTimeout> | undefined;
  let loadedTask: Promise<number | null> | null = null;
  const failsafe = setTimeout(() => ctrl.abort(), WINDOW_MS + 8_000);
  const add = (n: number) => {
    windowTimer ??= setTimeout(() => ctrl.abort(), WINDOW_MS);
    bytes += n;
    const now = performance.now();
    if (ticks.length === 0) ticks.push({ t: now, bytes });
    else {
      const last = ticks[ticks.length - 1];
      if (ticks.length === 1 || now - last.t >= 100) ticks.push({ t: now, bytes });
      else {
        last.t = now;
        last.bytes = bytes;
      }
    }
    if (probe && !loadedTask) {
      loadedTask = new Promise((resolve) => {
        setTimeout(() => resolve(oneLoadedPing(probe(90))), 800);
      });
    }
    if (bytes >= DOWN_CAP) ctrl.abort();
  };
  async function worker() {
    while (!ctrl.signal.aborted && bytes < DOWN_CAP) {
      try {
        await pull(url(seq++), ctrl.signal, add);
      } catch (error) {
        if (ctrl.signal.aborted) return;
        throw error;
      }
    }
  }
  try {
    await Promise.all(Array.from({ length: PARALLEL }, () => worker()));
  } finally {
    clearTimeout(failsafe);
    if (windowTimer) clearTimeout(windowTimer);
    ctrl.abort();
  }
  if (ticks.length === 1 && bytes > 0) ticks.push({ t: Math.max(performance.now(), ticks[0].t + 1), bytes });
  if (bytes < 50_000 || ticks.length < 2) throw new Error("medida falhou");
  return { mbps: loadedMbps(ticks), loaded: loadedTask ? await loadedTask : null };
}

function sendUpload(url: string, body: ArrayBuffer) {
  return new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const timer = setTimeout(() => {
      xhr.abort();
      reject(new Error("medida falhou"));
    }, 12_000);
    xhr.open("POST", url);
    xhr.setRequestHeader("content-type", "application/octet-stream");
    const stop = () => {
      clearTimeout(timer);
      halt.signal.removeEventListener("abort", stop);
      xhr.abort();
      reject(new Error("medida falhou"));
    };
    if (halt.signal.aborted) {
      stop();
      return;
    }
    halt.signal.addEventListener("abort", stop, { once: true });
    const finish = () => {
      clearTimeout(timer);
      halt.signal.removeEventListener("abort", stop);
    };
    xhr.upload.onload = () => {
      finish();
      resolve();
    };
    xhr.upload.onerror = () => {
      finish();
      reject(new Error("medida falhou"));
    };
    xhr.onerror = () => {
      finish();
      reject(new Error("medida falhou"));
    };
    xhr.send(body);
    noteTx(body.byteLength);
  });
}

async function measureUpload(url: string, warm: boolean) {
  if (warm) {
    try {
      await sendUpload(url, randomBody(64_000));
    } catch {
      /* aquecimento */
    }
  }
  const bodies = Array.from({ length: UP_PARALLEL }, () => randomBody(UP_BYTES));
  const started = performance.now();
  await Promise.all(bodies.map((body) => sendUpload(url, body)));
  return mbps(UP_BYTES * bodies.length, performance.now() - started);
}

async function timedFetch(url: string) {
  const ctrl = liveCtrl();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  const start = performance.now();
  try {
    const response = await fetch(url, { cache: "no-store", signal: ctrl.signal });
    if (!response.ok) throw new Error("pacote falhou");
    const timedBody = await response.arrayBuffer();
    noteRx(timedBody.byteLength || 1);
    return performance.now() - start;
  } finally {
    clearTimeout(timer);
  }
}

const IDLE_MS = 10_000;
let lastTraffic = 0;
let pageRx = 0;
let pageTx = 0;

export function noteRx(bytes: number) {
  if (bytes > 0) pageRx += bytes;
}

export function noteTx(bytes: number) {
  if (bytes > 0) pageTx += bytes;
}

export function readTraffic() {
  // Nativo, depois: TrafficStats do aparelho, só enquanto o Coil está aberto.
  // Grava rx e tx em CoilNative e dispara "coil-traffic".
  // Até lá, conta os bytes do próprio Coil. Não muda a medição.
  const native = coilNative();
  if (typeof native?.rx === "number" || typeof native?.tx === "number") {
    return { rx: native?.rx ?? 0, tx: native?.tx ?? 0 };
  }
  return { rx: pageRx, tx: pageTx };
}

function touchTraffic() {
  lastTraffic = performance.now();
}

export function linkIdle() {
  return lastTraffic === 0 || performance.now() - lastTraffic > IDLE_MS;
}

function generationParts(mbps: number | null) {
  const speed = mbps == null || !Number.isFinite(mbps) ? null : mbps < 0.3 ? 2 : mbps < 5 ? 3 : mbps < 50 ? 4 : 5;
  if (typeof navigator === "undefined") return { phone: null, speed };
  const connection = (navigator as Navigator & { connection?: { effectiveType?: string } }).connection;
  const reported = connection?.effectiveType;
  const phone = reported === "slow-2g" || reported === "2g" ? 2 : reported === "3g" ? 3 : reported === "4g" ? 4 : null;
  return { phone, speed };
}

export function generationMark(mbps: number | null) {
  const { phone, speed } = generationParts(mbps);
  const name = (n: number) => `${n}G`;
  if (speed == null) return phone == null ? "" : name(phone);
  if (phone == null) return name(speed);
  if (Math.abs(phone - speed) >= 2) {
    const mid = (phone + speed) / 2;
    if (Number.isInteger(mid)) return name(mid);
    return `${name(Math.floor(mid))}–${name(Math.ceil(mid))}`;
  }
  if (phone === 4 && speed >= 5) return "5G";
  return name(speed >= phone ? speed : phone);
}

export function generationLine(mbps: number): string {
  const { phone, speed } = generationParts(mbps);
  const settled = speed ?? 4;
  const name = (n: number) => `${n}G`;
  if (phone == null) return `O celular não informa a geração · a descida parece ${name(settled)}`;
  if (Math.abs(phone - settled) >= 2) {
    const mid = (phone + settled) / 2;
    if (Number.isInteger(mid)) return `Destoa do celular · média ${name(mid)}`;
    return `Destoa do celular · entre ${name(Math.floor(mid))} e ${name(Math.ceil(mid))}`;
  }
  if (phone === 4 && settled >= 4) return "Perto do celular · 4G ou mais";
  return `Confere com o celular · ${name(phone)}`;
}

export function linkFacts() {
  if (typeof navigator === "undefined" || navigator.onLine === false) return [];
  const lines: string[] = [];
  const connection = (navigator as Navigator & {
    connection?: {
      type?: string;
      effectiveType?: string;
      rtt?: number;
      downlink?: number;
      saveData?: boolean;
    };
  }).connection;
  if (!connection) {
    lines.push("O aparelho não informa o tipo.");
    return lines;
  }
  if (connection.type === "wifi") lines.push("Caminho: Wi-fi.");
  else if (connection.type === "cellular") lines.push("Caminho: plano.");
  else if (connection.type === "ethernet") lines.push("Caminho: cabo.");
  else if (connection.type === "bluetooth") lines.push("Caminho: Bluetooth.");
  else if (connection.type === "none") lines.push("Sem interface de rede.");
  else if (connection.type) lines.push("Caminho não identificado.");
  if (connection.saveData) lines.push("Economia de dados ligada.");
  if (typeof connection.rtt === "number" && connection.rtt >= 1000) lines.push(`O aparelho estima a resposta muito alta · ${Math.round(connection.rtt)} ms`);
  else if (typeof connection.rtt === "number" && connection.rtt >= 300) lines.push(`O aparelho estima a resposta alta · ${Math.round(connection.rtt)} ms`);
  if (typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < 0.5) lines.push("O aparelho estima a descida muito baixa.");
  else if (typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < 1.5) lines.push("O aparelho estima a descida baixa.");
  return lines;
}

function looksSlow() {
  const connection = (navigator as Navigator & {
    connection?: { effectiveType?: string; rtt?: number; downlink?: number };
  }).connection;
  if (!connection) return false;
  if (connection.effectiveType === "slow-2g" || connection.effectiveType === "2g" || connection.effectiveType === "3g") {
    return true;
  }
  if (typeof connection.rtt === "number" && connection.rtt >= 300) return true;
  return typeof connection.downlink === "number" && connection.downlink > 0 && connection.downlink < 1.5;
}

export function linkSlow() {
  return looksSlow();
}

let activeUntil = 0;

export function noteAction() {
  activeUntil = performance.now() + IDLE_MS;
}

let gate: "up" | "local" | "portal" | "down" = "up";

export function setGate(next: "up" | "local" | "portal" | "down") {
  gate = next;
}

export function readLane() {
  if (typeof navigator === "undefined") return null;
  const nav = navigator as Navigator & { connection?: { type?: string }; userAgentData?: { mobile?: boolean } };
  const kind = nav.connection?.type;
  if (kind === "ethernet") return "cable" as const;
  if (kind === "bluetooth") return "bt" as const;
  if (kind === "cellular") return "cell" as const;
  if (kind === "wifi") return "wifi" as const;
  if (kind === "none") return null;
  const pc = !nav.userAgentData?.mobile && !/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  return pc ? ("wifi" as const) : null;
}

export function readVpn() {
  // Nativo, depois: ConnectivityManager, TRANSPORT_VPN.
  // O WebView define window.CoilNative.vpn e dispara "coil-vpn".
  // A página não descobre VPN sozinha. Não muda a medição.
  return coilNative()?.vpn === true;
}

export const interruptionUrl = "https://consultaesaq.com.br/interrupcao/#/interrupcoes/home";

export function readInterruption() {
  // Nativo, depois: uma página só da Anatel, atrás do Coil, sem aparecer na tela.
  // O botão reaproveita essa mesma página. Se ela não puder ser reusada, a anterior fecha antes da nova.
  // Nunca ficam duas. Resetar e sair do app fecham essa página.
  // Ela precisa continuar carregada durante a consulta. Se não responder escondida, a busca falha e o visor fica em silêncio.
  // Primeiro aperta Histórico de Interrupções. A pesquisa começa nessa tela.
  // Lê window.CoilPlace. Preenche o estado primeiro e espera a lista abrir.
  // Só então preenche o município. Se inverter, o município não aparece.
  // Data de início: startBr, no máximo 3 dias atrás.
  // Prestadora: window.CoilCarrier, só se os dados móveis estiverem levando o tráfego.
  // Veio do chip em uso (se houver dois, vale o dos dados). No Wi-Fi, deixa em branco.
  // Chip dos Correios entra como TIM.
  // Depois aperta Pesquisar na própria página.
  // Lê só o aviso mais recente e grava em window.CoilNative.interruption.
  // Dispara "coil-esaq". A página não lê esse portal sozinha. Não muda a medição.
  const text = coilNative()?.interruption?.trim();
  return text || "";
}

export function towerPhrase(meters: number) {
  if (!Number.isFinite(meters) || meters < 0) return "";
  if (meters <= 400) return "Torres próximas";
  if (meters <= 1500) return "Torres afastadas";
  if (meters <= 5000) return "Torres longínquas";
  return "Torres remotas";
}

export function readTowers() {
  // Nativo, nesta ordem:
  // 1. Lê a célula em uso: MCC, MNC, TAC e o número da célula. Grava em CoilNative.cell.
  // Na mesma leitura, pega o dBm dessa célula (getDbm) e grava em CoilNative.dbm.
  // 2. Lê o GPS de agora, onde o usuário está. Não usa a cidade salva. Grava em CoilNative.fix.
  // 3. Só com os dois, consulta a OpenCellID e recebe a latitude e a longitude estimadas.
  // 4. Compara com o GPS e grava a distância em CoilNative.towerMeters. Dispara "coil-tower".
  // Sem célula ou sem GPS, não consulta. A página não mostra metro, célula nem coordenada.
  // Não muda a medição.
  const native = coilNative();
  const cell = native?.cell;
  const fix = native?.fix;
  if (!cell || !Number.isFinite(cell.mcc) || !Number.isFinite(cell.mnc) || !Number.isFinite(cell.tac) || !Number.isFinite(cell.id)) return "";
  if (!fix || !Number.isFinite(fix.lat) || !Number.isFinite(fix.lon)) return "";
  if (typeof native?.towerMeters !== "number") return "";
  return towerPhrase(native.towerMeters);
}

export function readDbm() {
  if (typeof navigator === "undefined" || readLane() !== "cell") return null;
  const dbm = coilNative()?.dbm;
  if (typeof dbm !== "number" || !Number.isFinite(dbm) || dbm >= 0 || dbm < -150) return null;
  return Math.round(dbm);
}

export function openInterruptions() {
  // Nativo: no máximo uma página, atrás do Coil, fora da tela.
  // Abre sozinha no fim do Medir, depois das emissões. Não há botão para isso.
  // Se ela já existe, reaproveita a mesma. Não abre outra.
  // Se não der para reaproveitar, fecha a anterior e só então abre uma.
  // Nunca empilha. Ao sair do Coil ou no Resetar, fecha essa única página.
  const open = coilNative()?.openInterruptions;
  if (!open) return false;
  open();
  return true;
}

function coilNative() {
  if (typeof window === "undefined") return undefined;
  return (window as Window & { CoilNative?: { vpn?: boolean; interruption?: string; carrier?: string; towerMeters?: number; dbm?: number; rx?: number; tx?: number; cell?: { mcc: number; mnc: number; tac: number; id: number }; fix?: { lat: number; lon: number }; requestCarrier?: () => void; openInterruptions?: () => void } }).CoilNative;
}

export async function probeReach() {
  if (typeof navigator !== "undefined" && navigator.onLine === false) return "down" as const;
  const ctrl = liveCtrl();
  const timer = setTimeout(() => ctrl.abort(), 2500);
  try {
    const response = await fetch("/api/reach", { cache: "no-store", signal: ctrl.signal });
    if (response.redirected) {
      const here = new URL(response.url).host;
      if (here && here !== location.host) return "portal" as const;
    }
    if (!response.ok) return "local" as const;
    return "up" as const;
  } catch {
    return navigator.onLine === false ? ("down" as const) : ("local" as const);
  } finally {
    clearTimeout(timer);
  }
}

export function linkMark(busy: boolean): "off" | "slow" | "idle" | "active" {
  if (typeof navigator !== "undefined" && navigator.onLine === false) return "off";
  if (gate !== "up") return "off";
  if (looksSlow()) return "slow";
  if (busy || performance.now() < activeUntil) return "active";
  return "idle";
}

async function sendMicro() {
  const stamp = Date.now();
  try {
    return await timedFetch(`${CLOUD}/__down?bytes=5000&r=${stamp}-prime`);
  } catch {
    return await timedFetch(`/api/speed?bytes=5000&r=${stamp}-prime`);
  }
}

export async function primeLink(onStep: (step: "ociosa" | "lenta" | "pacote" | "espera" | "pronta", waitMs?: number) => void) {
  const idle = lastTraffic === 0 || performance.now() - lastTraffic > IDLE_MS;
  const slow = looksSlow();
  if (!idle && !slow) return { primed: false, waitMs: 0 };

  onStep(idle ? "ociosa" : "lenta");
  await new Promise((resolve) => setTimeout(resolve, 350));
  onStep("pacote");
  const took = await sendMicro();
  const waitMs = Math.round(Math.min(500, Math.max(100, took < 120 ? 180 : took < 300 ? 320 : 480)));
  onStep("espera", waitMs);
  await new Promise((resolve) => setTimeout(resolve, waitMs));
  touchTraffic();
  onStep("pronta");
  return { primed: true, waitMs };
}

async function kickUdp() {
  if (typeof RTCPeerConnection === "undefined") return false;
  const pc = new RTCPeerConnection({
    iceServers: [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }],
  });
  try {
    pc.createDataChannel("coil");
    await pc.setLocalDescription(await pc.createOffer());
    return await new Promise<boolean>((resolve) => {
      let done = false;
      const finish = (hit: boolean) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve(hit);
      };
      const timer = setTimeout(() => finish(false), 2500);
      pc.onicecandidate = (event) => {
        const cand = event.candidate?.candidate ?? "";
        if (cand.includes("typ srflx") || cand.includes("typ relay")) finish(true);
        else if (!event.candidate) finish(false);
      };
    });
  } catch {
    return false;
  } finally {
    pc.close();
  }
}

async function kick(url: string) {
  const ctrl = liveCtrl();
  const timer = setTimeout(() => ctrl.abort(), 4000);
  try {
    await fetch(url, { cache: "no-store", mode: "no-cors", signal: ctrl.signal });
    return true;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

export async function probeOutages(place: { city?: string; state?: string; uf?: string } | null, carrier: string): Promise<string[]> {
  const params = new URLSearchParams();
  if (place?.city) params.set("city", place.city);
  if (place?.state) params.set("state", place.state);
  if (place?.uf) params.set("uf", place.uf);
  if (carrier) params.set("carrier", carrier);
  try {
    const response = await fetch(`/api/outage?${params}`, { cache: "no-store" });
    if (!response.ok) return [];
    const data = (await response.json()) as { lines?: string[] };
    return (data.lines ?? []).filter((line) => line === "Queda aberta na região" || line === "Queda aberta na operadora");
  } catch {
    return [];
  }
}

export async function probePages(): Promise<string[]> {
  try {
    const response = await fetch("/api/pages", { cache: "no-store" });
    if (!response.ok) return ["Páginas sem retorno"];
    const data = (await response.json()) as { lines?: string[] };
    return data.lines?.length ? data.lines : ["Páginas sem retorno"];
  } catch {
    return ["Páginas sem retorno"];
  }
}

export async function probeDns() {
  // Nativo, depois: trocar o DNS de verdade com VpnService, só para os nomes, apontando para 1.1.1.1.
  // O usuário autoriza a VPN uma vez. Não aumenta megabit. O navegador não consegue fazer isso.
  const ctrl = liveCtrl();
  const timer = setTimeout(() => ctrl.abort(), 2500);
  const t0 = performance.now();
  try {
    const res = await fetch("https://cloudflare-dns.com/dns-query?name=one.one.one.one&type=A", {
      headers: { accept: "application/dns-json" },
      cache: "no-store",
      signal: ctrl.signal,
    });
    if (!res.ok) return { kind: "none" as const, ms: null };
    const data = (await res.json()) as { Status?: number };
    const ms = Math.round(performance.now() - t0);
    if (data.Status !== 0) return { kind: "none" as const, ms };
    if (ms >= 1000) return { kind: "late" as const, ms };
    if (ms >= 300) return { kind: "slow" as const, ms };
    return { kind: "ok" as const, ms };
  } catch {
    return { kind: "none" as const, ms: null };
  } finally {
    clearTimeout(timer);
  }
}

async function clockFetch(url: string) {
  const ctrl = liveCtrl();
  const timer = setTimeout(() => ctrl.abort(), 2500);
  const t0 = performance.now();
  try {
    await fetch(url, { cache: "no-store", mode: "no-cors", signal: ctrl.signal });
    return Math.round(performance.now() - t0);
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

export async function probePhoneDns() {
  const ip = await clockFetch("https://1.1.1.1/cdn-cgi/trace");
  const named = await clockFetch("https://one.one.one.one/cdn-cgi/trace");
  if (ip == null || named == null) return null;
  return Math.max(0, named - ip);
}

export function dnsGap(cloudMs: number | null, phoneMs: number | null) {
  if (cloudMs == null || phoneMs == null) return "";
  if (phoneMs >= cloudMs * 2 && phoneMs - cloudMs >= 200) return "DNS do celular mais lento que o da Cloudflare";
  return "";
}

const COLO: Record<string, string> = {
  GRU: "São Paulo",
  GIG: "Rio de Janeiro",
  FOR: "Fortaleza",
  SSA: "Salvador",
  BSB: "Brasília",
  CWB: "Curitiba",
  POA: "Porto Alegre",
  MAO: "Manaus",
  BEL: "Belém",
  REC: "Recife",
  CNF: "Belo Horizonte",
  FLN: "Florianópolis",
  VIX: "Vitória",
  NAT: "Natal",
  AJU: "Aracaju",
  SLZ: "São Luís",
  JPA: "João Pessoa",
  THE: "Teresina",
  CGB: "Cuiabá",
  CGR: "Campo Grande",
  EZE: "Buenos Aires",
  SCL: "Santiago",
  BOG: "Bogotá",
  LIM: "Lima",
  MIA: "Miami",
  IAD: "Ashburn",
  ATL: "Atlanta",
  DFW: "Dallas",
  LAX: "Los Angeles",
  ORD: "Chicago",
  EWR: "Nova York",
  LIS: "Lisboa",
  MAD: "Madrid",
  LHR: "Londres",
  CDG: "Paris",
  FRA: "Frankfurt",
  AMS: "Amsterdã",
};

export function exitPhrase(city: string, ping: number | null, signalGood: boolean) {
  if (!city) return "";
  if (signalGood && ping != null && ping >= 300) return `Saindo por ${city} · caminho longo`;
  return `Saindo por ${city}`;
}

export function carrierPhrase(name: string) {
  return name.trim();
}

export async function probeExit() {
  try {
    const res = await fetch("https://1.1.1.1/cdn-cgi/trace", { cache: "no-store" });
    if (!res.ok) return { city: "", carrier: "" };
    const text = await res.text();
    noteRx(text.length || 1);
    const field = (key: string) => text.match(new RegExp(`^${key}=(.+)$`, "m"))?.[1]?.trim() ?? "";
    const city = COLO[field("colo")] || field("colo");
    const warp = field("warp");
    if (warp === "on" || warp === "plus") return { city, carrier: "Cloudflare WARP" };
    const ip = field("ip");
    if (!ip) return { city, carrier: "" };
    const who = await fetch(`/api/who?ip=${encodeURIComponent(ip)}`, { cache: "no-store" });
    if (!who.ok) return { city, carrier: "" };
    const data = (await who.json()) as { name?: string };
    return { city, carrier: data.name?.trim() || "" };
  } catch {
    return { city: "", carrier: "" };
  }
}

export async function probeOutside(place: string) {
  const where = place.trim() || "Brazil";
  try {
    const created = await fetch("https://api.globalping.io/v1/measurements", {
      method: "POST",
      headers: { "content-type": "application/json" },
      cache: "no-store",
      body: JSON.stringify({
        type: "ping",
        target: "speed.cloudflare.com",
        locations: [{ magic: where, limit: 1 }],
        measurementOptions: { packets: 3 },
      }),
    });
    if (!created.ok) return "";
    const job = (await created.json()) as { id?: string };
    if (!job.id) return "";
    for (let i = 0; i < 6; i++) {
      await new Promise((resolve) => setTimeout(resolve, 700));
      const res = await fetch(`https://api.globalping.io/v1/measurements/${job.id}`, { cache: "no-store" });
      if (!res.ok) return "";
      const data = (await res.json()) as {
        status?: string;
        results?: { probe?: { city?: string }; result?: { status?: string; stats?: { avg?: number; loss?: number } } }[];
      };
      if (data.status !== "finished") continue;
      const row = data.results?.[0];
      const stats = row?.result?.stats;
      if (row?.result?.status !== "finished" || !stats || typeof stats.avg !== "number") return "";
      if ((stats.loss ?? 0) > 0 || stats.avg >= 300) return "De fora também está ruim";
      const city = row.probe?.city?.trim() || (place.trim() ? where : "Brasil");
      return `De ${city} o destino responde`;
    }
    return "";
  } catch {
    return "";
  }
}

export async function pokeNetwork(onStep?: (line: string) => void) {
  const stamp = Date.now();
  const say = (line: string) => onStep?.(line);
  say("Sintonizando redes...");
  const cloud = await cloudReachable();
  const base = cloud ? `${CLOUD}/__down` : "/api/speed";
  let before = 0;
  let dead = false;
  try {
    before = await timedFetch(`${base}?bytes=0&r=${stamp}-a`);
  } catch {
    dead = true;
  }
  say("Emitindo pulso...");
  try {
    await timedFetch(`${base}?bytes=5000&r=${stamp}-b1`);
  } catch {
    dead = true;
  }
  await new Promise((resolve) => setTimeout(resolve, 200));
  say("Emitindo pulso...");
  try {
    await timedFetch(`${base}?bytes=5000&r=${stamp}-b2`);
  } catch {
    dead = true;
  }
  say("Enviando UDP...");
  const udp = await kickUdp();
  const opened = (
    await Promise.all([
      kick(`${CLOUD}/__down?bytes=1000&r=${stamp}-k1`),
      kick(`https://cp.cloudflare.com/generate_204?r=${stamp}`),
      kick(`https://www.gstatic.com/generate_204?r=${stamp}`),
      kick(`/api/speed?bytes=1000&r=${stamp}-k2`),
    ])
  ).filter(Boolean).length;
  for (let beat = 1; beat <= 3; beat++) {
    try {
      await timedFetch(`${base}?bytes=1000&r=${stamp}-beat${beat}`);
    } catch {
      dead = true;
    }
    if (beat < 3) await new Promise((resolve) => setTimeout(resolve, 160));
  }
  await new Promise((resolve) => setTimeout(resolve, 300));
  let after = 0;
  let http = true;
  try {
    after = await timedFetch(`${base}?bytes=0&r=${stamp}-c`);
  } catch {
    http = false;
  }
  const woke = http && !dead && before - after > 100 && after < before * 0.65;
  touchTraffic();
  return {
    before: Math.round(before),
    after: Math.round(after),
    woke,
    revived: dead && http,
    opened,
    udp,
    http,
  };
}

export async function runSpeedTest(
  onPhase: (phase: SpeedPhase) => void,
  options?: { warm?: boolean },
): Promise<SpeedReading> {
  const stamp = Date.now();
  const warm = options?.warm !== false;
  const cloud = await cloudReachable();
  const paths = cloud ? cloudPaths(stamp) : ownPaths(stamp);

  onPhase("ping");
  const ping = await measurePing(paths.ping);

  onPhase("descida");
  if (warm) await warmDownload(paths.warm);
  const down = (await measureDownload(paths.down)).mbps;

  onPhase("subida");
  let up: number;
  try {
    up = await measureUpload(paths.up, warm);
  } catch (error) {
    if (!cloud) throw error;
    up = await measureUpload(ownPaths(stamp).up, false);
  }

  touchTraffic();
  return { down, up, ping: Math.round(ping.ping) };
}

export async function diagnosePacket() {
  if (typeof navigator !== "undefined" && navigator.onLine === false) return { kind: "off" as const, ms: null };
  const stamp = Date.now();
  const cloud = await cloudReachable();
  const url = cloud ? `${CLOUD}/__down?bytes=0&r=${stamp}-diag` : `/api/speed?bytes=0&r=${stamp}-diag`;
  const ctrl = liveCtrl();
  const timer = setTimeout(() => ctrl.abort(), 3000);
  const start = performance.now();
  try {
    const response = await fetch(url, { cache: "no-store", signal: ctrl.signal });
    if (!response.ok) throw new Error("pacote falhou");
    const probeBody = await response.arrayBuffer();
    noteRx(probeBody.byteLength || 1);
    return judgeResponse(performance.now() - start);
  } catch {
    return { kind: (typeof navigator !== "undefined" && navigator.onLine === false ? "off" : "none") as "off" | "none", ms: null };
  } finally {
    clearTimeout(timer);
  }
}

export function judgeResponse(ms: number) {
  const time = Math.round(ms);
  if (time >= 1000) return { kind: "late" as const, ms: time };
  if (time >= 300) return { kind: "slow" as const, ms: time };
  return { kind: "ok" as const, ms: time };
}

export function loadLine(idle: number, loaded: number | null) {
  if (loaded == null) return "Ping não voltou na descida";
  const clog = loaded >= idle + 150 && loaded >= Math.round(idle * 1.8);
  return clog ? `Rede entope na descida · ${loaded} ms` : `Ping firme na descida · ${loaded} ms`;
}

export function diagnosisLine(kind: "off" | "none" | "late" | "slow" | "ok", ms: number | null) {
  if (kind === "off") return "Queda de conexão durante o envio";
  if (kind === "none") return "Dados enviados sem retorno";
  if (kind === "late") return `Demorou demais · ${ms} ms`;
  if (kind === "slow") return `Respondeu, mas devagar · ${ms} ms`;
  return `Respondeu a tempo · ${ms} ms`;
}

export async function openSpeedLane() {
  const stamp = Date.now();
  const cloud = await cloudReachable();
  const paths = cloud ? cloudPaths(stamp) : ownPaths(stamp);
  return {
    cloud,
    async down(warm = false) {
      if (warm) await warmDownload(paths.warm);
      const reading = await measureDownload(paths.down, paths.ping);
      touchTraffic();
      return reading;
    },
    async up(warm = false) {
      let value: number;
      try {
        value = await measureUpload(paths.up, warm);
      } catch (error) {
        if (!cloud) throw error;
        value = await measureUpload(ownPaths(stamp).up, false);
      }
      touchTraffic();
      return value;
    },
    async ping() {
      const reading = await measurePing(paths.ping);
      touchTraffic();
      return { ping: Math.round(reading.ping), jitter: Math.round(reading.jitter), lost: reading.lost };
    },
  };
}
