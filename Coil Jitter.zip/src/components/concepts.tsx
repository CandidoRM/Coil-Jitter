import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent, type ReactElement, type ReactNode } from "react";
import { Antenna, DraftingCompass, Gauge, HeartPulse, Microscope, Radar, Radio, RadioTower, Rss, Ruler, SatelliteDish, ScanSearch, Signal, Stethoscope, TestTubes, TowerControl, Wifi, type LucideIcon } from "lucide-react";
import { diagnosePacket, diagnosisLine, judgeResponse, linkFacts, openSpeedLane, pokeNetwork, primeLink } from "@/lib/speed";
import { br, concepts, diary, pulse, snapshot, type ConceptId } from "@/lib/net";
import { useBackground, useButton, useChapa, useVisorEffect, useWakeIcon } from "@/lib/choice";

type Frame = { chrome?: boolean; actions?: boolean };
type Link = { down: number | null; up: number | null; ping: number | null; jitter: number | null } | null;

function useRandomFlicker(active = true) {
  const [ms, setMs] = useState<number | null>(null);
  useEffect(() => {
    if (!active) return;
    let alive = true;
    let timer = 0;
    const play = () => {
      if (!alive) return;
      const dur = 1700 + Math.random() * 700;
      setMs(dur);
      timer = window.setTimeout(() => {
        if (!alive) return;
        setMs(null);
        timer = window.setTimeout(play, 250 + Math.random() * 3250);
      }, dur);
    };
    timer = window.setTimeout(play, 250 + Math.random() * 3250);
    return () => {
      alive = false;
      window.clearTimeout(timer);
    };
  }, [active]);
  return ms;
}

function SegNum({ value }: { value: string }) {
  const comma = value.indexOf(",");
  if (comma < 0) return value;
  return (
    <>
      {value.slice(0, comma).replaceAll(".", "")}
      <i className="seg-dec">,</i>
      {value.slice(comma + 1)}
    </>
  );
}

function segLong(value: string) {
  return value.replace(/\D/g, "").length >= 5;
}

function Shell({
  slug,
  chrome,
  children,
  bare,
  live,
  tone,
}: Frame & { slug: string; children: ReactNode; bare?: boolean; live?: boolean; tone?: string }) {
  return (
    <section
      className={`concept concept-${slug} ${chrome ? "concept-chrome" : ""} ${live ? "concept-live" : ""} ${tone ? `bg-${tone}` : ""} ${bare ? "" : "px-5 pb-28 pt-5"}`}
    >
      {children}
    </section>
  );
}

function Kicker({ children }: { children: ReactNode }) {
  return <p className="c-muted text-xs tracking-widest uppercase">{children}</p>;
}

function Campo({ chrome }: Frame) {
  return (
    <Shell slug="campo" chrome={chrome}>
      <Kicker>Campo · {snapshot.carrier} {snapshot.tech}</Kicker>
      <div className="relative mx-auto mt-10 grid h-56 w-56 place-items-center">
        <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full" aria-hidden>
          <circle cx="100" cy="100" r="92" className="ring ring-dim" />
          <circle cx="100" cy="100" r="68" className="ring ring-dim" />
          <circle cx="100" cy="100" r="44" className="ring ring-hot" />
        </svg>
        <div className="relative text-center">
          <div className="c-accent text-5xl leading-none tabular-nums">{snapshot.dbm}</div>
          <div className="c-muted mt-1 text-xs tracking-widest">dBm</div>
        </div>
      </div>
      <dl className="mt-10 grid grid-cols-3 gap-3 text-center">
        <div>
          <dt className="c-muted text-xs">Desce</dt>
          <dd className="mt-1 text-lg tabular-nums">{br(snapshot.down)}</dd>
        </div>
        <div>
          <dt className="c-muted text-xs">Sobe</dt>
          <dd className="mt-1 text-lg tabular-nums">{br(snapshot.up)}</dd>
        </div>
        <div>
          <dt className="c-muted text-xs">Ping</dt>
          <dd className="mt-1 text-lg tabular-nums">{snapshot.ping}</dd>
        </div>
      </dl>
    </Shell>
  );
}

function Sentenca({ chrome }: Frame) {
  return (
    <Shell slug="sentenca" chrome={chrome}>
      <Kicker>{snapshot.place}</Kicker>
      <h1 className="mt-6 text-6xl leading-none tracking-tight">Sinal bom.</h1>
      <p className="c-muted mt-6 max-w-xs text-2xl leading-snug">
        {snapshot.carrier} {snapshot.tech}, {snapshot.dbm} dBm.
      </p>
      <dl className="c-rule mt-16 grid grid-cols-3 gap-4 border-t pt-5 text-sm">
        <div>
          <dt className="c-muted">Ping</dt>
          <dd className="mt-1 tabular-nums">{snapshot.ping} ms</dd>
        </div>
        <div>
          <dt className="c-muted">Desce</dt>
          <dd className="mt-1 tabular-nums">{br(snapshot.down)}</dd>
        </div>
        <div>
          <dt className="c-muted">Plano</dt>
          <dd className="mt-1 tabular-nums">{br(snapshot.usedGb)} GB</dd>
        </div>
      </dl>
    </Shell>
  );
}

function Cockpit({ chrome }: Frame) {
  const tiles = [
    { k: "Sinal", v: `${snapshot.bars}/4`, u: `${snapshot.dbm} dBm` },
    { k: "Ping", v: String(snapshot.ping), u: "ms" },
    { k: "Desce", v: br(snapshot.down), u: "Mb/s" },
    { k: "Sobe", v: br(snapshot.up), u: "Mb/s" },
  ];
  return (
    <Shell slug="cockpit" chrome={chrome}>
      <Kicker>Cockpit · {snapshot.tech}</Kicker>
      <div className="mt-5 grid grid-cols-2 gap-3">
        {tiles.map((tile) => (
          <div key={tile.k} className="c-surface rounded-xl px-3 py-4">
            <div className="c-muted text-xs tracking-widest uppercase">{tile.k}</div>
            <div className="c-accent mt-3 text-4xl leading-none tabular-nums">{tile.v}</div>
            <div className="c-muted mt-2 text-xs">{tile.u}</div>
          </div>
        ))}
      </div>
    </Shell>
  );
}

function Franquia({ chrome, actions }: Frame) {
  const fundo = useBackground();
  const botao = useButton();
  const acordar = useWakeIcon();
  const efeito = useVisorEffect();
  const chapa = useChapa();
  const RedoIcon = redoIcons[botao] ?? RadioTower;
  const WakeIcon = wakeIcons[acordar] ?? Radio;
  const tone = concepts.find((item) => item.id === fundo)?.slug;
  const efeitoClass = efeito ? `efeito-${concepts.find((item) => item.id === efeito)?.slug ?? ""}` : "";
  const chapaClass = chapa ? `chapa-${concepts.find((item) => item.id === chapa)?.slug ?? ""}` : "";
  const [link, setLink] = useState<Link>(null);
  const [net, setNet] = useState<string | null>(null);
  const [reading, setReading] = useState<"idle" | "busy" | "none">("idle");
  const [poking, setPoking] = useState(false);
  const runRef = useRef(false);
  const medirHeld = useRef(false);
  const wakeHeld = useRef(false);
  const pokingRef = useRef(false);
  const queueRef = useRef<{ state: string; doing: string }[]>([]);
  const shownRef = useRef({ state: "Pronto", doing: "Carregando bobina..." });
  const timerRef = useRef<number | null>(null);
  const holdRef = useRef(false);
  const litRef = useRef(false);
  const tuneRef = useRef(false);
  const [shown, setShown] = useState(shownRef.current);
  const visorFx = efeitoClass === "efeito-grao" && shown.doing === "Carregando bobina..." ? "" : efeitoClass;
  const [fadeKey, setFadeKey] = useState(0);
  const [lit, setLit] = useState(false);
  const [tune, setTune] = useState(false);
  const [diag, setDiag] = useState("");
  const [diagKey, setDiagKey] = useState(0);
  const [online, setOnline] = useState(true);
  const diagQueue = useRef<string[]>([]);
  const diagTimer = useRef<number | null>(null);
  const diagShown = useRef("");
  const flick = useRandomFlicker();

  function playDiag() {
    if (diagTimer.current !== null) return;
    const next = diagQueue.current.shift();
    if (!next) return;
    diagShown.current = next;
    setDiag(next);
    setDiagKey((n) => n + 1);
    diagTimer.current = window.setTimeout(() => {
      diagTimer.current = null;
      playDiag();
    }, 1800);
  }

  function tell(line: string) {
    const last = diagQueue.current.at(-1) ?? diagShown.current;
    if (last === line) return;
    diagQueue.current.push(line);
    playDiag();
  }

  function tellNow(line: string) {
    diagQueue.current = [];
    if (diagTimer.current !== null) {
      window.clearTimeout(diagTimer.current);
      diagTimer.current = null;
    }
    diagShown.current = "";
    tell(line);
  }

  function releaseLight() {
    if (holdRef.current || timerRef.current !== null || queueRef.current.length > 0) return;
    if (!litRef.current) return;
    litRef.current = false;
    setLit(false);
    if (tuneRef.current) {
      tuneRef.current = false;
      setTune(false);
    }
  }

  function playNext() {
    if (timerRef.current !== null) return;
    const next = queueRef.current.shift();
    if (!next) {
      releaseLight();
      return;
    }
    shownRef.current = next;
    setShown(next);
    setFadeKey((n) => n + 1);
    timerRef.current = window.setTimeout(() => {
      timerRef.current = null;
      playNext();
    }, 500);
  }

  function say(state: string, doing: string) {
    const last = queueRef.current.at(-1) ?? shownRef.current;
    if (last.state === state && last.doing === doing) return;
    queueRef.current.push({ state, doing });
    playNext();
  }

  function beginLight() {
    holdRef.current = true;
    if (litRef.current) return;
    litRef.current = true;
    setLit(true);
  }

  function beginTune() {
    tuneRef.current = true;
    setTune(true);
    beginLight();
  }

  function endLight() {
    holdRef.current = false;
    releaseLight();
  }

  useEffect(() => {
    timerRef.current = window.setTimeout(() => {
      timerRef.current = null;
      playNext();
    }, 500);
    const report = () => {
      setOnline(navigator.onLine);
      say("Pronto", navigator.onLine ? "On-line" : "Off-line");
    };
    setOnline(navigator.onLine);
    const bootOnline = actions && navigator.onLine;
    if (!bootOnline) {
      if (document.readyState === "complete") report();
      else window.addEventListener("load", report, { once: true });
    }
    window.addEventListener("online", report);
    window.addEventListener("offline", report);
    const releaseHold = () => {
      medirHeld.current = false;
      wakeHeld.current = false;
    };
    window.addEventListener("pointerup", releaseHold);
    window.addEventListener("pointercancel", releaseHold);
    let alive = true;
    const boot = window.setTimeout(() => {
      if (alive && bootOnline) void measure();
    }, 0);
    return () => {
      alive = false;
      window.clearTimeout(boot);
      window.removeEventListener("load", report);
      window.removeEventListener("online", report);
      window.removeEventListener("offline", report);
      window.removeEventListener("pointerup", releaseHold);
      window.removeEventListener("pointercancel", releaseHold);
      if (timerRef.current !== null) window.clearTimeout(timerRef.current);
      if (diagTimer.current !== null) window.clearTimeout(diagTimer.current);
    };
  }, []);

  const down = link?.down ?? null;
  const up = link?.up ?? null;
  const ping = link?.ping ?? null;
  const jitter = link?.jitter ?? null;
  const downText = reading === "busy" && down == null ? "…" : down != null ? br(down) : "_";
  const upText = reading === "busy" && up == null ? "…" : up != null ? br(up) : "—";
  const pingText = reading === "busy" && ping == null ? "…" : ping != null ? String(ping) : "—";
  const jitterText = reading === "busy" && jitter == null ? "…" : jitter != null ? String(jitter) : "—";
  const netText = reading === "busy" && net == null ? "…" : net ?? "—";
  const blinking = (text: string) => text === "—" || text === "…" || text === "_";
  const sweeping = lit && !tune;

  function pause() {
    return new Promise((resolve) => setTimeout(resolve, 1000));
  }

  async function measure() {
    if (runRef.current || pokingRef.current) return;
    runRef.current = true;
    beginLight();
    const kind = (navigator as Navigator & { connection?: { type?: string } }).connection?.type;
    const pc = !(navigator as Navigator & { userAgentData?: { mobile?: boolean } }).userAgentData?.mobile
      && !/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
    setNet(pc || kind === "wifi" || kind === "ethernet" ? "Wi-fi" : kind === "cellular" ? "Plano" : null);
    setReading("busy");
    setLink(null);
    let down: number | null = null;
    let up: number | null = null;
    let cause = "O pacote saiu e não voltou.";
    async function cycle() {
      if (navigator.onLine === false) {
        cause = "Sem conexão. O pacote não saiu.";
        throw new Error("off");
      }
      let lane: Awaited<ReturnType<typeof openSpeedLane>> | null = null;
      const path = async () => (lane ??= await openSpeedLane());
      if (down == null) {
        cause = "O pacote saiu e não voltou.";
        tellNow("Enviando pacote...");
        const probe = await diagnosePacket();
        tellNow(diagnosisLine(probe.kind, probe.ms));
        if (probe.kind === "off" || probe.kind === "none") {
          cause = diagnosisLine(probe.kind, probe.ms);
          throw new Error("diag");
        }
        cause = "A descida não voltou.";
        const prime = await primeLink((step) => {
          say(
            "Medindo",
            step === "ociosa"
              ? "Rede ociosa"
              : step === "lenta"
                ? "Rede lenta"
                : step === "pacote"
                  ? "Preparando medição..."
                  : step === "espera"
                    ? "Aguardando retorno"
                    : "Conexão iniciada",
          );
        });
        say("Medindo", prime.primed ? "Conexão iniciada" : "Rede ativa");
        if (prime.primed) tell(`Esperou ${prime.waitMs} ms`);
        const road = await path();
        say("Medindo", "Recebendo dados...");
        const down1 = await road.down(true);
        await pause();
        const down2 = await road.down(false);
        down = (down1 + down2) / 2;
        setLink({ down, up: null, ping: null, jitter: null });
      }
      if (up == null) {
        cause = "A subida não voltou.";
        const road = await path();
        say("Medindo", "Transferindo dados...");
        const up1 = await road.up(true);
        await pause();
        const up2 = await road.up(false);
        up = (up1 + up2) / 2;
        setLink({ down, up, ping: null, jitter: null });
        await pause();
      }
      cause = "O ping não voltou.";
      const road = await path();
      say("Medindo", "Calculando latência...");
      const ping1 = await road.ping();
      setLink({ down, up, ping: ping1.ping, jitter: ping1.jitter });
      await pause();
      const ping2 = await road.ping();
      const ping = Math.round((ping1.ping + ping2.ping) / 2);
      const jitter = Math.round((ping1.jitter + ping2.jitter) / 2);
      setLink({ down, up, ping, jitter });
      const reply = judgeResponse(ping);
      tellNow(diagnosisLine(reply.kind, reply.ms));
      for (const line of linkFacts()) tell(line);
      say("Pronto", navigator.onLine ? "On-line" : "Off-line");
      setReading("idle");
    }
    try {
      try {
        await cycle();
      } catch {
        await cycle();
      }
    } catch {
      tellNow(cause);
      for (const line of linkFacts()) tell(line);
      say("Falhou", "Medição sem sucesso");
      setReading("none");
    } finally {
      runRef.current = false;
      endLight();
      if (medirHeld.current) void measure();
      else if (wakeHeld.current) wake();
    }
  }

  function wake() {
    if (runRef.current || pokingRef.current) return;
    pokingRef.current = true;
    beginTune();
    setPoking(true);
    pokeNetwork((line) => say("Sintonizar", line))
      .then((result) => {
        say(
          "Sintonizar",
          !result.http && result.udp
            ? "UDP retornou sem HTTP"
            : !result.http
              ? "Não respondeu"
              : result.revived
                ? "Voltou a responder"
                : result.woke
                  ? "Mais rápido"
                  : result.udp
                    ? "Respondeu · UDP saiu"
                    : "Respondeu · igual",
        );
      })
      .catch(() => say("Sintonizar", "Não respondeu"))
      .finally(() => {
        pokingRef.current = false;
        setPoking(false);
        endLight();
        if (wakeHeld.current) wake();
        else if (medirHeld.current) void measure();
      });
  }

  const pointerUsed = useRef(false);

  function holdStart(which: "medir" | "wake", event: ReactPointerEvent<HTMLButtonElement>) {
    if (event.button !== 0) return;
    event.preventDefault();
    pointerUsed.current = true;
    if (which === "medir") medirHeld.current = true;
    else wakeHeld.current = true;
    if (which === "medir") void measure();
    else wake();
  }

  function holdEnd(which: "medir" | "wake") {
    if (which === "medir") medirHeld.current = false;
    else wakeHeld.current = false;
    window.setTimeout(() => {
      pointerUsed.current = false;
    }, 0);
  }

  function pressClick(which: "medir" | "wake") {
    if (pointerUsed.current) {
      pointerUsed.current = false;
      return;
    }
    if (which === "medir") void measure();
    else wake();
  }

  return (
    <Shell slug="franquia" chrome={chrome} bare={actions} live={actions} tone={actions ? tone : undefined}>
      {actions ? (
        <svg className="lamp-cut" aria-hidden="true" width="0" height="0">
          <filter id="visor-lamp" filterUnits="objectBoundingBox" primitiveUnits="userSpaceOnUse" x="-1.6" y="-1.6" width="4.2" height="4.2" colorInterpolationFilters="sRGB">
            <feGaussianBlur in="SourceAlpha" stdDeviation="1.4" result="b1" />
            <feFlood floodColor="rgb(255, 190, 90)" result="c1" />
            <feComposite in="c1" in2="b1" operator="in" result="g1" />
            <feGaussianBlur in="SourceAlpha" stdDeviation="3" result="b2" />
            <feFlood floodColor="rgb(255, 110, 20)" floodOpacity="0.4" result="c2" />
            <feComposite in="c2" in2="b2" operator="in" result="g2" />
            <feMerge>
              <feMergeNode in="g2" />
              <feMergeNode in="g1" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </svg>
      ) : null}
      <div className={actions ? "flex h-full flex-col px-5 pt-16" : ""}>
        {actions ? <h1 className="plate-name" aria-label="Coil Jitter"><span>Coil Jitter</span></h1> : null}
        <div className={actions ? "coil-grid" : undefined}>
          <div className={actions ? "coil-span descida-row" : undefined}>
            <div className={`speed-square ${visorFx} ${sweeping ? "is-waking" : ""}`}>
              <p>
                <span key={downText} className={`fosforo-figure is-fading${segLong(downText) ? " is-long" : ""}`}>
                  <span className={blinking(downText) ? "caret" : ""}><SegNum value={downText} /></span>
                </span>
                <span className="fosforo-unit">Mb/s</span>
                <i className="fosforo-scan" aria-hidden />
              </p>
              <i className="coil-sweep" aria-hidden />
            </div>
            {actions ? (
              <span className={`net-mark${online ? " is-on" : ""}`} role="status" aria-label={online ? "On-line" : "Off-line"}>
                <Wifi size={20} strokeWidth={2.4} aria-hidden />
              </span>
            ) : null}
          </div>
          <div className="speed-side">
            <div className={`speed-chip ${visorFx} ${sweeping ? "is-waking" : ""}`}>
              <div>
                <span key={`sobe-${upText}`} className="is-fading">
                  sobe <span className={`seg-num ${blinking(upText) ? "caret" : ""}`}><SegNum value={upText} /></span> Mb/s
                </span>
                <span key={`ping-${pingText}`} className="is-fading">
                  ping <span className={`seg-num ${blinking(pingText) ? "caret" : ""}`}><SegNum value={pingText} /></span> ms
                </span>
                <span key={`jitter-${jitterText}`} className="is-fading">
                  jitter <span className={`seg-num ${blinking(jitterText) ? "caret" : ""}`}><SegNum value={jitterText} /></span> ms
                </span>
                <i className="fosforo-scan" aria-hidden />
              </div>
              <i className="coil-sweep" aria-hidden />
            </div>
            <div className={`speed-chip ${visorFx} ${sweeping ? "is-waking" : ""}`}>
              <div>
                <span key={netText} className="is-fading">
                  <span className={blinking(netText) ? "caret" : ""}>{netText}</span>
                </span>
                <i className="fosforo-scan" aria-hidden />
              </div>
              <i className="coil-sweep" aria-hidden />
            </div>
          </div>
          {actions ? (
            <span className="plate-key">
              <button
                type="button"
                className={`speed-redo is-off ${chapaClass} ${reading === "busy" ? "is-busy" : ""} ${reading === "busy" && online ? "is-lit" : ""}`}
                aria-label="Medir"
                onPointerDown={(event) => holdStart("medir", event)}
                onPointerUp={() => holdEnd("medir")}
                onPointerCancel={() => holdEnd("medir")}
                onContextMenu={(event) => event.preventDefault()}
                onClick={() => pressClick("medir")}
              >
                <RedoIcon size={22} strokeWidth={2.25} />
              </button>
            </span>
          ) : null}
          {actions ? (
            <>
              <section className={`clock-field coil-span ${visorFx} ${lit ? "is-waking" : ""}`} aria-label={`Visor de Estado. ${shown.doing}`}>
                <div className="clock-readout">
                  <div key={fadeKey} className={`clock-copy ${fadeKey ? "is-fading" : ""}`}>
                    {shown.state === "Pronto" || shown.state === "Medindo" || shown.state === "Sintonizar" || shown.state === "Falhou" ? null : <p className={`clock-state ${flick ? "is-flick" : ""}`} style={flick ? { ["--flick" as string]: `${flick}ms` } : undefined}>{shown.state}</p>}
                    <p className={`clock-doing ${flick ? "is-flick" : ""}`} style={flick ? { ["--flick" as string]: `${flick}ms` } : undefined}>{shown.doing}</p>
                  </div>
                </div>
                <i className="coil-sweep" aria-hidden />
              </section>
              <section className={`clock-field clock-extra coil-span ${visorFx} ${sweeping ? "is-waking" : ""}`} aria-label={diag || "Diagnóstico"}>
                <div className="clock-readout">
                  <div key={diagKey} className={`clock-copy ${diagKey ? "is-fading" : ""}`}>
                    <p className={`clock-doing ${flick ? "is-flick" : ""}`} style={flick ? { ["--flick" as string]: `${flick}ms` } : undefined}>{diag}</p>
                  </div>
                </div>
                <i className="coil-sweep" aria-hidden />
              </section>
              <span className="plate-key is-wake">
                <button
                  type="button"
                  className={`speed-redo wake-redo is-off ${chapaClass} ${poking ? "is-busy" : ""} ${poking && online ? "is-lit" : ""}`}
                  aria-label="Sintonizar"
                  onPointerDown={(event) => holdStart("wake", event)}
                  onPointerUp={() => holdEnd("wake")}
                  onPointerCancel={() => holdEnd("wake")}
                  onContextMenu={(event) => event.preventDefault()}
                  onClick={() => pressClick("wake")}
                >
                  <WakeIcon size={22} strokeWidth={2.25} />
                </button>
              </span>
            </>
          ) : null}
        </div>
      </div>
    </Shell>
  );
}

function Pulso({ chrome }: Frame) {
  const w = 320;
  const h = 96;
  const max = Math.max(...pulse);
  const min = Math.min(...pulse);
  const d = pulse
    .map((v, i) => {
      const x = (i / (pulse.length - 1)) * w;
      const y = h - ((v - min) / (max - min)) * (h - 8) - 4;
      return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <Shell slug="pulso" chrome={chrome}>
      <Kicker>Pulso</Kicker>
      <p className="mt-6 text-6xl leading-none tabular-nums tracking-tight">
        {snapshot.ping}
        <span className="c-muted text-2xl"> ms</span>
      </p>
      <svg viewBox={`0 0 ${w} ${h}`} className="mt-8 h-24 w-full" aria-hidden>
        <path d={d} fill="none" stroke="currentColor" strokeWidth="2" className="c-accent" />
      </svg>
      <p className="c-muted mt-3 text-sm">Latência nos últimos minutos.</p>
      <p className="c-accent mt-6 text-sm">Pico de 48 ms às 07:40, na queda.</p>
    </Shell>
  );
}

function Barras({ chrome }: Frame) {
  return (
    <Shell slug="barras" chrome={chrome}>
      <Kicker>Barras</Kicker>
      <div className="mt-8 flex h-72 items-end gap-3">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={`flex-1 rounded-sm ${i <= snapshot.bars ? "c-fill" : "c-track"}`}
            style={{ height: `${22 + i * 18}%` }}
          />
        ))}
      </div>
      <p className="mt-6 text-3xl leading-none">Três de quatro.</p>
      <p className="c-muted mt-3 text-sm">
        {snapshot.carrier} · {snapshot.tech} · {snapshot.dbm} dBm
      </p>
    </Shell>
  );
}

function Diario({ chrome }: Frame) {
  return (
    <Shell slug="diario" chrome={chrome}>
      <Kicker>Sexta, 2 de outubro</Kicker>
      <h1 className="c-serif mt-3 text-4xl leading-none tracking-tight">Diário da rede</h1>
      <ol className="mt-8">
        {diary.map((item, index) => (
          <li key={item.t} className="grid grid-cols-[3.2rem_1fr] gap-3">
            <div className="c-muted pt-3 text-xs tabular-nums">{item.t}</div>
            <div className={`c-rule py-3 ${index ? "border-t" : ""}`}>
              <div className="font-medium">{item.title}</div>
              <div className="c-muted text-sm">{item.detail}</div>
            </div>
          </li>
        ))}
      </ol>
    </Shell>
  );
}

function Relogio({ chrome }: Frame) {
  const pct = 0.68;
  const r = 78;
  const circ = 2 * Math.PI * r;
  const dash = circ * pct;
  return (
    <Shell slug="relogio" chrome={chrome}>
      <Kicker>Relógio · {snapshot.carrier}</Kicker>
      <div className="relative mx-auto mt-8 grid h-64 w-64 place-items-center">
        <svg viewBox="0 0 200 200" className="h-full w-full" aria-hidden>
          <circle cx="100" cy="100" r={r} className="arc-track" />
          <circle
            cx="100"
            cy="100"
            r={r}
            className="arc-value"
            strokeDasharray={`${dash} ${circ - dash}`}
            transform="rotate(-90 100 100)"
          />
        </svg>
        <div className="absolute text-center">
          <div className="c-serif text-5xl leading-none">{snapshot.quality}</div>
          <div className="c-muted mt-2 text-sm tabular-nums">{snapshot.dbm} dBm</div>
        </div>
      </div>
      <p className="c-muted mt-6 text-center text-sm">
        {snapshot.tech} · {snapshot.ping} ms · {br(snapshot.down)} Mb/s
      </p>
    </Shell>
  );
}

function Cartoes({ chrome }: Frame) {
  const cards = [
    { k: "Sinal", v: snapshot.quality, s: `${snapshot.bars} de 4 · ${snapshot.dbm} dBm` },
    { k: "Velocidade", v: `${br(snapshot.down)} Mb/s`, s: `sobe ${br(snapshot.up)} · ping ${snapshot.ping} ms` },
    { k: "Plano", v: `${br(snapshot.usedGb)} GB`, s: `de ${snapshot.capGb} GB · ${snapshot.carrier}` },
  ];
  return (
    <Shell slug="cartoes" chrome={chrome}>
      <Kicker>Cartões</Kicker>
      <div className="mt-5 flex flex-col gap-3">
        {cards.map((card) => (
          <article key={card.k} className="c-surface rounded-2xl px-4 py-4 shadow-sm">
            <h2 className="c-muted text-xs tracking-widest uppercase">{card.k}</h2>
            <p className="mt-2 text-3xl leading-none tracking-tight">{card.v}</p>
            <p className="c-muted mt-2 text-sm">{card.s}</p>
          </article>
        ))}
      </div>
    </Shell>
  );
}

function Faixa({ chrome }: Frame) {
  const [open, setOpen] = useState(true);
  return (
    <Shell slug="faixa" chrome={chrome} bare>
      {chrome ? (
        <button
          type="button"
          className="c-strip flex w-full items-center justify-between px-5 py-4 text-left"
          onClick={() => setOpen((v) => !v)}
        >
          <span className="text-sm font-medium">
            {snapshot.carrier} {snapshot.tech}
          </span>
          <span className="text-sm tabular-nums">{snapshot.ping} ms</span>
        </button>
      ) : (
        <div className="c-strip flex w-full items-center justify-between px-5 py-4 text-left">
          <span className="text-sm font-medium">
            {snapshot.carrier} {snapshot.tech}
          </span>
          <span className="text-sm tabular-nums">{snapshot.ping} ms</span>
        </div>
      )}
      {open ? (
        <div className="px-5 pb-28 pt-6">
          <Kicker>Por baixo da faixa</Kicker>
          <p className="mt-4 text-4xl leading-none tracking-tight">{snapshot.quality}</p>
          <p className="c-muted mt-3 text-sm">
            {snapshot.dbm} dBm · desce {br(snapshot.down)} · plano {br(snapshot.usedGb)} de {snapshot.capGb} GB
          </p>
        </div>
      ) : null}
    </Shell>
  );
}

function wavePath(amp: number, phase: number) {
  let d = "";
  for (let x = 0; x <= 320; x += 8) {
    const y = 28 + Math.sin((x / 320) * Math.PI * 3 + phase) * amp;
    d += `${x === 0 ? "M" : "L"}${x} ${y.toFixed(1)} `;
  }
  return d;
}

function Orbita({ chrome }: Frame) {
  return (
    <Shell slug="orbita" chrome={chrome}>
      <Kicker>Órbita · {snapshot.tech}</Kicker>
      <div className="relative mx-auto mt-8 grid h-64 w-64 place-items-center">
        <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full" aria-hidden>
          <ellipse cx="100" cy="100" rx="88" ry="32" className="ring ring-dim" transform="rotate(-22 100 100)" />
          <ellipse cx="100" cy="100" rx="70" ry="26" className="ring ring-dim" transform="rotate(28 100 100)" />
          <ellipse cx="100" cy="100" rx="46" ry="18" className="ring ring-hot" />
          <g className="orbit-spin">
            <circle cx="100" cy="18" r="4" fill="currentColor" className="c-accent" />
          </g>
        </svg>
        <div className="relative text-center">
          <div className="glow c-accent text-5xl leading-none tabular-nums">{snapshot.dbm}</div>
          <div className="c-muted mt-1 text-xs">dBm</div>
        </div>
      </div>
      <p className="c-muted mt-6 text-center text-sm">{snapshot.carrier} · ping {snapshot.ping} ms</p>
    </Shell>
  );
}

function Fosforo({ chrome }: Frame) {
  return (
    <Shell slug="fosforo" chrome={chrome}>
      <Kicker>link / {snapshot.carrier.toLowerCase()}</Kicker>
      <p className="glow c-accent mt-8 text-6xl leading-none tabular-nums">
        {snapshot.tech}
        <span className="caret">_</span>
      </p>
      <ul className="mt-8 space-y-2 text-sm">
        <li>rssi {snapshot.dbm} dBm</li>
        <li>rtt {snapshot.ping} ms</li>
        <li>down {br(snapshot.down)} Mb/s</li>
        <li className="c-muted">up {br(snapshot.up)} Mb/s · plano {br(snapshot.usedGb)}/{snapshot.capGb}</li>
      </ul>
    </Shell>
  );
}

function Neon({ chrome }: Frame) {
  return (
    <Shell slug="neon" chrome={chrome}>
      <Kicker>{snapshot.place}</Kicker>
      <p className="neon-sign mt-8 text-7xl leading-none tracking-tight">{snapshot.tech}</p>
      <p className="mt-4 text-2xl">{snapshot.quality}</p>
      <div className="mt-10 flex h-24 items-end gap-2">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={`flex-1 ${i <= snapshot.bars ? "c-fill neon-bar" : "c-track"}`}
            style={{ height: `${30 + i * 16}%` }}
          />
        ))}
      </div>
      <p className="c-muted mt-4 text-sm tabular-nums">{snapshot.dbm} dBm · {snapshot.ping} ms</p>
    </Shell>
  );
}

function Visor({ chrome }: Frame) {
  return (
    <Shell slug="visor" chrome={chrome}>
      <Kicker>Visor</Kicker>
      <div className="hud mt-4">
        <span className="hud-corner hud-tl" />
        <span className="hud-corner hud-tr" />
        <span className="hud-corner hud-bl" />
        <span className="hud-corner hud-br" />
        <span className="scan" />
        <div className="absolute inset-0 grid place-items-center text-center">
          <div>
            <div className="c-muted text-xs tracking-widest">LOCK</div>
            <div className="glow c-accent mt-2 text-5xl leading-none tabular-nums">{snapshot.dbm}</div>
            <div className="mt-2 text-sm">{snapshot.carrier} {snapshot.tech}</div>
          </div>
        </div>
        <div className="c-muted absolute bottom-3 left-4 text-xs tabular-nums">{snapshot.ping} ms</div>
        <div className="c-muted absolute right-4 bottom-3 text-xs tabular-nums">{br(snapshot.down)} ↓</div>
      </div>
    </Shell>
  );
}

function Ondas({ chrome }: Frame) {
  const bands = [
    { name: "Desce", amp: 16, phase: 0.4 },
    { name: "Sobe", amp: 9, phase: 1.3 },
    { name: "Ping", amp: 6, phase: 2.1 },
  ];
  return (
    <Shell slug="ondas" chrome={chrome}>
      <Kicker>Ondas</Kicker>
      <div className="mt-6 space-y-3">
        {bands.map((band) => (
          <div key={band.name}>
            <div className="c-muted text-xs tracking-widest uppercase">{band.name}</div>
            <svg viewBox="0 0 320 56" className="h-14 w-full" aria-hidden>
              <path d={wavePath(band.amp, band.phase)} fill="none" stroke="currentColor" strokeWidth="1.6" className="c-accent" />
            </svg>
          </div>
        ))}
      </div>
      <p className="mt-2 text-sm tabular-nums">{br(snapshot.down)} · {br(snapshot.up)} · {snapshot.ping} ms</p>
    </Shell>
  );
}

function Selos({ chrome }: Frame) {
  return (
    <Shell slug="selos" chrome={chrome}>
      <Kicker>Correio da rede</Kicker>
      <article className="c-surface mt-6 px-4 py-5">
        <div className="perf" />
        <p className="c-muted mt-4 text-xs tracking-widest uppercase">{snapshot.place} · {snapshot.carrier}</p>
        <h1 className="mt-3 text-4xl leading-none">{snapshot.quality} passagem</h1>
        <p className="mt-4 text-lg">{snapshot.tech}, {snapshot.dbm} dBm, {snapshot.ping} ms.</p>
        <div className="mt-8 mb-4">
          <span className="stamp text-sm">Sinal bom</span>
        </div>
        <div className="perf" />
      </article>
    </Shell>
  );
}

function Ceu({ chrome }: Frame) {
  const stars = [
    [28, 36, 1.5], [70, 18, 2], [118, 48, 1.6], [168, 22, 4.2], [214, 58, 1.8],
    [92, 88, 2.2], [150, 102, 1.4], [206, 96, 2.6], [48, 110, 1.2],
  ];
  return (
    <Shell slug="ceu" chrome={chrome}>
      <Kicker>Céu · {snapshot.place}</Kicker>
      <svg viewBox="0 0 240 140" className="mt-4 h-44 w-full" aria-hidden>
        <path d="M70 18 L168 22 L214 58 L150 102 L92 88 Z" fill="none" stroke="currentColor" className="c-muted" strokeWidth="0.6" />
        {stars.map(([x, y, r]) => (
          <circle key={`${x}-${y}`} cx={x} cy={y} r={r} fill="currentColor" className={r > 3 ? "c-accent" : "c-muted"} />
        ))}
      </svg>
      <p className="c-accent text-sm">O ponto claro é agora · {snapshot.dbm} dBm</p>
      <p className="c-muted mt-2 text-sm">{snapshot.carrier} {snapshot.tech} · {snapshot.ping} ms</p>
    </Shell>
  );
}

function Fita({ chrome }: Frame) {
  const meters = [
    { name: "Desce", lit: 14 },
    { name: "Sobe", lit: 8 },
    { name: "Ping", lit: 6 },
  ];
  return (
    <Shell slug="fita" chrome={chrome}>
      <Kicker>Deck · {snapshot.carrier}</Kicker>
      <div className="c-surface mt-6 space-y-4 rounded-xl px-4 py-4">
        {meters.map((meter) => (
          <div key={meter.name}>
            <div className="c-muted mb-2 text-xs tracking-widest uppercase">{meter.name}</div>
            <div className="flex gap-1">
              {Array.from({ length: 16 }, (_, i) => (
                <span key={i} className={`h-5 flex-1 ${i < meter.lit ? (i >= 12 ? "vu-hot" : "c-fill") : "c-track"}`} />
              ))}
            </div>
          </div>
        ))}
      </div>
      <p className="c-muted mt-4 text-sm tabular-nums">{snapshot.dbm} dBm · {snapshot.tech}</p>
    </Shell>
  );
}

function Grade({ chrome }: Frame) {
  return (
    <Shell slug="grade" chrome={chrome}>
      <Kicker>Grade noturna</Kicker>
      <div className="mt-5 grid grid-cols-8 gap-1">
        {Array.from({ length: 64 }, (_, i) => {
          const on = (i * 5 + 2) % 9 < snapshot.bars + 3;
          const hot = on && i % 7 === 0;
          return <span key={i} className={`aspect-square ${hot ? "vu-hot" : on ? "c-fill" : "c-track"}`} />;
        })}
      </div>
      <p className="mt-4 text-sm">{snapshot.quality} · {snapshot.bars} de 4 células fortes</p>
      <p className="c-muted text-sm tabular-nums">{snapshot.dbm} dBm · {br(snapshot.down)} Mb/s</p>
    </Shell>
  );
}

function Luneta({ chrome }: Frame) {
  return (
    <Shell slug="luneta" chrome={chrome}>
      <Kicker>Luneta</Kicker>
      <div className="lens mt-6">
        <div>
          <div className="c-accent text-5xl leading-none tabular-nums">{snapshot.dbm}</div>
          <div className="c-muted mt-2 text-xs tracking-widest">dBm</div>
          <div className="mt-3 text-sm">{snapshot.quality}</div>
        </div>
      </div>
      <p className="c-muted mt-6 text-center text-sm">{snapshot.carrier} {snapshot.tech} · {snapshot.place}</p>
    </Shell>
  );
}

const redoIcons: Record<number, LucideIcon> = {
  40: RadioTower,
  41: Antenna,
  42: Signal,
  43: Rss,
  44: Gauge,
  45: Radar,
  46: TowerControl,
  47: Wifi,
};

const wakeIcons: Record<number, LucideIcon> = {
  48: Radio,
  49: HeartPulse,
  50: Stethoscope,
  51: ScanSearch,
  52: Microscope,
  53: SatelliteDish,
  54: Ruler,
  55: DraftingCompass,
  56: TestTubes,
};

function icone(kicker: string, title: string, note: string, Icon: LucideIcon) {
  return function Botao({ chrome }: Frame) {
    return (
      <Shell slug="botao" chrome={chrome}>
        <Kicker>{kicker}</Kicker>
        <p className="mt-6 text-3xl leading-none">{title}</p>
        <div className="botao-stage">
          <span className="speed-redo is-armed" aria-hidden>
            <Icon size={22} strokeWidth={2.25} />
          </span>
        </div>
        <p className="c-muted mt-4 max-w-xs text-sm">{note}</p>
      </Shell>
    );
  };
}

function botao(title: string, note: string, Icon: LucideIcon) {
  return icone("Medir", title, note, Icon);
}

function acordar(title: string, note: string, Icon: LucideIcon) {
  return icone("Sintonizar", title, note, Icon);
}

function chapa(slug: string, title: string, note: string) {
  return function Chapa({ chrome }: Frame) {
    return (
      <Shell slug="chapa" chrome={chrome}>
        <Kicker>Botões</Kicker>
        <p className="mt-6 text-3xl leading-none">{title}</p>
        <div className="chapa-stage">
          <span className={`speed-redo chapa-${slug}`} aria-hidden>
            <Gauge size={22} strokeWidth={2.25} />
          </span>
          <span className={`speed-redo chapa-${slug}`} aria-hidden>
            <SatelliteDish size={22} strokeWidth={2.25} />
          </span>
        </div>
        <p className="c-muted mt-4 max-w-xs text-sm">{note}</p>
      </Shell>
    );
  };
}

function fundo(slug: string, title: string, note: string) {
  return function Fundo({ chrome }: Frame) {
    return (
      <Shell slug={slug} chrome={chrome}>
        <Kicker>Fundo</Kicker>
        <p className="mt-8 text-3xl leading-none">{title}</p>
        <p className="c-muted mt-4 max-w-xs text-sm">{note}</p>
      </Shell>
    );
  };
}

function efeitoVisor(slug: string, title: string, note: string) {
  return function Efeito({ chrome }: Frame) {
    const flick = useRandomFlicker(slug === "cintilacao");
    return (
      <Shell slug="fosforo" chrome={chrome}>
        <Kicker>Efeito</Kicker>
        <p className="mt-6 text-3xl leading-none">{title}</p>
        <div className={`speed-square efeito-${slug} ${flick ? "is-flick" : ""} mt-8`} style={flick ? { ["--flick" as string]: `${flick}ms` } : undefined}>
          <p>
            <span className="fosforo-figure"><SegNum value="42,6" /></span>
            <span className="fosforo-unit">Mb/s</span>
            <i className="fosforo-scan" aria-hidden />
          </p>
        </div>
        <p className="c-muted mt-4 max-w-xs text-sm">{note}</p>
      </Shell>
    );
  };
}

const views: Record<ConceptId, (p: Frame) => ReactElement> = {
  1: Campo,
  2: Sentenca,
  3: Cockpit,
  4: Franquia,
  5: Pulso,
  6: Barras,
  7: Diario,
  8: Relogio,
  9: Cartoes,
  10: Faixa,
  11: Orbita,
  12: Fosforo,
  13: Neon,
  14: Visor,
  15: Ondas,
  16: Selos,
  17: Ceu,
  18: Fita,
  19: Grade,
  20: Luneta,
  21: fundo("escovado", "Escovado", "Alumínio escovado, claro, como tampa de aparelho."),
  22: fundo("aco", "Aço", "Chapa de aço fosco, do tipo painel de instrumento."),
  23: fundo("anodizado", "Anodizado", "Alumínio anodizado preto, sem brilho de neon."),
  24: fundo("inox", "Inox", "Aço inoxidável escovado na diagonal."),
  25: fundo("jateado", "Jateado", "Alumínio jateado, fosco, sem direção de escova."),
  26: fundo("esmalte", "Esmalte", "Tinta eletrostática grafite, de chassi de equipamento."),
  27: fundo("fresagem", "Fresagem", "Alumínio escovado na vertical, com risco e reflexo de estúdio."),
  28: fundo("acovivo", "Aço vivo", "Aço laminado, grão fino e brilho de óleo."),
  29: fundo("negro", "Negro", "Alumínio anodizado preto, luz raspando a superfície."),
  30: fundo("espelho", "Espelho", "Inox escovado na diagonal, com reflexo do ambiente."),
  31: fundo("grao", "Grão", "Alumínio jateado, fosco, grão fechado."),
  32: fundo("chassi", "Chassi", "Tinta de equipamento, casca de laranja, emenda e parafusos."),
  33: fundo("liga", "Liga", "Inox do Espelho com a emenda e os parafusos do Chassi."),
  34: fundo("ferrugem", "Ferrugem", "Aço quase íntegro, com pequenas manchas de corrosão."),
  35: fundo("gasto", "Gasto", "Alumínio com risco, mancha fosca e oxidação na borda."),
  36: fundo("zinco", "Zinco", "Chapa galvanizada, corrosão pequena no canto."),
  37: fundo("parafusos", "Parafusos", "Placa grafite com quatro parafusos allen."),
  38: fundo("pregos", "Pregos", "Chapa clara com rebites e duas cabeças de prego."),
  39: fundo("fixacao", "Fixação", "Parafusos e um prego, com ferrugem só em volta deles."),
  40: botao("Torre", "Mastro com ondas no topo.", RadioTower),
  41: botao("Antena", "Haste única, como antena de rádio.", Antenna),
  42: botao("Sinal", "Barras crescendo. O sinal em pé.", Signal),
  43: botao("Onda", "Três arcos saindo de um ponto.", Rss),
  44: botao("Medidor", "Ponteiro de instrumento. É o ícone atual.", Gauge),
  45: botao("Radar", "Círculo com um braço varrendo.", Radar),
  46: botao("Poste", "Torre de controle, mais larga que o mastro.", TowerControl),
  47: botao("Wi-fi", "O arco familiar do Wi-fi.", Wifi),
  48: acordar("Rádio", "O rádio de antes.", Radio),
  49: acordar("Pulso", "Linha de pulso. Diagnóstico.", HeartPulse),
  50: acordar("Esteto", "Estetoscópio. Ausculta a rede.", Stethoscope),
  51: acordar("Varredura", "Uma busca varrendo o sinal.", ScanSearch),
  52: acordar("Lente", "Microscópio. Exame de perto.", Microscope),
  53: acordar("Prato", "Antena parabólica. É o ícone atual.", SatelliteDish),
  54: acordar("Régua", "Medida direta, em escala.", Ruler),
  55: acordar("Compasso", "Abre o arco e mede.", DraftingCompass),
  56: acordar("Tubos", "Análise de laboratório.", TestTubes),
  57: efeitoVisor("brilho", "Brilho", "O número ganha um halo de fósforo."),
  58: efeitoVisor("cintilacao", "Cintilação", "O visor pisca leve, como um tubo cansado."),
  59: efeitoVisor("fantasma", "Fantasma", "Uma cópia fraca do texto, um pouco ao lado."),
  60: efeitoVisor("grao", "Grão", "Granulação fina sobre o vidro."),
  61: efeitoVisor("vinheta", "Vinheta", "Os cantos do visor escurecem."),
  62: efeitoVisor("reflexo", "Reflexo", "Um brilho de vidro atravessa o visor."),
  63: efeitoVisor("moldura", "Moldura", "A borda interna acende e apaga."),
  64: efeitoVisor("linhas", "Linhas", "As linhas do tubo ficam mais fortes e descem."),
  65: efeitoVisor("nucleo", "Núcleo", "Um clarão parado atrás do número."),
  66: efeitoVisor("poeira", "Poeira", "Pontos pequenos parados no vidro."),
  67: efeitoVisor("vidro", "Vidro", "Reflexo fixo de vidro curvo no topo."),
  68: efeitoVisor("quente", "Quente", "O centro mais claro e a borda mais escura."),
  69: efeitoVisor("batida", "Batida", "O visor inteiro respira em brilho."),
  70: efeitoVisor("eco", "Eco", "O texto se repete, cada vez mais fraco."),
  71: efeitoVisor("neblina", "Neblina", "Uma névoa leve por cima do vidro."),
  72: chapa("polido", "Polido", "Alumínio novo. Sem marca de uso."),
  73: chapa("escova", "Escova", "Aço escovado na horizontal, ainda limpo."),
  74: chapa("jato", "Jato", "Fosco jateado. Quase nenhum brilho."),
  75: chapa("chumbo", "Chumbo", "Grafite escuro, liso, pouco manuseado."),
  76: chapa("frio", "Frio", "Inox com reflexo frio na diagonal."),
  77: chapa("niquel", "Níquel", "Metal morno, com um véu leve de dedo."),
  78: chapa("bronze", "Bronze", "Bronze escuro. Pátina só num canto."),
  79: chapa("oleo", "Óleo", "Aço com véu de óleo e uma marca de dedo."),
  80: chapa("dedos", "Dedos", "As bordas escureceram de tanto toque."),
  81: chapa("uso", "Uso", "Centro mais claro. Os cantos já gastaram."),
  82: chapa("oxido", "Óxido", "Zinco com pontos brancos de oxidação."),
  83: chapa("patina", "Pátina", "Bronze com verde só na borda."),
  84: chapa("pinta", "Pinta", "Aço com pintas pequenas de ferrugem."),
  85: chapa("tempera", "Têmpera", "Aço queimado. Azul e marrom de calor."),
  86: chapa("sucata", "Sucata", "O mais usado: escuro, manchado, ferrugem na quina."),
};

export function Concept({
  id,
  chrome = true,
  actions = false,
}: {
  id: ConceptId;
  chrome?: boolean;
  actions?: boolean;
}) {
  const View = views[id];
  return <View chrome={chrome} actions={actions} />;
}
