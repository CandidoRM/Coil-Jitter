import { useEffect, useState } from "react";
import { FlaskConical, Gauge } from "lucide-react";
import { Concept } from "@/components/concepts";
import { chooseConcept, hydrateChoice, useBackground, useButton, useChapa, useChosen, useVisorEffect, useWakeIcon } from "@/lib/choice";
import { hydratePlan } from "@/lib/plan";
import { concepts, type ConceptId } from "@/lib/net";

function inUse(
  item: (typeof concepts)[number],
  state: { chosen: ConceptId; fundo: ConceptId; botao: ConceptId; acordar: ConceptId; efeito: ConceptId | null; chapa: ConceptId | null },
) {
  if ("kind" in item && item.kind === "fundo") return state.fundo === item.id;
  if ("kind" in item && item.kind === "botao") return state.botao === item.id;
  if ("kind" in item && item.kind === "acordar") return state.acordar === item.id;
  if ("kind" in item && item.kind === "efeito") return state.efeito === item.id;
  if ("kind" in item && item.kind === "chapa") return state.chapa === item.id;
  return state.chosen === item.id;
}

const labOrder = [...concepts].sort((a, b) => {
  const rank = (item: (typeof concepts)[number]) =>
    "kind" in item && item.kind === "marca" && item.slug.startsWith("lua-")
      ? -6
      : "kind" in item && item.kind === "marca" && item.slug.startsWith("zz-")
      ? -5
      : "kind" in item && item.kind === "marca" && item.slug === "sono-0"
      ? -4
      : "kind" in item && item.kind === "marca" && item.slug.startsWith("sono-")
      ? -3
      : "kind" in item && item.kind === "marca" && item.slug.startsWith("lenta-")
      ? -2
      : "kind" in item && item.kind === "marca" && item.slug.startsWith("ociosa-")
        ? -1
        : "kind" in item && item.kind === "chapa"
          ? 0
          : 1;
  return rank(a) - rank(b);
});

export function DevLab() {
  const chosen = useChosen();
  const fundo = useBackground();
  const botao = useButton();
  const acordar = useWakeIcon();
  const efeito = useVisorEffect();
  const chapa = useChapa();
  const [open, setOpen] = useState(false);
  const [preview, setPreview] = useState<ConceptId | null>(null);

  useEffect(() => {
    hydrateChoice();
    hydratePlan();
  }, []);

  function onLaunch() {
    if (open || preview) {
      setOpen(false);
      setPreview(null);
      return;
    }
    setOpen(true);
  }

  const current = concepts.find((item) => item.id === preview);

  return (
    <>
      <button
        type="button"
        className="dev-launch"
        aria-label={open || preview ? "Fechar testes" : "Abrir testes"}
        aria-pressed={open || preview != null}
        onClick={onLaunch}
      >
        <FlaskConical size={18} strokeWidth={1.75} />
      </button>

      {open && preview == null ? (
        <div className="lab-layer" role="dialog" aria-label="Testes do desenvolvedor">
          <p className="lab-kicker">Desenvolvedor</p>
          <h1 className="lab-title">Testes</h1>
          <p className="lab-note">
            As chapas dos botões vêm primeiro. Cada uma é o fundo real da tecla. Depois vêm a interface, os fundos, os ícones e os efeitos dos visores.
          </p>
          <ul className="lab-list">
            {labOrder.map((item) => {
              const plate = "kind" in item && item.kind === "chapa";
              return (
              <li key={item.id}>
                <button type="button" className="lab-row" onClick={() => setPreview(item.id)}>
                  <div className={plate ? "thumb thumb-chapa" : "thumb"} aria-hidden>
                    {plate ? (
                      <span className={`speed-redo chapa-${item.slug}`}>
                        <Gauge size={20} strokeWidth={2.25} />
                      </span>
                    ) : (
                      <div className="thumb-inner">
                        <Concept id={item.id} chrome={false} />
                      </div>
                    )}
                  </div>
                  <span>
                    <span className="lab-num">{String(item.id).padStart(2, "0")}</span>
                    <span className="lab-name">{item.name}</span>
                    <span className="lab-line">{item.line}</span>
                    {inUse(item, { chosen, fundo, botao, acordar, efeito, chapa }) ? (
                      <span className="lab-flag">Em uso</span>
                    ) : null}
                  </span>
                </button>
              </li>
              );
            })}
          </ul>
        </div>
      ) : null}

      {preview != null && current ? (
        <div className="lab-layer p-0" role="dialog" aria-label={current.name}>
          <Concept id={preview} />
          <div className="lab-dock">
            <button type="button" onClick={() => setPreview(null)}>
              Voltar à lista
            </button>
            {"kind" in current && current.kind === "marca" ? null : (
            <button type="button" className="primary" onClick={() => chooseConcept(preview)}>
              {inUse(current, { chosen, fundo, botao, acordar, efeito, chapa }) ? "Em uso" : "Usar esta"}
            </button>
            )}
          </div>
        </div>
      ) : null}
    </>
  );
}
