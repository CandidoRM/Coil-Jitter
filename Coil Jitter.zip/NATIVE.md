# Coil Jitter nativo

Quando o app for nativo, o Sintonizar deve trocar o DNS de verdade.

- Usar VpnService só para as consultas de nome, apontando para `1.1.1.1`.
- O usuário autoriza a VPN uma vez.
- O download continua no caminho da operadora. Não aumenta megabit. No máximo a página começa um pouco antes.
- Não fingir a troca. No app web isso fica só como consulta, em `probeDns`.

Quando o app for nativo, detectar portal preso.

- O Android já marca a rede. Ler essa marca.
- Se estiver preso, o Visor de Diagnóstico mostra "Portal preso".
- Se quiser, abrir a tela de login do sistema.
- No navegador isso não dá. O HTTPS esconde a página de login. Não fingir a frase no app web.

Quando o app for nativo, testar IPv4 e IPv6 e ficar com o que responder.

- Resolver o endereço antigo (A) e o novo (AAAA) de `speed.cloudflare.com`.
- Abrir os dois ao mesmo tempo, com o nome certo no certificado, e um limite curto.
- A medição e os pacotes do Coil Jitter seguem pelo que responder primeiro.
- Não aumenta megabit. Só evita a espera quando um dos caminhos está mudo.
- No navegador isso não dá. A página não escolhe o tipo de endereço. Não fingir a escolha no app web.

